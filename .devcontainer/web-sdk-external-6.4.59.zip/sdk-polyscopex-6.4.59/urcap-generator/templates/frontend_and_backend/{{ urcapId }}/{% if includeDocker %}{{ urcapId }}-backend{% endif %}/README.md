# Docker {% if includeRos %}ROS2 Node {% endif %}contribution

This project is a template example of a URCap with a Docker {% if includeRos %}ROS2 Node {% endif %}contribution

### Installation
To install the URCap type:

`$ npm install`

### Build
To build the URCap type:

`$ npm run build`

### Deploy
To deploy the URCap to the simulator type:

`$ npm run install-urcap`

## Further help

Get more help from the included SDK documentation.
