import { ProgramNode, TabInputModel, Time, SignalValue, SignalValueTypeEnum } from '@universal-robots/contribution-api';
import { SelectedType, TabInputValue } from '@universal-robots/ui-models';

export const floatOperators = ['<', '>'] as const;
export const registerOperators = [...floatOperators, '==', '!=', '>=', '<='] as const;
export const operatorInverseMap = {
    '<': '>=',
    '>': '<=',
    '==': '!=',
    '!=': '==',
    '>=': '<',
    '<=': '>',
} as const;

export type floatOperator = (typeof floatOperators)[number];
export type registerOperator = (typeof registerOperators)[number];

export interface SampleWaitNodeSignalInput {
    groupId?: string;
    sourceID?: string;
    signalID?: string;
    selectedType?: SelectedType;
    floatOperator?: floatOperator;
    registerOperator?: registerOperator;
    value?: SignalValue;
    signalValueType?: SignalValueTypeEnum;
}

export interface SampleWaitNode extends ProgramNode {
    type: 'ur-sample-node-wait';
    parameters: {
        type: 'time' | 'signalInput' | 'expression';
        time?: TabInputModel<Time>;
        signalInput?: SampleWaitNodeSignalInput;
        expression?: TabInputValue;
    };
}
