# Overview of sample

This project is an example of how to access USB devices from inside a URCap, using the container Hot plug mechanism.

Refer to the [official documentation](https://docs.universal-robots.com/) for more information.

## Build and Deploy Sample

To build and deploy this sample, use the commands below. A rebuild of the project is required to see any changes made 
to the source code. If you are deploying the URCap to URSim, ensure that you have started the simulator.

### Dependencies

Run this command to install the dependencies of the project.

```shell
npm install
```

### Build

Run this command to build the contribution type.

```shell
npm run build
```

### Installation

Run this command to install the built URCap to the simulator.

```shell
npm run install-urcap
```

Run this command to install the built URCap to the robot.

```shell
npm run install-urcap -- --host <robot_ip_address>
````


## Backend contribution

The project only contains a backend contribution providing two Hot plug callback hooks:
on_device_add and on_device_remove implemented as bash scripts.

The hooks will accept all supported USB devices and log all data at in a log file found inside the container at 
`/data/temporary/log.txt`. The log is also written to the container console output, it can be viewed from a robot teminal
by doing `docker logs universal-robots_usb-hotplug_usb-hotplug-backend`.

## Usage

With the URCap installed, connect and disconnect USB devices and observe the Hot plug events
being written in the URCap log. 

Access the URCap container to observe the USB devices being made available `docker exec -it universal-robots_usb-hotplug_usb-hotplug-backend sh`.
### USB to Ethernet
With an USB to Ethernet dongle connected, execute the following command from within the URCap container: `ip addr show`. 
From the output you should be able to observe an extra ethernet interface available in the container.

### USB to Serial
With an USB to serial dongle connected, from within the URCap container inspect the log file `/data/temporary/log.txt`. Find the `on_device_add` 
entry and the corresponding JSON payload. In the JSON find the `deviceNode` value and check that the serial device can be found at this path.

### USB to Video
With an USB to video dongle connected, from within the URCap container inspect the log file `/data/temporary/log.txt`. Find the `on_device_add` 
entry and the corresponding JSON payload. In the JSON find the `deviceNode` value and check that the video device can be found at this path.