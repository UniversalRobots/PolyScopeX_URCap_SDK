import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { first } from 'rxjs/operators';
import { ApplicationPresenter, ApplicationPresenterAPI, RobotSettings } from '@universal-robots/contribution-api';
import { URCAP_ID, VENDOR_ID } from '../../../generated/contribution-constants';
import { XmlRpcClient } from '../../xmlrpc/xmlrpc-client';
import { SimpleXmlrpcApplicationNode } from './simple-xmlrpc-application-node.node';

@Component({
    templateUrl: './simple-xmlrpc-application-node.component.html',
    styleUrls: ['./simple-xmlrpc-application-node.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    standalone: false,
})
export class SimpleXmlrpcApplicationNodeComponent implements ApplicationPresenter, OnChanges {
    // applicationAPI is optional
    @Input() applicationAPI: ApplicationPresenterAPI;
    // robotSettings is optional
    @Input() robotSettings: RobotSettings;
    private _applicationNode: SimpleXmlrpcApplicationNode;

    private xmlrpc: XmlRpcClient;

    response: string;

    constructor(
        protected readonly translateService: TranslateService,
        protected readonly cd: ChangeDetectorRef,
    ) {}

    // applicationNode is required
    get applicationNode(): SimpleXmlrpcApplicationNode {
        return this._applicationNode;
    }

    @Input()
    set applicationNode(value: SimpleXmlrpcApplicationNode) {
        this._applicationNode = value;
        this.cd.detectChanges();
    }

    async ngOnChanges(changes: SimpleChanges): Promise<void> {
        if (changes?.robotSettings) {
            if (!changes?.robotSettings?.currentValue) {
                return;
            }

            if (changes?.robotSettings?.isFirstChange()) {
                if (changes?.robotSettings?.currentValue) {
                    this.translateService.use(changes?.robotSettings?.currentValue?.language);
                }
                this.translateService.setDefaultLang('en');
            }

            this.translateService
                .use(changes?.robotSettings?.currentValue?.language)
                .pipe(first())
                .subscribe(() => {
                    this.cd.detectChanges();
                });
        }
        const url = this.applicationAPI.getContainerContributionURL(VENDOR_ID, URCAP_ID, 'simple-xmlrpc-backend', 'xmlrpc');
        this.xmlrpc = new XmlRpcClient(`${location.protocol}//${url}/`);
    }

    async getListOfMethods() {
        this.response = await this.xmlrpc.methodCall('system.listMethods');
        this.cd.detectChanges();
    }

    async getMethodHelp() {
        this.response = await this.xmlrpc.methodCall('system.methodHelp', 'echo_string_method');
        this.cd.detectChanges();
    }

    async sendString() {
        this.response = await this.xmlrpc.methodCall('echo_string_method', 'Great Job!');
        this.cd.detectChanges();
    }

    async sendInteger() {
        this.response = await this.xmlrpc.methodCall('echo_integer_method', 10);
        this.cd.detectChanges();
    }

    async sendStruct() {
        const myData = {
            name: 'John',
            age: 30.7,
            address: {
                city: 'Odense',
                zipCode: 5220,
            },
            hobbies: ['Reading', 'Gardening'],
        };
        const response_object = await this.xmlrpc.methodCall('echo_struct_method', myData);
        this.response = JSON.stringify(response_object);
        this.cd.detectChanges();
    }

    // call saveNode to save node parameters
    saveNode() {
        this.cd.detectChanges();
        this.applicationAPI.applicationNodeService.updateNode(this.applicationNode);
    }
}
