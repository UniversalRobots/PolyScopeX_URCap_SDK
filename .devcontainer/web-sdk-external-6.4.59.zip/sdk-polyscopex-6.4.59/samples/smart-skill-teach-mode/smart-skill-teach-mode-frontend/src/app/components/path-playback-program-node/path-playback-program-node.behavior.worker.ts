/// <reference lib="webworker" />
import {
    InsertionContext,
    OptionalPromise,
    ProgramBehaviors,
    ProgramNode,
    registerProgramBehavior,
    ScriptBuilder,
    ValidationContext,
    ValidationResponse,
} from '@universal-robots/contribution-api';
import { PathPlaybackProgramNodeNode } from './path-playback-program-node.node';

// programNodeLabel is required
const createProgramNodeLabel = (node: PathPlaybackProgramNodeNode): OptionalPromise<string> =>
    node.parameters.jointAngles.length + ' moves';

// factory is required
const createProgramNode = (): OptionalPromise<PathPlaybackProgramNodeNode> => ({
    type: 'universal-robots-smart-skill-teach-mode-path-playback-program-node',
    version: '1.0.0',
    lockChildren: false,
    allowsChildren: false,
    parameters: {
        jointAngles: [],
        sampleFrequency: 10,
    },
});

// generateCodeBeforeChildren is optional
const generateScriptCodeBefore = (node: PathPlaybackProgramNodeNode): OptionalPromise<ScriptBuilder> => {
    const scriptBuilder = new ScriptBuilder();
    //move slow and safe into the start position
    scriptBuilder.movej(node.parameters.jointAngles[0], 0.2, 0.3);
    node.parameters.jointAngles.forEach((element) => {
        const timeStep = 1 / node.parameters.sampleFrequency;
        scriptBuilder.addRaw('servoj([' + element.toString() + '], 0,0,' + timeStep + ',0.1,300)');
    });
    scriptBuilder.addRaw('stopj(1)');
    return scriptBuilder;
};

// generateCodeAfterChildren is optional
const generateScriptCodeAfter = (node: PathPlaybackProgramNodeNode): OptionalPromise<ScriptBuilder> => new ScriptBuilder();

// generateCodePreamble is optional
const generatePreambleScriptCode = (node: PathPlaybackProgramNodeNode): OptionalPromise<ScriptBuilder> => new ScriptBuilder();

// validator is optional
const validate = (node: PathPlaybackProgramNodeNode, validationContext: ValidationContext): OptionalPromise<ValidationResponse> => ({
    isValid: true,
});

// allowsChild is optional
const allowChildInsert = (node: ProgramNode, childType: string): OptionalPromise<boolean> => true;

// allowedInContext is optional
const allowedInsert = (insertionContext: InsertionContext): OptionalPromise<boolean> => true;

// upgradeNode is optional
const nodeUpgrade = (loadedNode: ProgramNode): ProgramNode => loadedNode;

const behaviors: ProgramBehaviors = {
    programNodeLabel: createProgramNodeLabel,
    factory: createProgramNode,
    generateCodeBeforeChildren: generateScriptCodeBefore,
    generateCodeAfterChildren: generateScriptCodeAfter,
    generateCodePreamble: generatePreambleScriptCode,
    validator: validate,
    allowsChild: allowChildInsert,
    allowedInContext: allowedInsert,
    upgradeNode: nodeUpgrade,
};

registerProgramBehavior(behaviors);
