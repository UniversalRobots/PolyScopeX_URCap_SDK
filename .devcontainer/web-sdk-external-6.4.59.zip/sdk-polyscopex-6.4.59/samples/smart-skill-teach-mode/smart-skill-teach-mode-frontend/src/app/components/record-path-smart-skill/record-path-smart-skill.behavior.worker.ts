import {
    registerSmartSkillBehavior,
    ScriptBuilder,
    SmartSkillBehaviors,
    SmartSkillInstance,
    SmartSkillsBehaviorAPI,
    SmartSkillsData,
} from '@universal-robots/contribution-api';
import { PathPlaybackProgramNodeNode } from '../path-playback-program-node/path-playback-program-node.node';

const behaviors: SmartSkillBehaviors = {
    // factory is required
    factory: () => {
        return {
            type: 'universal-robots-smart-skill-teach-mode-record-path-smart-skill',
            name: 'Record Path Smart Skill',
            parameters: {},
            //Recording frequency
            recordingFrequency: 100,
            //RTDE signals to record
            recordingSignals: ['target_q'],
        };
    },

    // startExecution is required
    startExecution: (instance) => {
        const builder = new ScriptBuilder();
        builder.addStatements('freedrive_mode()');
        builder.beginWhile('True');
        builder.sync();
        builder.end();
        return builder;
    },

    // stopExecution is optional
    stopExecution: (instance) => {
        return new ScriptBuilder();
    },

    // Parameters:
    //  instance: This Smart skills node containing its parameter data.
    //  data: Data recorded during Smart skill activation.
    // Return: OptionalPromise<ProgramNode>

    createProgramNode: async (instance: SmartSkillInstance, data: SmartSkillsData[]) => {
        //target Frequency after downsampling
        const downSampledFrequency: number = 5;
        //Array for holding the movement we want to replay, each joint angle set is a number array
        let jointAngles: number[][] = [];
        if (data.length > 0) {
            //Loop over the array of recorded data and select all the target joint angles
            data.forEach((element) => {
                jointAngles.push(element.target_q);
            });
            //Process the data, this could be done using a contributed backend component
            //For this example we simply do a rough downsampling of the data
            jointAngles = simpleDownsampleToFrequency(jointAngles, downSampledFrequency, instance.recordingFrequency);
        }

        const api = new SmartSkillsBehaviorAPI(self);
        // Create a program node to be directly inserted in the program tree.
        const myCreatedNode = (await api.builder.createNode(
            'universal-robots-smart-skill-teach-mode-path-playback-program-node',
        )) as PathPlaybackProgramNodeNode;
        //Pass the processed data to the program node. The program node will use the data to generate script during program execution
        myCreatedNode.parameters.jointAngles = jointAngles;
        myCreatedNode.parameters.sampleFrequency = downSampledFrequency;
        return myCreatedNode;
    },

    // Parameters:
    //  instance: This Smart skills node containing its parameter data.
    //  data: Data recorded during Smart skill activation.
    // Return: Promise<ScriptBuilder>

    async undo(instance: SmartSkillInstance, data: SmartSkillsData[]): Promise<ScriptBuilder> {
        const undoScriptBuilder = new ScriptBuilder();
        const targetPosition = data[0]?.target_q;
        undoScriptBuilder.append(buildMoveScript(targetPosition));
        return undoScriptBuilder;
    },

    // Parameters:
    //  instance: This Smart skills node containing its parameter data.
    //  data: Data recorded during Smart skill activation.
    // Return: Promise<ScriptBuilder>

    async redo(instance: SmartSkillInstance, data: SmartSkillsData[]): Promise<ScriptBuilder> {
        const redoScriptBuilder = new ScriptBuilder();
        const targetPosition = data[data.length - 1]?.target_q;
        redoScriptBuilder.append(buildMoveScript(targetPosition));
        return redoScriptBuilder;
    },
};

//Simple function to downsample the recorded data
function simpleDownsampleToFrequency(jointAngles: number[][], downSampledFrequency: number, frequency: number) {
    let downsampledData: number[][] = [];
    const factor = Math.floor(frequency / downSampledFrequency);
    for (let x = 0; x < jointAngles.length; x += factor) {
        downsampledData.push(jointAngles[x]);
    }
    //Make sure to the end position is added
    downsampledData.push(jointAngles[jointAngles.length - 1]);
    return downsampledData;
}

function buildMoveScript(targetPosition: any): ScriptBuilder {
    const builder = new ScriptBuilder();
    if (targetPosition) {
        builder.movej(targetPosition, 0.5, 0.5);
    } else {
        builder.addRaw(`popup("${this.translate.instant('program.undo_redo_smart_skill.no_data')}")`);
    }
    return builder;
}
registerSmartSkillBehavior(behaviors);
