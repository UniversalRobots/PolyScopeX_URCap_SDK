import { HttpBackend, HttpClientModule } from '@angular/common/http';
import { DoBootstrap, Injector, NgModule } from '@angular/core';
import { createCustomElement } from '@angular/elements';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { MultiTranslateHttpLoader } from 'ngx-translate-multi-http-loader';
import { UIAngularComponentsModule } from '@universal-robots/ui-angular-components';
import { PATH } from '../generated/contribution-constants';
import { PathPlaybackProgramNodeComponent } from './components/path-playback-program-node/path-playback-program-node.component';

export const httpLoaderFactory = (http: HttpBackend) =>
    new MultiTranslateHttpLoader(http, [
        { prefix: PATH + '/assets/i18n/', suffix: '.json' },
        { prefix: './ui/assets/i18n/', suffix: '.json' },
    ]);

@NgModule({
    declarations: [PathPlaybackProgramNodeComponent],
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        UIAngularComponentsModule,
        HttpClientModule,
        TranslateModule.forRoot({
            loader: { provide: TranslateLoader, useFactory: httpLoaderFactory, deps: [HttpBackend] },
            useDefaultLang: false,
        }),
    ],
    providers: [],
})
export class AppModule implements DoBootstrap {
    constructor(private injector: Injector) {}

    ngDoBootstrap() {
        const pathplaybackprogramnodeComponent = createCustomElement(PathPlaybackProgramNodeComponent, { injector: this.injector });
        customElements.define('universal-robots-smart-skill-teach-mode-path-playback-program-node', pathplaybackprogramnodeComponent);
    }

    // This function is never called, because we don't want to actually use the workers, just tell webpack about them
    registerWorkersWithWebPack() {
        new Worker(
            new URL(
                './components/path-playback-program-node/path-playback-program-node.behavior.worker.ts',
                /* webpackChunkName: "path-playback-program-node.worker" */ import.meta.url,
            ),
            {
                name: 'path-playback-program-node',
                type: 'module',
            },
        );
        new Worker(
            new URL(
                './components/record-path-smart-skill/record-path-smart-skill.behavior.worker.ts',
                /* webpackChunkName: "record-path-smart-skill.worker" */ import.meta.url,
            ),
            {
                name: 'record-path-smart-skill',
                type: 'module',
            },
        );
    }
}
