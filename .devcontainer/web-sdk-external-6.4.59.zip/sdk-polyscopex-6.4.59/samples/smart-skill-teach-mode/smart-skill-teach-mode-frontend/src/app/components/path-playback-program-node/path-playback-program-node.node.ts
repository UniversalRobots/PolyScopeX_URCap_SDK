import { ProgramNode } from '@universal-robots/contribution-api';

export interface PathPlaybackProgramNodeNode extends ProgramNode {
    type: string;
    parameters: {
        jointAngles: number[][];
        sampleFrequency: number;
    };
    lockChildren?: boolean;
    allowsChildren?: boolean;
}
