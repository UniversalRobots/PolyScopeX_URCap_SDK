const path = require('path');
const CopyPlugin = require('copy-webpack-plugin');
const TerserPlugin = require('terser-webpack-plugin');

module.exports = [
  {
    name: 'main',
    entry: './src/index.js',
    mode: 'production',
    devServer: {
      host: '0.0.0.0',
      hot: true,
      static: ['assets'],
      allowedHosts: 'all',
      compress: true,
      port: 4200,
    },
    output: {
        path: path.resolve(__dirname, 'dist/{{ frontendId }}'),
        filename: 'main.js'
    }{% if  (hasProgramNode or hasApplicationNode or hasSmartSkill or hasSidebar or hasOperatorScreen) %},
    plugins: [
      new CopyPlugin({
        patterns: [
          { from: "./src/contribution.json" },
          { from: "./src/assets", to: path.resolve(__dirname, 'dist/{{ frontendId }}/assets') }
        ],
      }),
    ], {% endif %}
  }{% if  (hasApplicationNode) %},
  {
    name: '{{ applicationNodeName }}',
    entry: './src/application/{{ applicationNodeName }}.behavior.worker.js',
    mode: 'production',
    output: {
        path: path.resolve(__dirname, 'dist/{{ frontendId }}'),
        filename: '{{ applicationNodeName }}.worker.js'
    },
    optimization: {
      minimize: true,
        minimizer: [new TerserPlugin({
        terserOptions: {
          format: {
            comments: false,
          },
        },
        extractComments: false,
      })]
    }
  }{% endif %}{% if (hasProgramNode) %},
  {
    name: '{{ programNodeName }}',
    entry: './src/program/{{ programNodeName }}.behavior.worker.js',
      mode: 'production',
      output: {
      path: path.resolve(__dirname, 'dist/{{ frontendId }}'),
        filename: '{{ programNodeName }}.worker.js'
    },
    optimization: {
      minimize: true,
        minimizer: [new TerserPlugin({
        terserOptions: {
          format: {
            comments: false,
          },
        },
        extractComments: false,
      })]
    }
  }{% endif %}{% if (hasSmartSkill) %},
  {
    name: '{{ smartSkillName }}',
    entry: './src/smart-skill/{{ smartSkillName }}.behavior.worker.js',
    mode: 'production',
    output: {
    path: path.resolve(__dirname, 'dist/{{ frontendId }}'),
      filename: '{{ smartSkillName }}.worker.js'
  },
    optimization: {
      minimize: true,
        minimizer: [new TerserPlugin({
        terserOptions: {
          format: {
            comments: false,
          },
        },
        extractComments: false,
      })]
    }
  }{% endif %}{% if (hasSidebar) %},
{
  name: '{{ sidebarName }}',
    entry: './src/sidebar/{{ sidebarName }}.behavior.worker.js',
  mode: 'production',
  output: {
  path: path.resolve(__dirname, 'dist/{{ frontendId }}'),
    filename: '{{ sidebarName }}.worker.js'
},
  optimization: {
    minimize: true,
      minimizer: [new TerserPlugin({
      terserOptions: {
        format: {
          comments: false,
        },
      },
      extractComments: false,
    })]
  }
}{% endif %}{% if (hasOperatorScreen) %},
{
  name: '{{ operatorScreenName }}',
    entry: './src/operator-screen/{{ operatorScreenName }}.behavior.worker.js',
  mode: 'production',
  output: {
  path: path.resolve(__dirname, 'dist/{{ frontendId }}'),
    filename: '{{ operatorScreenName }}.worker.js'
},
  optimization: {
    minimize: true,
      minimizer: [new TerserPlugin({
      terserOptions: {
        format: {
          comments: false,
        },
      },
      extractComments: false,
    })]
  }
}{% endif %}
];
