import { DoBootstrap, Injector, NgModule } from '@angular/core';
{% if (hasProgramNode) %}import { {{ programComponentName }}Component } from './components/{{ programNodeName }}/{{ programNodeName }}.component';
{% endif %}{% if (hasApplicationNode)%}import { {{ applicationComponentName }}Component } from './components/{{ applicationNodeName }}/{{ applicationNodeName }}.component';
{% endif %}{% if (hasSmartSkill) %}import { {{ smartSkillComponentName }}Component } from './components/{{ smartSkillName }}/{{ smartSkillName }}.component';
{% endif %}{% if (hasSidebar) %}import { {{ sidebarComponentName }}Component } from './components/{{ sidebarName }}/{{ sidebarName }}.component';
{% endif %}{% if (hasOperatorScreen) %}import { {{ operatorScreenComponentName }}Component } from './components/{{ operatorScreenName }}/{{ operatorScreenName }}.component';
{% endif %}import { UIAngularComponentsModule } from '@universal-robots/ui-angular-components';
import { BrowserModule } from '@angular/platform-browser';
import { createCustomElement } from '@angular/elements';
import { HttpBackend, HttpClientModule } from '@angular/common/http';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import {MultiTranslateHttpLoader} from 'ngx-translate-multi-http-loader';
import { PATH } from '../generated/contribution-constants';
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";

export const httpLoaderFactory = (http: HttpBackend) =>
    new MultiTranslateHttpLoader(http, [
        { prefix: PATH + '/assets/i18n/', suffix: '.json' },
        { prefix: './ui/assets/i18n/', suffix: '.json' },
    ]);

@NgModule({
  declarations: [
    {% if (hasProgramNode) %}        {{ programComponentName }}Component{% if (hasApplicationNode or hasSmartSkill or hasSidebar or hasOperatorScreen) %},{% endif %}
{% endif %} {% if (hasApplicationNode) %}        {{ applicationComponentName }}Component{% if (hasSmartSkill or hasSidebar or hasOperatorScreen) %},{% endif %}
{% endif %} {% if (hasSmartSkill) %}        {{ smartSkillComponentName }}Component{% if (hasSidebar or hasOperatorScreen) %},{% endif %}
{% endif %} {% if (hasSidebar) %}        {{ sidebarComponentName }}Component{% if hasOperatorScreen %},{% endif %}
{% endif %} {% if (hasOperatorScreen) %}        {{ operatorScreenComponentName }}Component
{% endif %}  ],
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        UIAngularComponentsModule,
        HttpClientModule,
        TranslateModule.forRoot({
            loader: { provide: TranslateLoader, useFactory: httpLoaderFactory, deps: [HttpBackend] },
            useDefaultLang: false,
        })
    ],
    providers: [],
})

export class AppModule implements DoBootstrap {
    constructor(private injector: Injector) {
    }

  ngDoBootstrap() {
    {% if (hasProgramNode) %}        const {{ programComponentName | lower }}Component = createCustomElement({{ programComponentName }}Component, {injector: this.injector});
    customElements.define('{{ programTagName }}', {{ programComponentName | lower}}Component);
    {% endif %}{%if (hasApplicationNode) %}        const {{ applicationComponentName | lower}}Component = createCustomElement({{ applicationComponentName }}Component, {injector: this.injector});
    customElements.define('{{ applicationTagName }}', {{ applicationComponentName | lower}}Component);
    {% endif %}{%if (hasSmartSkill) %}        const {{ smartSkillComponentName | lower}}Component = createCustomElement({{ smartSkillComponentName }}Component, {injector: this.injector});
    customElements.define('{{ smartSkillTagName }}', {{ smartSkillComponentName | lower}}Component);
    {% endif %}{%if (hasSidebar) %}        const {{ sidebarComponentName | lower}}Component = createCustomElement({{ sidebarComponentName }}Component, {injector: this.injector});
    customElements.define('{{ sidebarTagName }}', {{ sidebarComponentName | lower}}Component);
    {% endif %}{%if (hasOperatorScreen) %}        const {{ operatorScreenComponentName | lower}}Component = createCustomElement({{ operatorScreenComponentName }}Component, {injector: this.injector});
    customElements.define('{{ operatorScreenTagName }}', {{ operatorScreenComponentName | lower}}Component);
    {% endif %}

    }

  // This function is never called, because we don't want to actually use the workers, just tell webpack about them
  registerWorkersWithWebPack() {
    {% if (hasApplicationNode) %}        new Worker(new URL('./components/{{ applicationNodeName }}/{{ applicationNodeName }}.behavior.worker.ts'
      /* webpackChunkName: "{{ applicationNodeName}}.worker" */, import.meta.url), {
      name: '{{ applicationNodeName}}',
      type: 'module'
    });
    {% endif %} {% if (hasProgramNode) %}       new Worker(new URL('./components/{{ programNodeName }}/{{ programNodeName }}.behavior.worker.ts'
      /* webpackChunkName: "{{ programNodeName}}.worker" */, import.meta.url), {
      name: '{{ programNodeName}}',
      type: 'module'
    });
    {% endif %} {% if (hasSmartSkill) %}        new Worker(new URL('./components/{{ smartSkillName }}/{{ smartSkillName }}.behavior.worker.ts'
      /* webpackChunkName: "{{ smartSkillName}}.worker" */, import.meta.url), {
      name: '{{ smartSkillName}}',
      type: 'module'
    });
    {% endif %} {% if (hasSidebar) %}        new Worker(new URL('./components/{{ sidebarName }}/{{ sidebarName }}.behavior.worker.ts'
      /* webpackChunkName: "{{ sidebarName }}.worker" */, import.meta.url), {
      name: '{{ sidebarName }}',
      type: 'module'
    });
    {% endif %} {% if (hasOperatorScreen) %}        new Worker(new URL('./components/{{ operatorScreenName }}/{{ operatorScreenName }}.behavior.worker.ts'
      /* webpackChunkName: "{{ operatorScreenName }}.worker" */, import.meta.url), {
      name: '{{ operatorScreenName }}',
      type: 'module'
    });
    {% endif %}
    }
}

