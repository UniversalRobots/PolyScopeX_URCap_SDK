const api = require('@universal-robots/contribution-api');

const behaviors = {
  factory: createOperatorScreenInstance,
};

// factory is required
async function createOperatorScreenInstance() {
  return {
    type: '{{ operatorScreenTagName }}',
    name: '{{ operatorScreenTitle }}',
    parameters: {},
  };
}


api.registerOperatorScreenBehavior(behaviors);
