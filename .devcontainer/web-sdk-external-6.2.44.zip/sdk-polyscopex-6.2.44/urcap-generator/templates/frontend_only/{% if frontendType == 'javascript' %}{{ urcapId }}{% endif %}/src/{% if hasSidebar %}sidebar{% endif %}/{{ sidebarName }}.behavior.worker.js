const api = require('@universal-robots/contribution-api');

const behaviors = {
  factory: createSidebarInstance,
};

// factory is required
async function createSidebarInstance() {
  return {
    type: '{{ sidebarTagName }}',
    name: '{{ sidebarTitle }}',
    parameters: {},
  };
}


api.registerSidebarBehavior(behaviors);
