# Docker {% if includeRos %}ROS2 Node {% endif %}contribution

This project is a template example of a URCap Docker {% if includeRos %}ROS2 Node {% endif %}Contribution

### Installation
To install the contribution type:

`$ npm install`

### Build
To build the contribution type:

`$ npm run build`

### Deploy
To deploy the contribution to the simulator type:

`$ npm run install-urcap`

## Further help

Get more help from the included SDK documentation.
