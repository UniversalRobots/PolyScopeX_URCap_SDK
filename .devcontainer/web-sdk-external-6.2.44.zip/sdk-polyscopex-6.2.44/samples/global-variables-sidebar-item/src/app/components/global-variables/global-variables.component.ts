import {
  ChangeDetectionStrategy,
  Component,
  effect,
  inject,
  input,
  InputSignal,
} from "@angular/core";
import { toObservable, toSignal } from "@angular/core/rxjs-interop";
import { TranslateService } from "@ngx-translate/core";
import {
  GlobalVariable,
  RobotSettings,
  SidebarItemPresenter,
  SidebarPresenterAPI,
} from "@universal-robots/contribution-api";
import { filter, map, switchMap } from "rxjs";

interface SignalSidebarItemPresenter
  extends Omit<SidebarItemPresenter, "robotSettings" | "presenterAPI"> {
  robotSettings: InputSignal<RobotSettings | undefined>;
  presenterAPI: InputSignal<SidebarPresenterAPI | undefined>;
}
@Component({
  selector: "ur-global-variables",
  templateUrl: "./global-variables.component.html",
  styleUrls: ["./global-variables.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: false,
})
export class GlobalVariablesComponent implements SignalSidebarItemPresenter {
  protected readonly translateService = inject(TranslateService);

  readonly robotSettings = input<RobotSettings | undefined>();
  readonly presenterAPI = input<SidebarPresenterAPI | undefined>();

  public variables = toSignal(
    toObservable(this.presenterAPI).pipe(
      filter((api) => !!api), // proceed when the API is ready
      switchMap((api: SidebarPresenterAPI) =>
        api.symbolService.globalVariables()
      ),
      map((variables: GlobalVariable[]) => [...variables].sort(this.sorter)),
      map((variables: GlobalVariable[]) =>
        variables.map((variable: GlobalVariable) => ({
          ...variable,
          value: this.processValue(variable.value),
        }))
      )
    )
  );

  readonly onCreateComponent = effect(() => {
    const language = this.robotSettings()?.language;
    if (language) {
      this.translateService.use(language);
    }
    this.translateService.setDefaultLang("en");
  });

  private readonly sorter = (a: GlobalVariable, b: GlobalVariable) => {
    const nameA = a.name.toLocaleUpperCase();
    const nameB = b.name.toLocaleUpperCase();
    return nameA.localeCompare(nameB);
  };

  private processValue(value: string) {
    if (value.startsWith("p[") || value.startsWith("[")) {
      return value.split(",").join(", ");
    }
    return value;
  }
}
