import {
  registerSidebarBehavior,
  SidebarItemBehaviors,
} from "@universal-robots/contribution-api";

const behaviors: SidebarItemBehaviors = {
  factory: () => {
    return {
      type: "global-variables-sidebar-item",
      version: "1.0.0",
    };
  },
};

registerSidebarBehavior(behaviors);
