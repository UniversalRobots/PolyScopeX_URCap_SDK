# Angular contribution

This project contains an example of a URCap Sidebar Item Contribution.
When running a program, this example displays a list of the global variables in the sidebar.

The sidebar is designed to contain content that needs quick selection access alongside the main content. 
Functioning as a persistent drawer, the user can toggle it open or closed.
Developers can contribute content to the sidebar using the Sidebar Item Contribution type.

Refer to the Sidebar Items contribution section in the [official documentation](https://docs.universal-robots.com/PolyScopeX_SDK_Documentation) for more information.

### Installation

To install the contribution type:

`$ npm install`

### Build

To build the contribution type:

`$ npm run build`

### Deploy

To deploy the contribution to the simulator type:

`$ npm run install-urcap`

## Further help

Get more help from the included SDK documentation.
