import { Component } from '@angular/core';

@Component({
    selector: 'simple-operator-screen-logo',
    templateUrl: './logo.component.html',
    styleUrls: ['./logo.component.scss'],
})
export class LogoComponent {
    readonly LOGO_URL = '/universal-robots/simple-operator-screen/simple-operator-screen/assets/icons/simple-operator-screen.svg';
}
