# Angular contribution

This project contains an example of a URCap Operator Screen Contribution.
When the sample has been installed, it is possible to change
the Operator Screen from the Application menu "Operator Screen".

Refer to the Operator Screen contribution section in
the [official documentation](https://docs.universal-robots.com/PolyScopeX_SDK_Documentation) for more information.

### Installation

To install the contribution type:

`$ npm install`

### Build

To build the contribution type:

`$ npm run build`

### Deploy

To deploy the contribution to the simulator type:

`$ npm run install-urcap`

## Further help

Get more help from the included SDK documentation.
