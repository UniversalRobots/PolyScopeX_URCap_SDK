import { ChangeDetectionStrategy, ChangeDetectorRef, Component, computed, inject, OnChanges, signal, Signal, SimpleChanges, WritableSignal } from '@angular/core';
import { toObservable, toSignal } from '@angular/core/rxjs-interop';
import { TranslateService } from '@ngx-translate/core';
import { combineLatest, firstValueFrom, map, mergeMap, of, switchMap } from 'rxjs';
import {
    floatOperators,
    ProgramPresenterAPI,
    registerOperator,
    registerOperators,
    SignalDirectionEnum,
    SignalValueTypeEnum,
    Source,
    Signal as SourceSignal,
    TabInputModel,
    Time,
    Value,
    ValueRange,
} from '@universal-robots/contribution-api';
import { URPortalService, URTabInputContainerComponent } from '@universal-robots/ui-angular-components';
import {
    DropdownOption,
    SelectedInput,
    TabInputData,
    TabInputValue,
    TabInputValueType,
    TabInputVariable,
} from '@universal-robots/ui-models';
import { s } from '@universal-robots/utilities-units';
import { CommonProgramPresenterComponent } from '../common-program-presenter.component';
import { SampleWaitNode } from './wait.node';

type SourceDropdownOption = DropdownOption & { groupId: string; groupIdName: string };
@Component({
    templateUrl: './wait.component.html',
    styleUrls: ['./wait.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    standalone: false,
})
export class WaitComponent extends CommonProgramPresenterComponent<SampleWaitNode> implements OnChanges {
    translateService = inject(TranslateService);
    cd = inject(ChangeDetectorRef);
    dialogService = inject(URPortalService);

    isVariableValid: WritableSignal<boolean> = signal(true);
    localPresenterAPI = signal<ProgramPresenterAPI | undefined>(undefined);
    selectedSignalInput = signal<SampleWaitNode['parameters']['signalInput'] | undefined>(undefined);
    selectedSourceSignal = computed(() =>
        this.signals()?.find((sourceSignal) => sourceSignal.signalID === this.selectedSignalInput()?.signalID),
    );
    selectedSourceOption = computed(() => this.sourcesOptions()?.find((option) => option.value === this.selectedSignalInput()?.sourceID));

    // RegisterOpereator dropdown selection
    registerOperator = computed(() => {
        const valueType = this.selectedSignalType();
        const signalValueType = this.selectedSignalInput()?.signalValueType;
        if (valueType !== signalValueType) {
            return undefined;
        }
        return this.selectedSignalInput()?.registerOperator;
    });

    // Signal value input
    selectedValueOption = computed(() => {
        const { value } = this.selectedSignalInput() ?? {};
        const option = this.digitalValueOptions().find((option) => {
            if (option.value === value) {
                return option;
        }
        });
        if (option) {
            return option;
        }
        if (value) {
            return {
                label: `${value}`,
                value: value,
                invalid: this.isVarSuppressed(value as string),
            };
        }
    });

    selectedSignalTabOption = computed(() => {
        // REGISTER & FLOAT = Value ({value, unit})
        const value = (this.selectedSignalInput()?.value as Value)?.value ?? this.selectedSignalInput()?.value ?? '';

        return {
            selectedType: this.selectedSignalInput()?.selectedType,
            value,
        };
    });

    sourceNodeLabels: Signal<{ [groupId: string]: string }> = toSignal(
        toObservable(this.localPresenterAPI).pipe(switchMap((presenterAPI) => presenterAPI?.sourceService.sourceNodeLabels() ?? of({}))),
        { initialValue: {} },
    );
    sourcesOptions = computed(() => {
        const options: Array<SourceDropdownOption> = [];
        Object.entries(this.sources()).forEach(([groupId, sources]) => {
            options.push(
                ...sources.map((source) => ({
                    label: groupId === 'robot' ? this.translateService.instant(source.sourceID) : source.name || source.sourceID,
                    value: source.sourceID,
                    groupId,
                    groupIdName:
                        groupId === 'robot'
                            ? this.translateService.instant(`communication.nodes.robot.title`)
                            : this.sourceNodeLabels()[groupId] || groupId,
                })),
            );
        });
        return options;
    });
    sources: Signal<{ [groupId: string]: Array<Source> }> = toSignal(
        toObservable(this.localPresenterAPI).pipe(
            switchMap((presenterAPI) => {
                if (presenterAPI) {
                    return presenterAPI.sourceService.sources({
                        direction: SignalDirectionEnum.IN,
                    });
                }
                return of({});
            }),
        ),
        { initialValue: {} },
    );
    signals = toSignal(
        combineLatest([toObservable(this.selectedSignalInput), toObservable(this.localPresenterAPI)]).pipe(
            mergeMap(([selectedSignalInput, presenterAPI]) => {
                if (!selectedSignalInput) {
                    return [];
                }
                const { groupId, sourceID } = selectedSignalInput;
                if (presenterAPI && groupId && sourceID) {
                    return firstValueFrom(
                        presenterAPI.sourceService.sourceSignals(groupId, sourceID, {
                        direction: SignalDirectionEnum.IN,
                        }),
                    );
                }
                return [];
            }),
            map((signals) => {
                return signals.filter((signal) =>
                    [SignalValueTypeEnum.BOOLEAN, SignalValueTypeEnum.FLOAT, SignalValueTypeEnum.REGISTER].some(
                        (valueType) => valueType === signal.valueType,
                    ),
                );
            }),
        ),
    );
    domains: Signal<Record<string, ValueRange> | undefined> = toSignal(
        combineLatest([toObservable(this.selectedSignalInput), toObservable(this.localPresenterAPI)]).pipe(
            mergeMap(([selectedSignalInput, presenterAPI]) => {
                const sourceId = selectedSignalInput?.sourceID;
                if (presenterAPI && sourceId) {
                    return presenterAPI.sourceService.getSignalsDomainData(selectedSignalInput.groupId || '', sourceId);
                }
                return of({});
            }),
        ),
    );
    selectedSignalType = computed(
        () => this.signals()?.find((signal) => signal.signalID === this.selectedSignalInput()?.signalID)?.valueType,
    );

    variables = toSignal(
        toObservable(this.localPresenterAPI).pipe(switchMap((presenterAPI) => presenterAPI?.symbolService.getVariables() ?? [])),
        { initialValue: [] },
    );

    tabInputVariables = computed(() => {
        return this.variables().map(
            (variable) =>
                ({
                    name: variable.name,
                    suppressed: variable.suppressed ?? false,
                    valueType: variable.valueType,
                }) as TabInputVariable,
        );
    });

    getAnalogUnit = computed(() => {
        this.selectedSignalTabOption();
        const domain = getSignalValueRange(this.domains(), this.contributedNode.parameters.signalInput?.signalID);
        if (domain !== undefined && this.selectedSignalInput()?.selectedType === 'VALUE') {
            return domain.unit;
        }
        return undefined;
    });

    readonly s = s;
    private readonly SINGLE_DAY_IN_SECONDS = 86400;
    readonly TIME_CONSTRAINTS = {
        lowerLimit: 0.01,
        upperLimit: this.SINGLE_DAY_IN_SECONDS,
        unit: s.label,
    };

    public timeValidators = [(val: number) => this.validateTime(val)];

    public SignalValueType = SignalValueTypeEnum;
    public typeSelection: DropdownOption[] = [];
    public valueValidators = [(val: number) => this.validateAnalogValue(val)];
    readonly floatOperators = floatOperators;
    readonly registerOperators = registerOperators;

    override onSetRobotSettings() {
        super.onSetRobotSettings();
        this.setOptions();
    }

    onUseVariable = () => {
        this.setTabInputValue();
    };

    private setOptions() {
        this.typeSelection = [
            {
                label: this.translateService.instant('presenter.wait.label.time'),
                value: 'time',
            },
            {
                label: this.translateService.instant('presenter.wait.label.signal_input'),
                value: 'signalInput',
            },
        ];
    }
    onLangChange = toSignal(this.translateService.onLangChange);

    digitalValueOptions = computed(() => {
        this.onLangChange();

        let options: Array<DropdownOption> = [
            {
                label: this.translateService.instant('high'),
                value: true,
            },
            {
                label: this.translateService.instant('low'),
                value: false,
            },
        ];
        const value = this.selectedSignalInput()?.value;
        if (this.selectedSignalInput()?.signalValueType === SignalValueTypeEnum.CUSTOM && value) {
            options = options.concat({
                label: `${value}`,
                value: value,
                invalid:
                    this.contributedNode.parameters.signalInput?.selectedType === 'EXPRESSION'
                        ? false
                        : this.isVarSuppressed(value as string) || !this.varExists(value as string),
            });
    }
        return options;
    });

    selectedSignalValueType = computed(() => {
        return this.typeMap[this.selectedSignalType() || 'DEFAULT'];
    });

    private typeMap: { [key: string]: TabInputValueType[] } = {
        BOOLEAN: ['boolean'],
        FLOAT: ['integer', 'float'],
        REGISTER: ['integer', 'float'],
        DEFAULT: ['integer', 'float', 'string', 'boolean'],
    };

    async ngOnChanges(changes: SimpleChanges) {
        await super.ngOnChanges(changes);
        if (changes.contributedNode?.isFirstChange()) {
            await this.initParamType();
            this.cd.detectChanges();
        }

        if (changes.presenterAPI) {
            this.localPresenterAPI.set(changes.presenterAPI.currentValue);
        }

        if (changes.contributedNode) {
            this.selectedSignalInput.set(changes.contributedNode.currentValue.parameters.signalInput);
        }
    }

    private async initParamType() {
        if (this.contributedNode.parameters.type === 'signalInput') {
            delete this.contributedNode.parameters.time;

            if (!this.contributedNode.parameters.signalInput) {
                this.contributedNode.parameters.signalInput = {};
                return;
            }
        } else if (this.contributedNode.parameters.type === 'time') {
            delete this.contributedNode.parameters.signalInput;
            if (!this.contributedNode.parameters.time) {
                this.contributedNode.parameters.time = new TabInputModel<Time>(
                    {
                        value: 1,
                        unit: s.label,
                    },
                    SelectedInput.VALUE,
                    1,
                );
            }
        }
    }

    async setType({ value }: DropdownOption) {
        if (value !== this.contributedNode.parameters.type) {
            this.contributedNode.parameters.type = value as 'time' | 'signalInput';
            await this.initParamType();
            this.saveNode();
        }
    }

    public getTime() {
        if (!this.contributedNode.parameters.time)
            return {
                selectedType: SelectedInput.VALUE,
                value: '1',
            };

        return TabInputModel.getTabInputValue<Time>(this.contributedNode.parameters.time);
    }

    public setTime($event: TabInputValue): void {
        if (this.contributedNode.parameters.time) {
            const time = this.contributedNode.parameters.time;
            TabInputModel.setTabInputValue(time, $event);
            time.entity.value = Number($event.value);
            this.contributedNode.parameters.time = time;
            this.saveNode();
        }
    }

    public async setSourceID($event: SourceDropdownOption) {
        if (!this.contributedNode.parameters.signalInput) {
            return;
        }
        this.contributedNode.parameters.signalInput.sourceID = $event.value as string;
        this.contributedNode.parameters.signalInput.groupId = $event.groupId;
        this.contributedNode.parameters.signalInput.signalID = undefined;
        this.contributedNode.parameters.signalInput.value = undefined;

        this.saveNode();
    }

    setSignalID($event: SourceSignal) {
        if (!this.contributedNode.parameters.signalInput) {
            return;
        }
        this.contributedNode.parameters.signalInput.signalID = $event.signalID;
        switch ($event.valueType) {
            case SignalValueTypeEnum.BOOLEAN:
                this.contributedNode.parameters.signalInput.value = true;
                this.contributedNode.parameters.signalInput.registerOperator = undefined;
                this.contributedNode.parameters.signalInput.floatOperator = undefined;
                this.contributedNode.parameters.signalInput.selectedType = undefined;
                break;

            case SignalValueTypeEnum.FLOAT:
                {
                  this.contributedNode.parameters.signalInput.floatOperator = '>';
                  const signalDomainData = getSignalValueRange(this.domains(), $event.signalID);
                  this.contributedNode.parameters.signalInput.selectedType = SelectedInput.VALUE;
                  if (signalDomainData !== undefined) {
                    this.contributedNode.parameters.signalInput.value = {
                      value: signalDomainData.min,
                      unit: signalDomainData.unit,
                    };
                  } else {
                      this.contributedNode.parameters.signalInput.value = 0;
                  }
                }
                break;

            case SignalValueTypeEnum.REGISTER:
                this.contributedNode.parameters.signalInput.registerOperator = '<';
                this.contributedNode.parameters.signalInput.value = 0;
                this.contributedNode.parameters.signalInput.selectedType = undefined;

              break;
        }
        this.contributedNode.parameters.signalInput.signalValueType = $event.valueType;
        this.isVariableValid.set(true);

        this.saveNode();
    }

    public signalLabelFactory = (signal: SourceSignal) => {
        return signal?.name || signal.signalID;
    };

    setAnalogTabInput($event: TabInputValue) {
        if (this.contributedNode.parameters.signalInput === undefined) {
            return;
        }

        const domain = getSignalValueRange(this.domains(), this.contributedNode.parameters.signalInput?.signalID);

        if (domain !== undefined && $event.selectedType === 'VALUE') {
            this.contributedNode.parameters.signalInput.value = { value: Number($event.value), unit: domain.unit };
            } else {
            this.contributedNode.parameters.signalInput.value = $event.value;
            }

        this.contributedNode.parameters.signalInput.selectedType = $event.selectedType;
        this.saveNode();
    }

    setRegisterValue($event: TabInputValue) {
        if (this.contributedNode.parameters.signalInput) {
            this.contributedNode.parameters.signalInput.value = $event.value;
            this.contributedNode.parameters.signalInput.signalValueType = SignalValueTypeEnum.REGISTER;
            this.contributedNode.parameters.signalInput.selectedType = $event.selectedType;
            this.saveNode();
        }
    }

    isVarSuppressed(searchName: string): boolean {
        return this.tabInputVariables().some((item) => item.name === searchName && item.suppressed);
    }

    varExists(searchName: string): boolean {
        return this.tabInputVariables().some((item) => item.name === searchName);
        }

    setDigitalValue($event: DropdownOption) {
        const dropDownOption = $event as DropdownOption;

        if (typeof dropDownOption.value === 'boolean') {
            this.contributedNode.parameters.signalInput = {
                ...this.contributedNode.parameters.signalInput,
                value: dropDownOption.value,
                signalValueType: SignalValueTypeEnum.BOOLEAN,
                selectedType: undefined,
            };

        this.saveNode();
    }
    }

    createTabInputData(): TabInputData {
        return {
            inputLabel: '',
            placeholder: '',
            translations: {},
            type: 'text',
            label: '',
            valueType: ['boolean'],
            variables: this.tabInputVariables().length > 0 ? this.tabInputVariables() : [],
            tabInputValue: {
                selectedType: this.selectedSignalInput()?.selectedType ?? SelectedInput.VARIABLE,
                value:
                    this.selectedSignalInput()?.signalValueType === SignalValueTypeEnum.CUSTOM
                        ? this.selectedSignalInput()?.value
                        : (undefined as any),
            },
            tabs: [SelectedInput.VARIABLE, SelectedInput.EXPRESSION],
        };
        }

    async setTabInputValue() {
        const inputData = this.createTabInputData();
        const { reason, returnData } = await firstValueFrom(
            this.dialogService.open<TabInputValue>(URTabInputContainerComponent, inputData).afterClose,
        );

        if (reason === 'CONFIRMED' && this.contributedNode.parameters.signalInput) {
            this.contributedNode.parameters.signalInput.signalValueType = SignalValueTypeEnum.CUSTOM;
            this.contributedNode.parameters.signalInput.value = returnData?.value;
            this.contributedNode.parameters.signalInput.selectedType = returnData?.selectedType;

            if (returnData?.selectedType === 'EXPRESSION') {
                this.isVariableValid.set(true);
            }
        this.saveNode();
    }
    }

    public setAnalogOperator($event: string) {
        if (!this.contributedNode.parameters.signalInput) {
            return;
        }
        if ($event === '>' || $event === '<') {
            this.contributedNode.parameters.signalInput.floatOperator = $event;
            this.saveNode();
        }
    }
    public setRegisterOperator($event: registerOperator) {
        if (!this.contributedNode.parameters.signalInput) {
            return;
        }
        this.contributedNode.parameters.signalInput.registerOperator = $event;
        this.contributedNode.parameters.signalInput.signalValueType = SignalValueTypeEnum.REGISTER;
        this.saveNode();
    }

    private getDomainDataErrorString(val: number, constraints: ValueRange): string {
        return this.getRangeErrorString(val, { lowerLimit: constraints.min, upperLimit: constraints.max, unit: constraints.unit });
    }

    public validateAnalogValue(val: number) {
        const signalDomainData = getSignalValueRange(this.domains(), this.contributedNode.parameters.signalInput?.signalID);
        if (signalDomainData !== undefined) {
            return this.getDomainDataErrorString(val, signalDomainData);
        }
        return undefined;
    }

    public validateTime(val: number) {
        return this.getRangeErrorString(val, this.TIME_CONSTRAINTS);
    }
}

const getSignalValueRange = (domains: Record<string, ValueRange> | undefined, signalID: string | undefined) => {
    if (signalID && domains && Object.hasOwnProperty.call(domains, signalID)) {
        return Reflect.get(domains, signalID) as ValueRange;
    }
    return undefined;
};
