import { ApplicationNodeType, EndEffectorNode, ProgramBehaviorAPI, TCPName } from '@universal-robots/contribution-api';

export async function updateTCPReference(tcpName: TCPName): Promise<TCPName | undefined> {
    // A reference to a TCP exists. If the TCP with this exact id exists in the end effectors of this program, use that, ie. do nothing.
    // If not, try to find the TCP in the current end effectors by name.
    // Finally, if the TCP is not found, do nothing and let the reference be invalid
    const api = new ProgramBehaviorAPI(self);
    const eeNode = (await api.applicationService.getApplicationNode(ApplicationNodeType.END_EFFECTOR)) as EndEffectorNode;
    if (!eeNode.endEffectors.flatMap((ee) => ee.tcps).some((tcp) => tcp.id === tcpName.id)) {
        const tcp = eeNode.endEffectors.flatMap((ee) => ee.tcps).find((tcp) => tcp.name === tcpName.name);
        if (!tcp) {
            return;
        }
        return { id: tcp.id, name: tcp.name };
    }
}
