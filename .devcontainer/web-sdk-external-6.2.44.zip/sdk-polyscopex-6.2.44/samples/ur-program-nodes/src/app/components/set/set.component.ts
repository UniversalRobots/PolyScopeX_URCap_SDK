import {
    ChangeDetectionStrategy,
    ChangeDetectorRef,
    Component,
    computed,
    inject,
    OnChanges,
    Signal,
    signal,
    SimpleChanges,
    WritableSignal,
} from '@angular/core';
import { toObservable, toSignal } from '@angular/core/rxjs-interop';
import { TranslateService } from '@ngx-translate/core';
import { combineLatest, firstValueFrom, map, mergeMap, of, switchMap } from 'rxjs';
import {
    ProgramPresenterAPI,
    Signal as SourceSignal,
    SignalDirectionEnum,
    SignalValueTypeEnum,
    Source,
    Value,
    ValueRange,
    VariableValueType,
} from '@universal-robots/contribution-api';
import { URPortalService, URTabInputContainerComponent } from '@universal-robots/ui-angular-components';
import {
    DropdownOption,
    InputValidator,
    SelectedInput,
    TabInputData,
    TabInputValue,
    TabInputValueType,
    TabInputVariable,
} from '@universal-robots/ui-models';
import { CommonProgramPresenterComponent } from '../common-program-presenter.component';
import { SampleSetNode } from './set.node';

type SourceDropdownOption = DropdownOption & { groupId: string; groupIdName: string; value: string };

@Component({
    templateUrl: './set.component.html',
    styleUrls: ['./set.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    standalone: false,
})
export class SetComponent extends CommonProgramPresenterComponent<SampleSetNode> implements OnChanges {
    localPresenterAPI = signal<ProgramPresenterAPI | undefined>(undefined);
    selectedSignalOutput = signal<SampleSetNode['parameters']['signalOutput'] | undefined>(undefined);
    isValid: WritableSignal<boolean> = signal(true);
    variableNameValidator?: InputValidator<string>;
    selectedSourceSignal = computed(() =>
        this.signals()?.find((sourceSignal) => sourceSignal.signalID === this.selectedSignalOutput()?.signalID),
    );
    selectedSourceOption = computed(() => this.sourcesOptions()?.find((option) => option.value === this.selectedSignalOutput()?.sourceID));
    sourcesOptions = computed(() => {
        return Object.entries(this.sources()).flatMap(([groupId, sources]) => {
            return sources.map((source) => ({
                    label: groupId === 'robot' ? this.translateService.instant(source.sourceID) : source.name || source.sourceID,
                    value: source.sourceID,
                    groupId,
                    groupIdName:
                        groupId === 'robot'
                            ? this.translateService.instant(`communication.nodes.robot.title`)
                            : this.sourceNodeLabels()[groupId] || groupId,
            }));
        });
    });

    sourceNodeLabels: Signal<{ [groupId: string]: string }> = toSignal(
        toObservable(this.localPresenterAPI).pipe(switchMap((presenterAPI) => presenterAPI?.sourceService.sourceNodeLabels() ?? of({}))),
        { initialValue: {} },
    );

    variables = toSignal(
        toObservable(this.localPresenterAPI).pipe(switchMap((presenterAPI) => presenterAPI?.symbolService.variables() ?? [])),
        { initialValue: [] },
    );

    tabInputVariables = computed(() => {
        return this.variables()
            .filter((variable) => variable.valueType !== VariableValueType.FRAME)
            .map(
                (variable) =>
                    ({
                        name: variable.name,
                        suppressed: variable.suppressed ?? false,
                        valueType: variable.valueType,
                    }) as TabInputVariable,
            );
        });

    onLangChange = toSignal(this.translateService.onLangChange);

    selectedSignalValueType = computed(() => {
        return this.typeMap[this.selectedSignalType() || 'DEFAULT'];
    });

    private typeMap: { [key: string]: TabInputValueType[] } = {
        BOOLEAN: ['boolean'],
        FLOAT: ['integer', 'float'],
        REGISTER: ['integer', 'float'],
        DEFAULT: ['integer', 'float', 'string', 'boolean'],
    };

    sources: Signal<{ [groupId: string]: Array<Source> }> = toSignal(
        toObservable(this.localPresenterAPI).pipe(
            switchMap((presenterAPI) => {
                if (presenterAPI) {
                    return presenterAPI.sourceService.sources({
                        direction: SignalDirectionEnum.OUT,
                    });
                }
                return of({});
            }),
        ),
        { initialValue: {} },
    );
    signals = toSignal(
        combineLatest([toObservable(this.selectedSignalOutput), toObservable(this.localPresenterAPI)]).pipe(
            mergeMap(([selectedSignalOutput, presenterAPI]) => {
                if (!selectedSignalOutput) {
                    return [];
                }
                const { groupId, sourceID } = selectedSignalOutput;
                if (presenterAPI && groupId && sourceID) {
                    return firstValueFrom(
                        presenterAPI.sourceService.sourceSignals(groupId, sourceID, {
                        direction: SignalDirectionEnum.OUT,
                        }),
                    );
                }
                return [];
            }),
            map((signals) => {
                return signals.filter((signal) =>
                    [SignalValueTypeEnum.BOOLEAN, SignalValueTypeEnum.FLOAT, SignalValueTypeEnum.REGISTER].some(
                        (valueType) => valueType === signal.valueType,
                    ),
                );
            }),
            mergeMap((signals) => {
                return this.filterSafetyOutputs(signals);
            }),
        ),
    );
    domains: Signal<Record<string, ValueRange> | undefined> = toSignal(
        combineLatest([toObservable(this.selectedSignalOutput), toObservable(this.localPresenterAPI)]).pipe(
            mergeMap(([selectedSignalInput, presenterAPI]) => {
                const sourceId = selectedSignalInput?.sourceID;
                if (presenterAPI && sourceId) {
                    return presenterAPI.sourceService.getSignalsDomainData(selectedSignalInput.groupId || '', sourceId);
                }
                return of({});
            }),
        ),
    );
    selectedSignalType = computed(
        () => this.signals()?.find((signal) => signal.signalID === this.selectedSignalOutput()?.signalID)?.valueType,
    );

    selectedSignalOption = computed(() => {
        const { value } = this.selectedSignalOutput() ?? {};
        const option = this.digitalValueOptions().find((option) => {
            if (option.value === value) {
                return option;
            }
        });
        if (option) {
            return option;
        }
        if (value) {
            return {
                label: `${value}`,
                value: value,
                invalid: this.isVarSuppressed(value as string),
            };
        }
    });

    selectedSignalTabOption = computed(() => {
        // REGISTER & FLOAT = Value ({value, unit})
        const value = (this.selectedSignalOutput()?.value as Value)?.value ?? this.selectedSignalOutput()?.value ?? 'undefined';
        return {
            selectedType: this.selectedSignalOutput()?.selectedType,
            value,
        };
    });

    isVariableValid: WritableSignal<boolean> = signal(true);

    public SignalValueType = SignalValueTypeEnum;
    public valueValidators = [this.validateValue.bind(this)];

    public digitalValueOptions = computed(() => {
        this.onLangChange();
        let options: Array<DropdownOption> = [
            {
                label: this.translateService.instant('high'),
                value: true,
            },
            {
                label: this.translateService.instant('low'),
                value: false,
            },
        ];
        const value = this.selectedSignalOutput()?.value;
        if (this.selectedSignalOutput()?.signalValueType === SignalValueTypeEnum.CUSTOM && value) {
            options = options.concat({
                label: `${value}`,
                value: value,
                invalid:
                    this.contributedNode.parameters.signalOutput?.selectedType === 'EXPRESSION'
                        ? false
                        : this.isVarSuppressed(value as string) || !this.varExists(value as string),
            });
        }
        return options;
    });

    translateService = inject(TranslateService);
    cd = inject(ChangeDetectorRef);
    dialogService = inject(URPortalService);

    public async ngOnChanges(changes: SimpleChanges) {
        await super.ngOnChanges(changes);

        if (changes.presenterAPI) {
            this.localPresenterAPI.set(changes.presenterAPI.currentValue);
        }

        if (changes.contributedNode) {
            this.selectedSignalOutput.set(changes.contributedNode.currentValue.parameters.signalOutput);

            //Validate the dropdown for the custom dropdown
            if (
                changes.contributedNode.currentValue.parameters.signalOutput.selectedType === 'VARIABLE' &&
                changes.contributedNode.currentValue.parameters.signalOutput.signalValueType === SignalValueTypeEnum.CUSTOM
            ) {
                const valid = await this.localPresenterAPI()?.symbolService.isValidVariable(
                    changes.contributedNode.currentValue.parameters.signalOutput.value,
                    ['boolean'],
                );
                if (valid !== undefined) {
                    this.isVariableValid.set(valid);
                }
            }
        }
    }

    public signalLabelFactory = (signal: SourceSignal) => {
        return signal?.name || signal.signalID;
    };

    //using arrow function to get the context correct.
    public digitalValueFactory = (option: any) => {
        return option.value === 'custom' && this.selectedSignalOutput()?.signalValueType === SignalValueTypeEnum.CUSTOM
            ? this.selectedSignalOutput()?.value
            : option.label;
    };

    public async setSourceID($event: SourceDropdownOption) {
        if (!this.contributedNode.parameters.signalOutput) {
            return;
        }
        this.contributedNode.parameters.signalOutput.sourceID = $event.value;
        this.contributedNode.parameters.signalOutput.groupId = $event.groupId;
        this.contributedNode.parameters.signalOutput.signalID = undefined;
        this.contributedNode.parameters.signalOutput.value = undefined;
        this.saveNode();
    }

    public setSignalID($event: SourceSignal) {
        if (!this.contributedNode.parameters.signalOutput) {
            return;
        }
        this.contributedNode.parameters.signalOutput.signalID = $event.signalID;
        this.contributedNode.parameters.signalOutput.signalValueType = $event.valueType;

        this.isVariableValid.set(true);
        this.resetSignalOutputValue($event.valueType, $event.signalID);
        this.saveNode();
    }

    private resetSignalOutputValue(valueType: SignalValueTypeEnum, signalID: string) {
        if (!this.contributedNode.parameters.signalOutput) {
            return;
        }
        const domain = getSignalValueRange(this.domains(), signalID);
        this.contributedNode.parameters.signalOutput.selectedType = undefined;
        this.contributedNode.parameters.signalOutput.value = 0;

        if (valueType === SignalValueTypeEnum.FLOAT) {
            this.contributedNode.parameters.signalOutput.selectedType = 'VALUE';
                if (domain !== undefined) {
                    this.contributedNode.parameters.signalOutput.value = {
                        value: domain.min,
                        unit: domain.unit,
                    };
                }
            }

        if (valueType === SignalValueTypeEnum.BOOLEAN) {
                this.contributedNode.parameters.signalOutput.value = true;
        }
    }

    public setValue($event: TabInputValue) {
        if (this.selectedSignalType() === SignalValueTypeEnum.REGISTER) {
            this.setRegisterValue($event);
            return;
        }
        this.setAnalogTabInput($event);
    }

    private setAnalogTabInput($event: TabInputValue) {
        if (this.contributedNode.parameters.signalOutput === undefined) {
            return;
        }

            const domain = getSignalValueRange(this.domains(), this.contributedNode.parameters.signalOutput?.signalID);
        if (domain !== undefined && $event.selectedType === 'VALUE') {
            this.contributedNode.parameters.signalOutput.value = { value: Number($event.value), unit: domain.unit };
            } else {
            this.contributedNode.parameters.signalOutput.value = $event.value;
            }

            this.contributedNode.parameters.signalOutput.selectedType = $event.selectedType;
            this.saveNode();
        }

    public setRegisterValue($event: TabInputValue) {
        if (this.contributedNode.parameters.signalOutput) {
            this.contributedNode.parameters.signalOutput.value = $event.value;
            this.contributedNode.parameters.signalOutput.selectedType = $event.selectedType;
            this.saveNode();
        }
    }

    private createTabInputData(): TabInputData {
        return {
            inputLabel: '',
            placeholder: '',
            translations: {},
            type: 'text',
            label: '',
            valueType: ['boolean'],
            variables: this.tabInputVariables().length > 0 ? this.tabInputVariables() : [],
            tabInputValue: {
                selectedType: this.selectedSignalOutput()?.selectedType ?? SelectedInput.VARIABLE,
                value:
                    this.selectedSignalOutput()?.signalValueType === SignalValueTypeEnum.CUSTOM
                        ? this.selectedSignalOutput()?.value
                        : (undefined as any),
            },
            tabs: [SelectedInput.VARIABLE, SelectedInput.EXPRESSION],
        };
    }

    async setTabInputValue() {
        const inputData = this.createTabInputData();
        const { reason, returnData } = await firstValueFrom(
            this.dialogService.open<TabInputValue>(URTabInputContainerComponent, inputData).afterClose,
        );

        if (reason === 'CONFIRMED' && this.contributedNode.parameters.signalOutput) {
            this.contributedNode.parameters.signalOutput.signalValueType = SignalValueTypeEnum.CUSTOM;
            this.contributedNode.parameters.signalOutput.value = returnData?.value;
            this.contributedNode.parameters.signalOutput.selectedType = returnData?.selectedType;
            if (returnData?.selectedType === 'EXPRESSION') {
                this.isVariableValid.set(true);
            }
            this.saveNode();
        }
    }

    onUseVariable = () => {
        this.setTabInputValue();
    };

    private isVarSuppressed(searchName: string): boolean {
        return this.tabInputVariables().some((item) => item.name === searchName && item.suppressed);
    }

    varExists(searchName: string): boolean {
        return this.tabInputVariables().some((item) => item.name === searchName);
    }

    public async setDigitalValue($event: DropdownOption) {
        if (!this.contributedNode.parameters.signalOutput) {
            return;
        }

        if (typeof $event.value === 'boolean') {
            this.contributedNode.parameters.signalOutput = {
                ...this.contributedNode.parameters.signalOutput,
                value: $event.value,
                signalValueType: SignalValueTypeEnum.BOOLEAN,
                selectedType: undefined,
            };
        this.saveNode();
      }
    }

    private getDomainDataErrorString(val: number, constraints: ValueRange): string {
        return this.getRangeErrorString(val, {
            lowerLimit: constraints.min,
            upperLimit: constraints.max,
            unit: constraints.unit,
        });
    }

    public validateValue(val: number) {
        const signalDomainData = getSignalValueRange(this.domains(), this.contributedNode.parameters.signalOutput?.signalID);
        if (signalDomainData !== undefined) {
            return this.getDomainDataErrorString(val, signalDomainData);
        }

        return null;
    }

    public getAnalogUnit() {
        const domain = getSignalValueRange(this.domains(), this.contributedNode.parameters.signalOutput?.signalID);
        if (domain !== undefined && this.selectedSignalOutput()?.selectedType === 'VALUE') {
            return domain.unit;
        }
        return null;
    }

    private async filterSafetyOutputs(signals: SourceSignal[]): Promise<SourceSignal[]> {
        const safetyOutputs = await this.getSafetyOutputs();
        return signals.filter((signal) => !this.isSignalUsedBySafetyIOs(signal.signalID, safetyOutputs));
    }

    private async getSafetyOutputs(): Promise<{ name: string; valueA: number; valueB: number }[]> {
        const safetyIOs = await this.presenterAPI.safetyService.getIOs();
        if (safetyIOs === undefined) {
            return [];
        }
        return Object.values(safetyIOs).filter((io) => io.name.includes('Output'));
    }

    private isSignalUsedBySafetyIOs(
        signalID: string,
        safetyOutputs: {
            name: string;
            valueA: number;
            valueB: number;
        }[],
    ): boolean {
        return safetyOutputs.some((output) => {
            return 'CO ' + output.valueA === signalID || 'CO ' + output.valueB === signalID;
        });
    }
}

const getSignalValueRange = (domains: Record<string, ValueRange> | undefined, signalID: string | undefined) => {
    if (signalID && domains && Object.hasOwnProperty.call(domains, signalID)) {
        return Reflect.get(domains, signalID) as ValueRange;
    }
    return undefined;
};
