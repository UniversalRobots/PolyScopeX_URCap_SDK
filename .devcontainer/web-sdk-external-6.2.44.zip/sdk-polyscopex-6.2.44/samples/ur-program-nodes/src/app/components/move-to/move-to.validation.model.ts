import { ValidationResponse } from '@universal-robots/contribution-api';

export type MoveToValidationResponse = ValidationResponse & { fieldValidation: MoveToFieldValidation };

export interface MoveToFieldValidation {
    position: boolean;
    point: boolean;
    advanced: {
        frame: boolean;
        speed: boolean;
        acceleration: boolean;
        transform: boolean;
        tcp: boolean;
        blend: boolean;
    };
}

export const getDefaultMoveToValidation = (): MoveToFieldValidation => {
    return {
        position: true,
        point: true,
        advanced: {
            frame: true,
            blend: true,
            transform: true,
            tcp: true,
            acceleration: true,
            speed: true,
        },
    };
};
