import { SelectedType } from '@universal-robots/ui-models';
import { ProgramNode, SignalValue, SignalValueTypeEnum } from '@universal-robots/contribution-api';

export interface SampleSetNode extends ProgramNode {
    type: 'ur-sample-node-set';
    parameters: {
        signalOutput?: {
            groupId?: string;
            sourceID?: string;
            signalID?: string;
            selectedType?: SelectedType;
            value?: SignalValue;
            signalValueType?: SignalValueTypeEnum;
        };
    };
}
