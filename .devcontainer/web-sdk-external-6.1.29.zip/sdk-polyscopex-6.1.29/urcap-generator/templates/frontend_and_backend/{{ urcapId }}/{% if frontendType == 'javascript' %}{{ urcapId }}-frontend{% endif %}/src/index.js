{% if (hasApplicationNode) %}import { {{ applicationComponentName }}Component } from './application/{{ applicationNodeName }}.component';
{% endif %}{% if (hasProgramNode) %}import { {{ programComponentName }}Component } from './program/{{ programNodeName }}.component';{% endif %}
