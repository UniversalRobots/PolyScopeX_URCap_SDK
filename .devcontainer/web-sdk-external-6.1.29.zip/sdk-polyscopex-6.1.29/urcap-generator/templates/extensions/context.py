from copier_templates_extensions import ContextHook
import re


class ContextUpdater(ContextHook):
    update = False

    # These 3 must be replaced by maven's filtering
    docker_image_development="universalrobots/urcap_polyscopex_ros2:3.3.2-humble-dev"
    docker_image_runtime="universalrobots/urcap_polyscopex_ros2:3.3.2-humble-runtime"
    docker_image_proxy=""

    # camel case strings. Fx my-awesome-string -> MyAwesomeString
    def to_camelcase(self, input_str):
        input_str = input_str.strip()  # Trim whitespace
        return input_str[0].upper() + re.sub(r'-(.)', lambda x: x.group(1).upper(), input_str[1:].lower())

    # Replace hyphen (dash) with whitespace and capitalize next word
    def to_title(self, input_str):
        return ' '.join(word.capitalize() for word in input_str.replace("-", " ").split())

    # replace . and _ with -
    def to_ROS2_node_name(self, input):
        return re.sub(r'[.-]', '_', input.lower().strip())

    # replace . and - with _
    def to_tag_name(self, input):
        return re.sub(r'[._]', '-', input.lower().strip())

    def hook(self, context):

        if context.get("smartSkillName") != None: # This must be the key to the last questions asked
            BASE_TAG = self.to_tag_name(context["vendorId"]) + "-" + self.to_tag_name(context["urcapId"]) + "-"

            context["artifactId"] = context.get("urcapId")
            applicationNodeName = context.get("applicationNodeName")
            context["applicationComponentName"] = self.to_camelcase(applicationNodeName)
            context["applicationNodeTitle"] = self.to_title(applicationNodeName)
            context["applicationTagName"] = self.to_tag_name(BASE_TAG + applicationNodeName)

            programNodeName = context.get("programNodeName")
            context["programComponentName"] = self.to_camelcase(programNodeName)
            context["programNodeTitle"] = self.to_title(programNodeName)
            context["programTagName"] = self.to_tag_name(BASE_TAG + programNodeName)

            smartSkillName = context.get("smartSkillName")
            context["smartSkillComponentName"] = self.to_camelcase(smartSkillName)
            context["smartSkillTitle"] = self.to_title(smartSkillName)
            context["smartSkillTagName"] = self.to_tag_name(BASE_TAG + smartSkillName)

            if not context["includeFrontend"] and context["includeDocker"]:
                context["dockerOnly"] = True
                context["FrontendType"] = ''


            context["ros2NodeName"] = self.to_ROS2_node_name(context.get("urcapId"))
            context["ros2NodeDesc"] = context.get("urcapId")

            # TODO REMOVE WHEN MAVEN BUILDS THESE
            context["docker_developmentimage"] = self.docker_image_development
            context["docker_runtimeimage"] = self.docker_image_runtime
            context["docker_sampleproxy"] = self.docker_image_proxy

            context["frontendId"] = context.get("urcapId")+"-frontend"
            context["backendId"] = context.get("urcapId")+"-backend"

            # Choose which template subfolder to use
            if not context["includeFrontend"] and context["includeDocker"]:
                context["subdirectory"] = "backend_only"
            elif context["includeFrontend"] and not context["includeDocker"]:
                context["subdirectory"] = "frontend_only"
            else:
                context["subdirectory"] = "frontend_and_backend"
        #return context