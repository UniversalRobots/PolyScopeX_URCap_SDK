import { ProgramNode, URVariable } from '@universal-robots/contribution-api';
import { TabInputValue } from '@universal-robots/ui-models';

export interface SampleLoopNode extends ProgramNode {
    type: 'ur-sample-node-loop';
    parameters: {
        type: 'always' | 'xtimes' | 'expression';
        expression?: TabInputValue;
        loopVariable?: URVariable;
        xtimes?: number;
    };
}
