/// <reference lib="webworker" />
import {
    AdvancedTranslatedProgramLabel,
    ProgramBehaviors,
    registerProgramBehavior,
    ScriptBuilder,
    ValidationResponse,
} from '@universal-robots/contribution-api';
import { SelectedInput, TabInputValue } from '@universal-robots/ui-models';
import { SampleLoopNode } from './loop.node';

const behaviors: ProgramBehaviors<SampleLoopNode> = {
    factory: async () => {
        return {
            type: 'ur-sample-node-loop',
            version: '0.0.2',
            allowsChildren: true,
            parameters: {
                type: 'always',
                expression: {
                    value: '',
                    selectedType: SelectedInput.EXPRESSION,
                } as TabInputValue,
                xtimes: 1,
            },
        };
    },
    programNodeLabel: (node: SampleLoopNode): AdvancedTranslatedProgramLabel => {
        switch (node.parameters.type) {
            case 'always':
                return [{ type: 'secondary', translationKey: `program-node-label.loop.always` }];
            case 'xtimes':
                return [
                    {
                        type: 'secondary',
                        translationKey: `program-node-label.loop.times`,
                        interpolateParams: { xtimes: `${node.parameters.xtimes}` },
                    },
                ];
            case 'expression':
                return [
                    {
                        type: 'secondary',
                        translationKey: `program-node-label.loop.while`,
                        interpolateParams: { expression: `${node.parameters.expression?.value ?? ''}` },
                    },
                ];
            default:
                return [{ type: 'secondary', translationKey: 'program-node-label.default' }];
        }
    },
    validator: (node: SampleLoopNode): ValidationResponse => {
        switch (node.parameters.type) {
            case 'always':
                return { isValid: true };
            case 'xtimes':
                if (!node.parameters.xtimes || node.parameters.xtimes < 1 || !node.parameters.loopVariable) {
                    return { isValid: false, errorMessageKey: 'Missing required parameters' };
                }
                return { isValid: true };
            case 'expression':
                if (!node.parameters.expression?.value) {
                    return { isValid: false, errorMessageKey: 'Missing expression' };
                }
                return { isValid: true };
        }
        return { isValid: false };
    },
    generateCodeBeforeChildren: (node: SampleLoopNode): ScriptBuilder => {
        const builder = new ScriptBuilder();

        switch (node.parameters.type) {
            case 'always':
                builder.beginWhileTrue();
                break;
            case 'xtimes':
                if (node.parameters.loopVariable?.name) {
                    builder.assign(node.parameters.loopVariable.name, '0');
                    builder.beginWhile(`${node.parameters.loopVariable.name} < ${node.parameters.xtimes}`);
                }
                break;
            case 'expression':
                if (node.parameters.expression?.value !== undefined) {
                    builder.beginWhile(node.parameters.expression.value.toString());
                }
                break;
        }
        return builder;
    },
    generateCodeAfterChildren: (node: SampleLoopNode): ScriptBuilder => {
        let builder: ScriptBuilder;

        if (node.parameters.type === 'xtimes' && node.parameters.loopVariable?.name) {
            builder = new ScriptBuilder('', ScriptBuilder.SINGLE_INDENT_LEVEL);
            builder.incrementVariable(node.parameters.loopVariable.name);
            builder.endBlock();
        } else {
            builder = new ScriptBuilder('');
        }

        return builder.end();
    },
    upgradeNode: (node: SampleLoopNode): SampleLoopNode => {
        if (node.version === '0.0.1') {
            const oldExpression = (node.parameters as any).expression;
            node.parameters.expression = {
                value: oldExpression,
                selectedType: SelectedInput.EXPRESSION,
            };
            node.version = '0.0.2';
        }
        return node;
    },
};

registerProgramBehavior(behaviors);
