/// <reference lib="webworker" />
import {
    AdvancedTranslatedProgramLabel,
    ApplicationNodeType,
    FramesNode,
    NodeType,
    ProgramBehaviorAPI,
    ProgramBehaviors,
    ProgramLabel,
    registerProgramBehavior,
    ScriptBuilder,
    TabInputModel,
    ToolForceDirection,
    ToolForceFrame,
    ToolForceZeroSensor,
    TranslatedProgramLabelPart,
    ValidationResponse,
    VariableValueType,
} from '@universal-robots/contribution-api';
import { SelectedInput } from '@universal-robots/ui-models';
import { SampleToolForceNode } from './tool-force.node';

export function timeToTabModel(obj: ToolForceZeroSensor) {
    return new TabInputModel<typeof obj>(
        {
            waiting: {
                value: 0,
                unit: 's',
            },
            enabled: true,
        },
        SelectedInput.VALUE,
        obj?.waiting?.value ?? 0,
    );
}

export function frameToTabModel(toolForceFrame: ToolForceFrame) {
    return new TabInputModel<typeof toolForceFrame>(toolForceFrame, SelectedInput.VALUE, toolForceFrame?.frameName ?? '');
}

export function forceToTabModel(toolForceDirection: ToolForceDirection) {
    return new TabInputModel<typeof toolForceDirection>(toolForceDirection, SelectedInput.VALUE, toolForceDirection?.force?.value ?? 0);
}

function generateZeroSensorLabels(node: SampleToolForceNode) {
    const labelZeroSensor: TranslatedProgramLabelPart = {
        type: 'secondary',
        translationKey: 'presenter.tool-force.label.zero-sensor',
    };
    const time = node.parameters.zeroSensor.model.value;
    const Unit = node.parameters.zeroSensor.model.entity.waiting.unit;

    const labelZeroSensorValue: TranslatedProgramLabelPart = {
        type: 'secondary',
        translationKey: 'program-node-label.single-value',
        interpolateParams: { value: `${time} ${Unit}` },
    };
    return { labelZeroSensor, labelZeroSensorValue };
}

function generateFrameLabels(node: SampleToolForceNode) {
    const frameLabel: TranslatedProgramLabelPart = {
        type: 'secondary',
        translationKey: 'presenter.tool-force.label.reference',
    };

    const frameName = node.parameters.selectedFrame.model.entity.frameName;
    const frameNameLabel: TranslatedProgramLabelPart = {
        type: 'secondary',
        translationKey: 'program-node-label.single-value',
        interpolateParams: { value: frameName },
    };
    return { frameLabel, frameNameLabel };
}

function generateAxisLabel(axis: { name: string; value: TabInputModel<ToolForceDirection> }): TranslatedProgramLabelPart {
    const name = axis.name;
    const value = axis.value.value;
    const unit = axis.value.selectedType === 'VALUE' ? axis.value.entity.force?.unit : '';

    return {
        type: 'secondary',
        translationKey: 'program-node-label.single-value',
        interpolateParams: { value: `web-sdk-external: ${value} ${unit}` },
    };
}

const behaviors: ProgramBehaviors<SampleToolForceNode> = {
    factory: (): SampleToolForceNode => {
        return {
            type: 'ur-sample-node-tool-force',
            version: '0.0.3',
            allowsChildren: true,
            parameters: {
                x: {
                    isValid: false,
                    model: forceToTabModel({ force: { value: 0, unit: 'N' }, enabled: false }),
                },
                y: {
                    isValid: false,
                    model: forceToTabModel({ force: { value: 0, unit: 'N' }, enabled: false }),
                },
                z: {
                    isValid: false,
                    model: forceToTabModel({ force: { value: 0, unit: 'N' }, enabled: false }),
                },
                zeroSensor: {
                    isValid: false,
                    model: timeToTabModel({ waiting: { value: 0.02, unit: 's' }, enabled: false }),
                },
                selectedFrame: {
                    isValid: true,
                    model: frameToTabModel({ frameName: 'base', enabled: false }),
                },
            },
        };
    },

    programNodeLabel: (node: SampleToolForceNode): ProgramLabel => {
        const programNodeLabels: AdvancedTranslatedProgramLabel = [];

        const axes = [
            { name: 'X', value: node.parameters.x.model },
            { name: 'Y', value: node.parameters.y.model },
            { name: 'Z', value: node.parameters.z.model },
        ];

        axes.filter((axis) => axis.value.entity.enabled).forEach((axis) => {
            programNodeLabels.push(generateAxisLabel(axis));
        });

        if (node.parameters.zeroSensor?.model?.entity?.enabled) {
            const { labelZeroSensor, labelZeroSensorValue } = generateZeroSensorLabels(node);
            programNodeLabels.push(labelZeroSensor);
            programNodeLabels.push(labelZeroSensorValue);
        }

        const { frameLabel, frameNameLabel } = generateFrameLabels(node);
        programNodeLabels.push(frameLabel);
        programNodeLabels.push(frameNameLabel);

        return programNodeLabels;
    },
    validator: async (node, context): Promise<ValidationResponse> => {
        let isValid = false;

        if ((node.parameters.zeroSensor?.model?.value?.valueOf() as number) < 0) {
            return {
                isValid: false,
                errorMessageKey: 'Waiting value should not be negative',
            };
        }

        // Force node must have at least one child to be valid
        let notSuppressedNodesCount = 0;
        for await (const child of context.traverse.children) {
            if (!child.isSuppressed) {
                notSuppressedNodesCount++;
            }
        }
        if (notSuppressedNodesCount === 0) {
            return {
                isValid: false,
                errorMessageKey: 'Tool force has no nodes',
            };
        }

        const x = { name: 'X', value: node?.parameters?.x };
        const y = { name: 'Y', value: node?.parameters?.y };
        const z = { name: 'Z', value: node?.parameters?.z };

        const api = new ProgramBehaviorAPI(self);

        if (!node.parameters) {
            return { isValid };
        }
        const enabledNodes = [x, y, z].filter((item) => item.value.model?.entity?.enabled);

        //For of is needed because of the async await.
        for (const axis of enabledNodes) {
            if (axis.value.model?.selectedType === SelectedInput.VARIABLE) {
                const isValidVariable = await api.symbolService.isValidVariable(axis.value.model?.value as string, [
                    VariableValueType.FLOAT,
                ]);

                if (!isValidVariable) {
                    return { isValid };
                }
            }

            isValid = String(axis.value.model?.value).length > 0;
        }

        const frameExists = await isValidFrame(node.parameters?.selectedFrame?.model.entity.frameName, api);
        if (!frameExists) {
            isValid = false;
        }

        return { isValid };
    },
    generateCodeBeforeChildren,
    generateCodeAfterChildren,
    upgradeNode: (loadedNode: SampleToolForceNode): SampleToolForceNode => {
        const oldNode = { ...loadedNode } as any;
        if (!loadedNode?.version) {
            loadedNode = upgradeTo001(loadedNode, oldNode);
        }
        if (loadedNode.version === '0.0.1') {
            loadedNode = upgradeTo002(loadedNode);
        }

        if (loadedNode.version === '0.0.2') {
            loadedNode = upgradeTo003(loadedNode);
        }

        return loadedNode;
    },
};

function upgradeTo001(loadedNode: SampleToolForceNode, oldNode: any) {
    return {
        ...loadedNode,
        version: '0.0.1',
        parameters: {
            ...loadedNode.parameters,
            x: {
                isValid: !!oldNode.parameters.x.force,
                model: {
                    entity: {
                        force: {
                            ...oldNode.parameters.x.force,
                        },
                        enabled: oldNode.parameters.x.enabled,
                    },
                    selectedType: SelectedInput.VALUE,
                    value: oldNode.parameters.x.force?.value,
                },
            },
            y: {
                isValid: !!oldNode.parameters.y.force,
                model: {
                    entity: {
                        force: {
                            ...oldNode.parameters.y.force,
                        },
                        enabled: oldNode.parameters.y.enabled,
                    },
                    selectedType: SelectedInput.VALUE,
                    value: oldNode.parameters.y.force?.value,
                },
            },
            z: {
                isValid: !!oldNode.parameters.z.force,
                model: {
                    entity: {
                        force: {
                            ...oldNode.parameters.z.force,
                        },
                        enabled: oldNode.parameters.z.enabled,
                    },
                    selectedType: SelectedInput.VALUE,
                    value: oldNode.parameters.z.force?.value,
                },
            },
        },
    };
}

function upgradeTo002(loadedNode: SampleToolForceNode) {
    return {
        ...loadedNode,
        version: '0.0.2',
        parameters: {
            ...loadedNode.parameters,
            zeroSensor: {
                isValid: false,
                model: timeToTabModel({ waiting: { value: 0.02, unit: 's' }, enabled: false }),
            },
            selectedFrame: {
                isValid: true,
                // Set selected frameName to tcp as it was the behavior before the upgrade
                // Note: all new nodes will have base as default
                model: frameToTabModel({ frameName: 'tcp', enabled: false }),
            },
        },
    };
}

function upgradeTo003(loadedNode: SampleToolForceNode) {
    loadedNode.version = '0.0.3';
    const { x, y, z } = loadedNode.parameters;
    [x, y, z].forEach((axis) => {
        if (axis.model.value === undefined) {
            axis.model.entity.force = { value: 0, unit: 'N' };
            axis.model.value = 0;
            axis.model.selectedType = SelectedInput.VALUE;
        } else if (axis.model.entity?.force?.value === undefined) {
            axis.model.entity.force = { value: 0, unit: 'N' };
        }
    });

    return loadedNode;
}

function generateCodeBeforeChildren(node: SampleToolForceNode): ScriptBuilder {
    const builder = new ScriptBuilder();

    const { x, y, z, zeroSensor, selectedFrame } = node.parameters;
    if (![x, y, z].some((axis) => axis.model.entity.enabled)) {
        return builder;
    }

    if (zeroSensor.model.entity.enabled && (zeroSensor.model.value.valueOf() as number) >= 0) {
        builder.sleep(zeroSensor.model.value);
        builder.addStatements('zero_ftsensor()');
    }

    // 1 or 0 to enable [x, y, z, rx, ry, rz]
    const selectionVector = `[${[x, y, z].map((axis) => (axis.model.entity.enabled ? 1 : 0)).join(', ')}, 0, 0, 0]`;

    // Force in N [x, y, z, rx, ry, rz]
    const wrench = `[${[x, y, z].map((axis) => axis.model.value ?? '0.0').join(', ')}, 0.0, 0.0, 0.0]`;

    // don't transform the force frame
    const forceType = 2;

    // max motion in mm/s [x, y, z, rx, ry, rz]
    const limits = '[0.15, 0.15, 0.15, 0.3, 0.3, 0.3]';

    const taskFrame = `get_pose("${selectedFrame.model.entity.frameName}")`;
    const enableForceMode = `force_mode(${taskFrame}, ${selectionVector}, ${wrench}, ${forceType}, ${limits})`;
    builder.addStatements(enableForceMode);

    return builder;
}

function generateCodeAfterChildren(node: SampleToolForceNode): ScriptBuilder {
    const builder = new ScriptBuilder();

    const { x, y, z } = node.parameters;
    if ([x, y, z].some((axis) => axis.model.entity.enabled)) {
        builder.addStatements('end_force_mode()');
        builder.addStatements('stopl(5.0)');
    }

    return builder;
}

async function isValidFrame(frameId: string, api: ProgramBehaviorAPI): Promise<boolean> {
    const frames = (await api.applicationService.getApplicationNode(ApplicationNodeType.FRAMES)) as FramesNode;
    return frames.framesList.some((frame) => frame.name === frameId);
}

registerProgramBehavior(behaviors);
