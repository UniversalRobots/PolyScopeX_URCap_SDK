/// <reference lib="webworker" />
import { firstValueFrom } from 'rxjs';
import {
    Current,
    CurrentUnit,
    CurrentUnits,
    ProgramBehaviorAPI,
    ProgramBehaviors,
    ProgramLabel,
    registerProgramBehavior,
    ScriptBuilder,
    Signal,
    SignalAnalogDomainValueEnum,
    SignalDirectionEnum,
    SignalValueTypeEnum,
    ValidationResponse,
    VariableValueType,
    Voltage,
    VoltageUnit,
    VoltageUnits,
} from '@universal-robots/contribution-api';
import { SampleSetNode } from './set.node';

const behaviors: ProgramBehaviors<SampleSetNode> = {
    factory: (): SampleSetNode => {
        return {
            type: 'ur-sample-node-set',
            version: '0.0.4',
            allowsChildren: false,
            parameters: {
                signalOutput: {},
            },
        };
    },
    programNodeLabel: async (node: SampleSetNode): Promise<ProgramLabel> => {
        if (node.parameters.signalOutput) {
            return await generateSignalOutputLabel(node.parameters.signalOutput);
        } else {
            return [{ type: 'primary', translationKey: 'program-node-label.default' }];
        }
    },
    validator: async (node: SampleSetNode): Promise<ValidationResponse> => {
        const signalOutput = node.parameters.signalOutput;

        if (!signalOutput?.groupId || !signalOutput?.sourceID || !signalOutput.signalID || signalOutput.value === undefined) {
            return { isValid: false };
        }
        const api = new ProgramBehaviorAPI(self);
        // Can remove this check once the migration to new tool and wired I/O is complete
        if (signalOutput.groupId === 'robot' && typeof signalOutput.value === 'object') {
            const domains = await api.sourceService.getAnalogSignalDomains(signalOutput.sourceID);
            const currentDomain = domains[signalOutput.signalID];
            return { isValid: isUnitOfDomain(signalOutput.value.unit, currentDomain) };
        }
        const variableValidate = await validateVariableName(signalOutput);
        if (!variableValidate) {
            return { isValid: false };
        }

        let isValidVariable = true;
        if (signalOutput.signalValueType === SignalValueTypeEnum.CUSTOM && signalOutput.selectedType === 'VARIABLE') {
            isValidVariable = await api.symbolService.isValidVariable(signalOutput.value as string, [VariableValueType.BOOLEAN]);
        } else if (signalOutput.selectedType === 'VARIABLE' && signalOutput.signalValueType === SignalValueTypeEnum.FLOAT) {
            isValidVariable = await api.symbolService.isValidVariable(signalOutput.value as string, [
                VariableValueType.FLOAT,
                VariableValueType.INTEGER,
            ]);
        }

        if (!isValidVariable) {
            return { isValid: false };
        }
        if (signalOutput.groupId && signalOutput.sourceID) {
            const validationResponse = await api.sourceService.validateSetSignal(
                signalOutput?.groupId,
                signalOutput?.sourceID,
                signalOutput?.signalID,
                signalOutput.value,
            );
            if (!validationResponse.isValid) {
                return validationResponse;
            }
        }

        const signalValidate = await validateSignal(signalOutput, api);

        //Invalidate the signal if not true
        if (!signalValidate.isValid) {
            return signalValidate;
        }

        return { isValid: true };
    },
    generateCodeBeforeChildren: async (node: SampleSetNode): Promise<ScriptBuilder> => {
        const api = new ProgramBehaviorAPI(self);
        const signalOutput = node.parameters.signalOutput;
        const builder = new ScriptBuilder();
        if (!signalOutput?.groupId || !signalOutput?.sourceID || !signalOutput.signalID || signalOutput.value === undefined) {
            return builder;
        }
        const script = await api.sourceService.getSetSignalScript(
            signalOutput.groupId,
            signalOutput.sourceID,
            signalOutput.signalID,
            signalOutput.value,
        );
        builder.addRaw(script);
        return builder;
    },
    upgradeNode: async (loadedNode) => {
        if (!loadedNode.version) {
            loadedNode.version = '0.0.1';
        }
        if (loadedNode.version === '0.0.1') {
            loadedNode = await upgradeTo002(loadedNode);
        }
        if (loadedNode.version === '0.0.2') {
            loadedNode = await upgradeSourceIds(loadedNode);
            loadedNode = await upgradeTo003(loadedNode);
        }
        // Update to the new wired and tool I/O, which have different ids, but the same data
        if (loadedNode.version === '0.0.3') {
            loadedNode = await upgradeTo004(loadedNode);
        }

        return loadedNode;
    },
};

async function upgradeTo002(node: SampleSetNode) {
    node.version = '0.0.2';
    delete (node.parameters as any).type;
    return node;
}

async function upgradeTo003(node: SampleSetNode) {
    node.version = '0.0.3';
    if (node.parameters.signalOutput) {
        // Check if the value matches the valueType of the signal - if yes, set the signalValueType
        let groupId = node.parameters.signalOutput.groupId;
        const { sourceID, signalID, value } = node.parameters.signalOutput;
        // Upgrade fix to handle old sources from ur-tool and ur-wired-io without groupId
        if (!groupId && sourceID && (sourceID.includes('ur-tool') || sourceID.includes('ur-wired'))) {
            groupId = 'robot';
            node.parameters.signalOutput.groupId = groupId;
        }
        if (groupId && sourceID && signalID) {
            const api = new ProgramBehaviorAPI(self);
            const signalValueType = (await firstValueFrom(api.sourceService.sourceSignals(groupId, sourceID)))?.find(
                (signal) => signal.signalID === signalID,
            )?.valueType;
            if (
                (signalValueType === SignalValueTypeEnum.FLOAT && ((value as Current | Voltage)?.value || typeof value === 'number')) ||
                (signalValueType === SignalValueTypeEnum.BOOLEAN && typeof value === 'boolean') ||
                (signalValueType === SignalValueTypeEnum.REGISTER && typeof value === 'number' && parseInt(value.toString()) === value)
            ) {
                node.parameters.signalOutput.signalValueType = signalValueType;
            }
        }
    }
    return node;
}

async function upgradeSourceIds(node: SampleSetNode) {
    const signalOutput = node.parameters.signalOutput;
    if (signalOutput?.groupId === 'robot') {
        signalOutput.groupId = 'ur-robot-io';
        if (signalOutput?.sourceID === 'ur-wired-io') {
            signalOutput.sourceID = 'ur-robot-wired-io';
        }
        if (signalOutput?.sourceID === 'ur-tool-io') {
            signalOutput.sourceID = 'ur-robot-tool-io';
        }
    }
    return node;
}

async function upgradeTo004(node: SampleSetNode) {
    node.version = '0.0.4';
    return await upgradeSourceIds(node);
}

async function generateSignalOutputLabel(signalOutput: SampleSetNode['parameters']['signalOutput']): Promise<ProgramLabel> {
    if (signalOutput?.groupId && signalOutput?.signalID && signalOutput?.sourceID && signalOutput.value !== undefined) {
        const signalName = await getSignalName(signalOutput.groupId, signalOutput.sourceID, signalOutput.signalID);
        if (signalOutput.signalValueType === SignalValueTypeEnum.BOOLEAN) {
            const hiLow = signalOutput.value ? 'high' : 'low';
            return [
                {
                    type: 'primary',
                    translationKey: 'program-node-label.single-value',
                    interpolateParams: { value: signalName ? `${signalName} = ` : '' },
                },
                {
                    type: 'secondary',
                    translationKey: signalName ? `program-node-label.abbreviations.${hiLow}` : '',
                },
            ];
        }
        // When using a variable or expression
        if (signalOutput.signalValueType === SignalValueTypeEnum.CUSTOM) {
            const customVarName = signalOutput.value;
            return [
                {
                    type: 'primary',
                    translationKey: 'program-node-label.single-value',
                    interpolateParams: { value: signalName ? `${signalName} =` : '' },
                },
                {
                    type: 'secondary',
                    translationKey: `program-node-label.abbreviations.custom-variable`,
                    interpolateParams: { variableName: signalName ? `${customVarName}` : '' },
                },
            ];
        }
        // When using a register/modbus signal
        if (typeof signalOutput.value === 'number' || typeof signalOutput.value === 'string') {
            return [
                { type: 'primary', value: signalName ? `${signalName} =` : '' },
                { type: 'secondary', value: signalName ? `${signalOutput.value}` : '' },
            ];
        } else {
            const input = signalOutput.value as Current | Voltage;
            return [
                { type: 'primary', value: signalName ? `${signalName} =` : '' },
                {
                    type: 'secondary',
                    value: `${input.value} ${input.unit}`,
                },
            ];
        }
    }
    return [{ type: 'primary', value: '' }];
}
const getSignalName = async (groupId: string, sourceId: string, signalId: string) => {
    const api = new ProgramBehaviorAPI(self);
    const signalName = (await firstValueFrom(api.sourceService.sourceSignals(groupId, sourceId))).find(
        (signal: Signal) => signal.signalID === signalId,
    )?.name as string;

    if (groupId !== 'ur-robot-io') {
        return signalName;
    }
    return (
        (await firstValueFrom(api.sourceService.sourceSignals(groupId, sourceId))).find((signal: Signal) => signal.signalID === signalId)
            ?.name ?? signalId
    );
};

const isUnitOfDomain = (unit: CurrentUnit | VoltageUnit, domain: SignalAnalogDomainValueEnum) => {
    if ((CurrentUnits as readonly string[]).includes(unit) && domain === SignalAnalogDomainValueEnum.CURRENT) {
        return true;
    }
    return (VoltageUnits as readonly string[]).includes(unit) && domain === SignalAnalogDomainValueEnum.VOLTAGE;
};

const validateSignal = async (signalOutput: SampleSetNode['parameters']['signalOutput'], api: ProgramBehaviorAPI) => {
    if (!signalOutput || !signalOutput.sourceID || !signalOutput.signalID) {
        return { isValid: false, errorMessageKey: 'Signal must be an output signal' };
    }

    const signals = await api.sourceService.getSignals(signalOutput.sourceID);
    const signal = signals.find((s) => s.signalID === signalOutput.signalID);

    if (!signal) {
        return { isValid: false, errorMessageKey: 'Signal not found' };
    }

    if (signal.direction !== SignalDirectionEnum.OUT) {
        return { isValid: false, errorMessageKey: 'Signal must be an output signal' };
    }

    if (signalOutput?.signalValueType !== SignalValueTypeEnum.CUSTOM && signal.valueType !== signalOutput?.signalValueType) {
        return { isValid: false, errorMessageKey: 'Signal value type does not match' };
    }

    return { isValid: true };
};

async function validateVariableName(signalOutput: SampleSetNode['parameters']['signalOutput']): Promise<boolean> {
    if (!signalOutput || signalOutput.value === undefined) {
        return false;
    }

    const api = new ProgramBehaviorAPI(self);

    if (signalOutput?.selectedType === 'VARIABLE' && signalOutput.signalValueType === SignalValueTypeEnum.CUSTOM) {
        const isRegisteredVariableName = await api.symbolService.isRegisteredVariableName(signalOutput.value as string);

        if (!isRegisteredVariableName) {
            return false;
        }

        const isSuppressed = await api.symbolService.isSuppressed(signalOutput.value as string);
        if (isSuppressed) {
            return false;
        }
    }

    return true;
}

registerProgramBehavior(behaviors);
