#!/bin/sh

FILE="/data/temporary/log.txt"
touch "$FILE"
JSON=$1

echo "on_device_remove callback called" >> $FILE

echo "Full JSON payload: $JSON" >> $FILE

# Expected values: NETWORK | SERIAL | VIDEO
TYPE=$(echo $JSON | jq -r .urDeviceType)
echo "device type $TYPE" >> $FILE

echo "removing device" >> $FILE
exit 0
