# Angular contribution

This project contains an example of a URCap Sidebar Item Contribution.
When running a program, this example displays a list of the global variables in the sidebar.

The sidebar is designed to contain content that needs quick selection access alongside the main content. 
Functioning as a persistent drawer, the user can toggle it open or closed.
Developers can contribute content to the sidebar using the Sidebar Item Contribution type.

Refer to the Sidebar Items contribution section in the [official documentation](https://docs.universal-robots.com/PolyScopeX_SDK_Documentation) for more information.

## Build and Deploy Sample

To build and deploy this sample, use the commands below. A rebuild of the project is required to see any changes made 
to the source code. If you are deploying the URCap to URSim, ensure that you have started the simulator.

### Dependencies

Run this command to install the dependencies of the project.

```shell
npm install
```

### Build

Run this command to build the contribution type.

```shell
npm run build
```

### Installation

Run this command to install the built URCap to the simulator.

```shell
npm run install-urcap
```

Run this command to install the built URCap to the robot.

```shell
npm run install-urcap -- --host <robot_ip_address>
````


## Further help

Get more help from the included SDK documentation.
