import { ApplicationNode } from '@universal-robots/contribution-api';

export interface {{ item.elementComponentName }}Node extends ApplicationNode {
  type: string;
  version: string;
}
