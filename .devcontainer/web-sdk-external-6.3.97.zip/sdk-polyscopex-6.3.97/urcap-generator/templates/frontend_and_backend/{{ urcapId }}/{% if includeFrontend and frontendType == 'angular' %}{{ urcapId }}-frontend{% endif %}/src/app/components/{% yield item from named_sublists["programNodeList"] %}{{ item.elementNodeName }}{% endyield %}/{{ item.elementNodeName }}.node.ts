import { ProgramNode } from '@universal-robots/contribution-api';

export interface {{ item.elementComponentName }}Node extends ProgramNode {
    type: string;
    parameters?: {
        [key: string]: unknown;
    };
    lockChildren?: boolean;
    allowsChildren?: boolean;
}
