import {ComponentFixture, TestBed} from '@angular/core/testing';
import { {{ item.elementComponentName }}Component} from "./{{ item.elementComponentName }}.component";
import {TranslateLoader, TranslateModule} from "@ngx-translate/core";
import {Observable, of} from "rxjs";

describe('{{ item.elementComponentName }}Component', () => {
  let fixture: ComponentFixture<{{ item.elementComponentName }}Component>;
  let component: {{ item.elementComponentName }}Component;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [{{ item.elementComponentName }}Component],
      imports: [TranslateModule.forRoot({
        loader: {
          provide: TranslateLoader, useValue: {
            getTranslation(): Observable<Record<string, string>> {
              return of({});
            }
          }
        }
      })],
    }).compileComponents();

    fixture = TestBed.createComponent({{ item.elementComponentName }}Component);
    component = fixture.componentInstance;
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });
});
