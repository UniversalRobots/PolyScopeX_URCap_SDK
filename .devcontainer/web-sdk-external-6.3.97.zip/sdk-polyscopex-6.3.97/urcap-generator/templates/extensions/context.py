from copier_templates_extensions import ContextHook
from copier.errors import UserMessageError
import re


class ContextUpdater(ContextHook):
    update = False

    # These 3 must be replaced by maven's filtering
    docker_image_development="universalrobots/urcap_polyscopex_ros2:4.0.5-humble-dev"
    docker_image_runtime="universalrobots/urcap_polyscopex_ros2:4.0.5-humble-runtime"
    docker_image_proxy=""

    # camel case strings. Fx my-awesome-string -> MyAwesomeString
    def to_camelcase(self, input_str):
        input_str = input_str.strip()  # Trim whitespace
        return input_str[0].upper() + re.sub(r'-(.)', lambda x: x.group(1).upper(), input_str[1:].lower())

    # Replace hyphen (dash) with whitespace and capitalize next word
    def to_title(self, input_str):
        return ' '.join(word.capitalize() for word in input_str.replace("-", " ").split())

    # replace . and _ with -
    def to_ROS2_node_name(self, input):
        return re.sub(r'[.-]', '_', input.lower().strip())

    # replace . and - with _
    def to_tag_name(self, input):
        return re.sub(r'[._]', '-', input.lower().strip())

    def buildItem(self, elementName, base_tag):
        return {
                  "elementComponentName": self.to_camelcase(elementName),
                  "elementNodeTitle": self.to_title(elementName),
                  "elementTagName": self.to_tag_name(base_tag + elementName),
                  "elementNodeName": elementName,
               }

    def hook(self, context):
        if context.get("operatorScreens") != None: # This must be the key to the last questions asked
            if not context["includeFrontend"] and not context["includeDocker"]:
                raise UserMessageError("Invalid combination chosen! Include either a frontend or a backend to generate a valid URCap. Rerun the generator to restart")

            base_tag = self.to_tag_name(context["vendorId"]) + "-" + self.to_tag_name(context["urcapId"]) + "-"
            context["artifactId"] = context.get("urcapId")

            applicationNodeList = []
            programNodeList = []
            smartSkillList = []
            sidebarItemList = []
            operatorScreenList = []

            if context["applicationNodes"]:
                for element in context["applicationNodes"].split(","):
                    applicationNodeList.append(self.buildItem(element, base_tag))

            if context["programNodes"]:
                for element in context["programNodes"].split(","):
                    programNodeList.append(self.buildItem(element, base_tag))

            if context["smartSkills"]:
                for element in context["smartSkills"].split(","):
                    smartSkillList.append(self.buildItem(element, base_tag))

            if context["sidebarItems"]:
                for element in context["sidebarItems"].split(","):
                    sidebarItemList.append(self.buildItem(element, base_tag))

            if context["operatorScreens"]:
                for element in context["operatorScreens"].split(","):
                    operatorScreenList.append(self.buildItem(element, base_tag))

            named_sublists = {
                            "applicationNodeList": applicationNodeList,
                            "programNodeList": programNodeList,
                            "smartSkillList": smartSkillList,
                            "sidebarItemList": sidebarItemList,
                            "operatorScreenList": operatorScreenList,
                        }

            context["named_sublists"] = named_sublists

            allElementsFlattened = [
                item for sublist in named_sublists.values() for item in sublist
            ]

            context["allElementsFlattened"] = allElementsFlattened


            if not context["includeFrontend"] and context["includeDocker"]:
                context["dockerOnly"] = True
                context["FrontendType"] = ''


            context["ros2NodeName"] = self.to_ROS2_node_name(context.get("urcapId"))
            context["ros2NodeDesc"] = context.get("urcapId")

            # TODO REMOVE WHEN MAVEN BUILDS THESE
            context["docker_developmentimage"] = self.docker_image_development
            context["docker_runtimeimage"] = self.docker_image_runtime
            context["docker_sampleproxy"] = self.docker_image_proxy
            context["frontendId"] = context.get("urcapId")+"-frontend"
            context["backendId"] = context.get("urcapId")+"-backend"
            context["subdirectory"] = "frontend_and_backend"