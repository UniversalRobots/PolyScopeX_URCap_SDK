/// <reference lib="webworker" />
import { firstValueFrom } from 'rxjs';
import {
    AdvancedTranslatedProgramLabel,
    Current,
    CurrentUnit,
    CurrentUnits,
    ProgramBehaviorAPI,
    ProgramBehaviors,
    registerProgramBehavior,
    ScriptBuilder,
    SignalAnalogDomainValueEnum,
    SignalDirectionEnum,
    SignalValue,
    Value,
    SignalValueTypeEnum,
    VALIDATION_OK,
    ValidationResponse,
    Voltage,
    VoltageUnit,
    VoltageUnits,
} from '@universal-robots/contribution-api';
import { SampleSetNode } from './set.node';

const behaviors: ProgramBehaviors<SampleSetNode> = {
    factory: (): SampleSetNode => {
        return {
            type: 'ur-sample-node-set',
            version: '0.0.4',
            allowsChildren: false,
            parameters: {
                signalOutput: {},
            },
        };
    },
    async programNodeLabel(node: SampleSetNode): Promise<AdvancedTranslatedProgramLabel> {
        const programLabel: AdvancedTranslatedProgramLabel = [];
        if (node.parameters.signalOutput) {
            const signalOutput = node.parameters.signalOutput;
            const groupID = signalOutput.groupId;
            const sourceID = signalOutput.sourceID;
            const signalID = signalOutput.signalID;
            const value = signalOutput.value;
            if (groupID && sourceID && signalID && value !== undefined) {
                const api = new ProgramBehaviorAPI(self);
                const signals = await api.sourceService.getSignals(sourceID);
                const signal = signals.find((s) => s.signalID === signalOutput.signalID);
                const signalName = signal?.name ?? signalID;
                programLabel.push({
                    type: 'primary',
                    translationKey: 'program-node-label.set.signal-name',
                    interpolateParams: { signalName: signalName },
                });
                if (signal?.valueType === SignalValueTypeEnum.BOOLEAN) {
                    programLabel.push({
                        type: 'secondary',
                        translationKey: `program-node-label.abbreviations.${value ? 'high' : 'low'}`,
                    });
                } else if (signal?.valueType === SignalValueTypeEnum.REGISTER) {
                    programLabel.push({
                        type: 'secondary',
                        translationKey: 'program-node-label.single-value',
                        interpolateParams: { value: `${value}` },
                    });
                } else if (signal?.valueType === SignalValueTypeEnum.FLOAT) {
                    if (typeof value === 'number') {
                        programLabel.push({
                            type: 'secondary',
                            translationKey: 'program-node-label.single-value',
                            interpolateParams: { value: `${value}` },
                        });
                    } else {
                        // Support legacy analog signals from wired-io and tool-io
                        programLabel.push({
                                type: 'secondary',
                            translationKey: 'program-node-label.single-value',
                            interpolateParams: {
                                value: `${(value as Current | Voltage).value.toFixed(1)} ${(value as Voltage | Current).unit}`,
                            },
                        });
                    }
                }
            } else if (signalID) {
                programLabel.push({
                    type: 'primary',
                    translationKey: 'program-node-label.single-value',
                    interpolateParams: { value: `${signalID}` },
                });
            }
        }
        return programLabel;
    },
    validator: async (node: SampleSetNode): Promise<ValidationResponse> => {
        const signalOutput = node.parameters.signalOutput;
        if (!signalOutput?.sourceID || !signalOutput.signalID || signalOutput.value === undefined) {
            return { isValid: false };
        }
        const api = new ProgramBehaviorAPI(self);
        // Can remove this check once the migration to new tool and wired I/O is complete
        if (signalOutput?.groupId === 'robot' && isValueObject(signalOutput.value)) {
            const domains = await api.sourceService.getAnalogSignalDomains(signalOutput.sourceID);
            const currentDomain = domains[signalOutput.signalID];
            return { isValid: isUnitOfDomain(signalOutput.value.unit, currentDomain) };
        }
        const signals = await api.sourceService.getSignals(signalOutput.sourceID);
        const signal = signals.find((s) => s.signalID === signalOutput.signalID);
        if (!signal) {
            return { isValid: false, errorMessageKey: 'Signal not found' };
        }
        if (signal.direction !== SignalDirectionEnum.OUT) {
            return { isValid: false, errorMessageKey: 'Signal must be an output signal' };
        }
        if (signal.valueType !== node.parameters.signalOutput?.signalValueType) {
            return { isValid: false, errorMessageKey: 'Signal value type does not match' };
        }
        if (signalOutput.groupId && signalOutput.sourceID) {
            const validationResponse = await api.sourceService.validateSetSignal(
                signalOutput?.groupId,
                signalOutput?.sourceID,
                signalOutput?.signalID,
                signalOutput.value,
            );
            if (validationResponse !== VALIDATION_OK) {
                return validationResponse;
            }
        }

        return { isValid: true };
    },
    generateCodeBeforeChildren: async (node: SampleSetNode): Promise<ScriptBuilder> => {
        const api = new ProgramBehaviorAPI(self);
        const signalOutput = node.parameters.signalOutput;
        const builder = new ScriptBuilder();
        if (!signalOutput?.groupId || !signalOutput?.sourceID || !signalOutput.signalID || signalOutput.value === undefined) {
            return builder;
        }
        const script = await api.sourceService.getSetSignalScript(
            signalOutput.groupId,
            signalOutput.sourceID,
            signalOutput.signalID,
            signalOutput.value,
        );
        builder.addRaw(script);
        return builder;
    },
    upgradeNode: async (loadedNode) => {
        if (loadedNode.version === '0.0.1') {
            loadedNode = await upgradeTo002(loadedNode);
        }
        if (loadedNode.version === '0.0.2') {
            loadedNode = await upgradeTo003(loadedNode);
        }
        // Update to the new wired and tool I/O, which have different ids, but the same data
        if (loadedNode.version === '0.0.3') {
            loadedNode = await upgradeTo004(loadedNode);
        }

        return loadedNode;
    },
};

async function upgradeTo002(node: SampleSetNode) {
    node.version = '0.0.2';
    delete (node.parameters as any).type;
    return node;
}

async function upgradeTo003(node: SampleSetNode) {
    node.version = '0.0.3';
    if (node.parameters.signalOutput) {
            // Check if the value matches the valueType of the signal - if yes, set the signalValueType
        let groupId = node.parameters.signalOutput.groupId;
        const { sourceID, signalID, value } = node.parameters.signalOutput;
            // Upgrade fix to handle old sources from ur-tool and ur-wired-io without groupId
            if (!groupId && sourceID && (sourceID.includes('ur-tool') || sourceID.includes('ur-wired'))) {
                groupId = 'robot';
                node.parameters.signalOutput.groupId = 'robot';
            }
            if (groupId && sourceID && signalID) {
                const api = new ProgramBehaviorAPI(self);
                const signalValueType = (await firstValueFrom(api.sourceService.sourceSignals(groupId, sourceID)))?.find(
                    (signal) => signal.signalID === signalID,
                )?.valueType;
                if (
                    (signalValueType === SignalValueTypeEnum.FLOAT && ((value as Current | Voltage)?.value || typeof value === 'number')) ||
                    (signalValueType === SignalValueTypeEnum.BOOLEAN && typeof value === 'boolean') ||
                    (signalValueType === SignalValueTypeEnum.REGISTER && typeof value === 'number' && parseInt(value.toString()) === value)
                ) {
                    node.parameters.signalOutput.signalValueType = signalValueType;
                }
              }
            }
    return node;
}

async function upgradeTo004(node: SampleSetNode) {
    node.version = '0.0.4';
    const signalOutput = node.parameters.signalOutput;
    if (signalOutput?.groupId === 'robot') {
        signalOutput.groupId = 'ur-robot-io';
        if (signalOutput?.sourceID === 'ur-wired-io') {
            signalOutput.sourceID = 'ur-robot-wired-io';
        }
        if (signalOutput?.sourceID === 'ur-tool-io') {
            signalOutput.sourceID = 'ur-robot-tool-io';
        }
        }
    return node;
}

const isUnitOfDomain = (unit: CurrentUnit | VoltageUnit, domain: SignalAnalogDomainValueEnum) => {
    if ((CurrentUnits as readonly string[]).includes(unit) && domain === SignalAnalogDomainValueEnum.CURRENT) {
        return true;
    }
    return (VoltageUnits as readonly string[]).includes(unit) && domain === SignalAnalogDomainValueEnum.VOLTAGE;
};

const isValueObject = (value: SignalValue): value is Value => {
    return typeof value === 'object' && 'unit' in value && 'value' in value;
};

registerProgramBehavior(behaviors);
