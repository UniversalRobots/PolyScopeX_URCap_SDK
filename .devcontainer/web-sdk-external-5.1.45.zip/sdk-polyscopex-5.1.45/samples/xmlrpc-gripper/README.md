# XmlRpc sample

This project is a template example of a URCap Contribution containing a Docker backend and a Web frontend.

## Build

To build contribution type:

`$ npm install && npm run build`

## Deploy

To deploy sample type:

`$ npm run install-urcap`
