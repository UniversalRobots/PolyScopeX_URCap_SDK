# ROS Custom Types

The following provides an example of how to supply your own custom message types for use inside urscript.
In order for the controller to understand your custom messages, they have to be first compiled and installed on the robot.

## Adding rostypes to manifest.yaml
First place your custom ros types in a folder with the name `rostypes`. Then in the `manifest.yaml` add a new artifact 'rosTypes':
```
...
artifacts:
  rosTypes:
    id: ros-types-example
    folder: rostypes
```
 Note that the foldername must be `rostypes`.

## What is a custom ROS type exactly?
A ROS type is also known as a ROS interface. It contains message, service and action definitions, which are respectively placed in directories with the names 'msg', 'srv', 'action'.

The messages provided with this example were created using standard ROS tooling, e.g. `ros2 pkg create` following this guide https://docs.ros.org/en/foxy/Tutorials/Beginner-Client-Libraries/Single-Package-Define-And-Use-Interface.html. The custom message packages should be created using ros tooling, or at least adhere to the standard directory layout of a ros package. 

In the case of this example, the messages contain a CMakeLists.txt detailing how to build the package, a package.xml with metadata and dependency information, and finally the msg definition itself.

```
├── bird_msgs
│   ├── CMakeLists.txt
│   ├── msg
│   │   └── Bird.msg
│   ├── package.xml
├── flock_msgs
│   ├── CMakeLists.txt
│   ├── msg
│   │   └── Flock.msg
│   ├── package.xml
```
Nested types in different packages are supported. In the provided example a 'Flock' is a list of 'Bird's, i.e. flock_msgs are dependent on bird_msgs. 

## Using a Custom Message in URScript
Create a new program in the program tab in PolyScope X. Add a script node and paste the following script into the dialog box. Then press play.

```
global iter = 0

# A thread responsible for sending messages
thread publish():
    # Prepare a handle for a topic, that can be used to send messages. The name is test, and the type is std_msgs/String
    pub_handle = ros_publisher_factory(topic="foo", msg_type="bird_msgs/Bird", history="keep_last", depth=100, durability="transient_local")
    while(True):
        pub_handle.write(struct(species="Seagull"))  
        sleep(1)
    end
end
myPublisher = run publish()

thread subscribe():
    sub_handle = ros_subscriber_factory(topic="foo", msg_type="bird_msgs/Bird")
    while(True):
        value = sub_handle.read()
        popup(value)
        end
end
mySubscriber = run subscribe()

join mySubscriber # Avoid the main thread exiting
join myPublisher

```

If everything works, a popup should appear.