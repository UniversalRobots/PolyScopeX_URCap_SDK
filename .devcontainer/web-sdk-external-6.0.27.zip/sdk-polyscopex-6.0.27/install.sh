#!/bin/bash

##############################################################################
# Bash script to install the URCap Contribution Generator
##############################################################################
set -e

echo "Installing URCap Generator ..."
npm install --silent -g yo file://./urcap-generator/generator-urcap.tgz
cp -f urcap-generator/sh_newurcap newurcap.sh
npm config set @universal-robots:registry https://pkgs.dev.azure.com/polyscopex/api/_packaging/polyscopex/npm/registry/
npm config set strict-ssl false
echo "Run './newurcap.sh' to create new URCap contributions."

set +e