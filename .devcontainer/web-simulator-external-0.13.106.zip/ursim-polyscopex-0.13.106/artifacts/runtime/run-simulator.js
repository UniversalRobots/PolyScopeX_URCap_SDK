const {spawn, spawnSync} = require("child_process");
const process = require('process');
const {program, Option} = require("commander");
const PropertiesReader = require('properties-reader');
const fs = require("fs");
const readlineSync = require('readline-sync');
const path = require('path');

// __dirname is the absolute path of the executed script (where the compose file is also located)
const DOCKER_COMPOSE_PATH = `${__dirname}/docker-compose.yml`;
const ENV_FILE=`${__dirname}/.env`
const ENV_FILE_PARAM = `--env-file=${ENV_FILE}`

let PROJECT_NAME;
let APPLICATION_VOLUME;
let URCAPS_VOLUME;
let NGINX_SNIPPETS_VOLUME;
let DOCKER_VOLUME;
let SAFETY_VOLUME;

// Populated from Maven variable, for checking against previous container
const DOCKER_IMAGE='universalrobots/ursim_polyscopex:0.13.106'

program.addOption(
    new Option("--robotType <Robot Type>", "The type of robot to simulate")
        .choices(["UR3", "UR5", "UR10", "UR16", "UR20", "UR30"])
        .default("UR5"))
    .option('--clear-applications', 'Remove applications and programs from previous runs')
    .option('--reset', 'Restore environment to default state (excluding applications and programs)')
    .option('--port <port>', 'Set a custom port for accessing the application', "80")
    .option('--project-name <Project Name>', 'Advanced option: Sets a custom namespace for Docker', "ursim-polyscopex")
    .action(async () => {
        doReset = false;
        await main()
    });

program.parse();

async function main() {
    process.on("SIGINT", async () => {
        // Trap interrupt (Ctrl-C)
        console.log("::::: Terminating Simulator :::::")
        await stopRunningProcess()
    });

    const doReset = parseParameters();

    writeEnvironmentFile()
    await stopRunningProcess()
    await launchBackendServices(doReset)
}

function parseParameters() {
    const opts = program.opts()
    let doReset = opts.reset
    const resetParams = parametersRequiringReset(opts);

    PROJECT_NAME = program.opts().projectName
    APPLICATION_VOLUME = `${PROJECT_NAME}-applications`
    URCAPS_VOLUME = `${PROJECT_NAME}-urcaps`
    NGINX_SNIPPETS_VOLUME = `${PROJECT_NAME}-ur-snippets`
    DOCKER_VOLUME = `${PROJECT_NAME}-docker-volume`
    SAFETY_VOLUME = `${PROJECT_NAME}-safety-volume`

    if (resetParams.length > 0 && !doReset) {
        // Parameters were set, and --reset was not used
        console.log("The following parameters requires creating a new Docker container using the --reset flag")
        for (let diff of resetParams) {
            if (diff.lastValue !== undefined) {
                console.log(`    ${diff.paramName} - Last Run: ${diff.lastValue}, This Run: ${diff.currentValue}`)
            } else {
                console.log(`    ${diff.paramName} was specified`)
            }
        }
        console.log("WARNING: Continuing will add the --reset flag and remove any installed URCaps")

        // Prompt user if parameters differ from last run and --reset wasn't used, to get acceptance to continue
        if (!readlineSync.keyInYNStrict()) {
            // User does not wish to continue
            console.log("run-simulator cancelled!")
            process.exit(0)
        }
        doReset = true;
    }
    return doReset
}

function parametersRequiringReset(opts) {
    let envFile = null;
    try {
        // Read .env file from last run
        envFile = PropertiesReader(ENV_FILE);
    } catch (e) {
        // .env file does not exist, probably first run
    }
    const diffs = []
    if (envFile) {
        // Check if current parameters differ with parameters from last run
        if (opts.robotType !== envFile.get("ROBOT_TYPE")) {
            diffs.push({param: "--robotType", paramName: "Robot Type", lastValue: envFile.get("ROBOT_TYPE"), currentValue: opts.robotType})
        }

        if (Number(opts.port) !== Number(envFile.get("PORT"))) {
            diffs.push({param: "--port", paramName: "Port", lastValue: envFile.get("PORT"), currentValue: opts.port})
        }

        if (opts.clearApplications !== undefined && !opts.reset) {
            diffs.push({param: "--clear-applications", paramName: "Clear Applications"})
        }

        if (opts.projectName !== envFile.get("PROJECT_NAME")) {
            diffs.push({param: "--project-name", paramName: "Project Name", lastValue: envFile.get("PROJECT_NAME"), currentValue: opts.projectName})
        }
    }

    const previousImage = getDockerImageFromPreviousContainer()
    if (previousImage && previousImage !== DOCKER_IMAGE) {
        // Docker image has changed from previous run (e.g. by an update)
        diffs.push({param: "DOCKER_IMAGE", paramName: "Docker Image", lastValue: previousImage, currentValue: DOCKER_IMAGE})
    }
    return diffs;
}

function writeEnvironmentFile() {
    const content = `ROBOT_TYPE=${program.opts().robotType}
HOST_ARCH=${process.arch}
ROS2_NAMESPACE=UR8888
PROJECT_NAME=${PROJECT_NAME}
APPLICATION_VOLUME=${APPLICATION_VOLUME}
URCAPS_VOLUME=${URCAPS_VOLUME}
NGINX_SNIPPETS_VOLUME=${NGINX_SNIPPETS_VOLUME}
DOCKER_VOLUME=${DOCKER_VOLUME}
SAFETY_VOLUME=${SAFETY_VOLUME}
PORT=${program.opts().port}`
    fs.writeFileSync(ENV_FILE, content);
}

function getDockerImageFromPreviousContainer() {
    // Get the container ID of the previously run simulator (if any)
    const containerId = getCommandLineOutput('docker', ['ps', '-a', '--filter', 'name=ursim-polyscopex-runtime-1', '-q'])
    if (containerId) {
        // Find the image used in the previous container (.replaceAll because inspect returns the string quoted)
        return getCommandLineOutput('docker', ['inspect', containerId, "--format='{{.Config.Image}}'"]).replaceAll("'", '');
    }
}

function getCommandLineOutput(command, params) {
    const proc = spawnSync(command, params, { encoding : 'utf8' });
    return proc.stdout.trim();
}

async function cleanDockerEnv() {
    // Clean up existing containers, networks and anonymous volumes from previous runs
    await executeCommandLine('docker', ['compose', ENV_FILE_PARAM, '--file', DOCKER_COMPOSE_PATH, '-p', PROJECT_NAME, 'down'])
}

async function stopRunningProcess() {
    // Shutdown development env (but don't remove containers, volumes, etc.)
    await executeCommandLine('docker', ['compose', ENV_FILE_PARAM, '--file', DOCKER_COMPOSE_PATH, '-p', PROJECT_NAME, 'stop'])
}

async function createDockerVolume(volume) {
    await executeCommandLine('docker', ['volume', 'create', volume], false)
}

async function removeDockerVolume(volume) {
    await executeCommandLine('docker', ['volume', 'rm', volume], false)
}

async function handleDockerVolumes(doReset) {
    console.log("Setting up docker volumes")
    if (program.opts().clearApplications) {
        await removeDockerVolume(APPLICATION_VOLUME)
    }
    await createDockerVolume(APPLICATION_VOLUME)

    if (doReset) {
        await removeDockerVolume(URCAPS_VOLUME)
        await removeDockerVolume(NGINX_SNIPPETS_VOLUME)
        await removeDockerVolume(DOCKER_VOLUME)
        if (program.opts().clearApplications) {
            await removeDockerVolume(SAFETY_VOLUME)
        }
    }
    await createDockerVolume(URCAPS_VOLUME)
    await createDockerVolume(NGINX_SNIPPETS_VOLUME)
    await createDockerVolume(DOCKER_VOLUME)
    await createDockerVolume(SAFETY_VOLUME)
}

async function launchBackendServices(doReset) {
    let creationParam = '--no-recreate'
    if (doReset) {
        await cleanDockerEnv()
        creationParam = '--force-recreate'
    }
    await handleDockerVolumes(doReset)
    await executeCommandLine('docker', ['compose', ENV_FILE_PARAM, '-p', PROJECT_NAME, '--file', DOCKER_COMPOSE_PATH, 'up', '--remove-orphans', creationParam, '-d']);
    await executeCommandLine('docker', ['compose', ENV_FILE_PARAM, '--file', DOCKER_COMPOSE_PATH, '-p', PROJECT_NAME, 'logs', '-f'], true, true);
}

async function executeCommandLine(command, params, ignoreStdErr = false, showOutput = true) {
    return new Promise(function (resolve, reject) {
        const proc = spawn(command, params, {stdio: [showOutput ? 'inherit' : 'ignore', showOutput ? 'inherit' : 'ignore', ignoreStdErr ? 'ignore' : 'inherit']});

        proc.on("exit", function (exitCode) {
            resolve()
        });

        proc.on("error", function (err) {
            reject(err);
        })
    });
}
