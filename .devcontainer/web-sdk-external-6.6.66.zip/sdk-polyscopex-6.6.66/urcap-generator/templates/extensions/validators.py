import re

from jinja2.ext import Extension


def _node_name_validator(current_nodes, *other_node_lists):
    """
    Validate that a list of node-names all are valid and doesn't contain duplicates.
    :param current_nodes: the list of names, as a comma-separated string.
    :param other_node_lists: optional lists (comma-separated strings) of the other types of nodes,
        for checking for duplicates.
    :return: an error message if input is not valid (as copier requires).
    """
    nodes_as_list = current_nodes.split(",")
    for node in nodes_as_list:
        if not re.fullmatch(r"^[A-Za-z].*", node):
            return "Each item must start with a letter."
        if not re.fullmatch(r"^[A-Za-z\d-]+$", node):
            return "Each item must include only letters, numbers, dashes."

    unique_names = set(nodes_as_list)
    if len(unique_names) != len(nodes_as_list):
        # If the set of unique names is not the same size as the full list, there are duplicates
        return "Duplicate values are not allowed."

    if other_node_lists:
        for other_nodes in other_node_lists:
            other_node_list = other_nodes.split(",")
            combined_list = nodes_as_list + other_node_list
            combined_set = set(combined_list)
            if len(combined_list) != len(combined_set):
                # If the set of unique names is not the same size as the full combined list, there are duplicates
                return "Duplicate values across nodes are not allowed."

    return ""


class NodeNameValidator(Extension):
    """Validator for names of frontend nodes"""

    def __init__(self, environment):
        super().__init__(environment)
        # allow usage of the validator in the copier.yml file, via the name 'node_name_validator'
        environment.filters["node_name_validator"] = _node_name_validator
