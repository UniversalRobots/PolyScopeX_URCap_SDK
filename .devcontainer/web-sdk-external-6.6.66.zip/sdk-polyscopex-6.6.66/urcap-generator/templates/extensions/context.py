import re
from typing import Any
from copier.errors import UserMessageError
from copier_templates_extensions import ContextHook


class ContextUpdater(ContextHook):
    """Helper class for creating a URCap, based on user's input"""

    update = False

    @staticmethod
    def to_camelcase(input_str) -> str:
        """Convert a string to camel case. For example, "my-awesome-string" becomes "MyAwesomeString"."""

        # Trim whitespace
        input_str = input_str.strip()
        return input_str[0].upper() + re.sub(
            r"-(.)", lambda x: x.group(1).upper(), input_str[1:].lower()
        )

    @staticmethod
    def to_title(input_str) -> str:
        """Replace hyphen (dash) with whitespace and capitalize next word"""

        return " ".join(
            word.capitalize() for word in input_str.replace("-", " ").split()
        )

    @staticmethod
    def to_ROS2_node_name(input_str) -> str:
        """replace . and _ with -"""

        return re.sub(r"[.-]", "_", input_str.lower().strip())

    @staticmethod
    def to_tag_name(input_str) -> str:
        """replace . and - with _"""

        return re.sub(r"[._]", "-", input_str.lower().strip())

    def build_item(self, element_name, base_tag) -> dict[str, str]:
        return {
            "elementComponentName": self.to_camelcase(element_name),
            "elementNodeTitle": self.to_title(element_name),
            "elementTagName": self.to_tag_name(base_tag + element_name),
            "elementNodeName": element_name,
        }

    def create_named_sublists(self, context) -> dict[Any, Any]:
        named_sublists = {}
        base_tag = (
            self.to_tag_name(context["vendorId"])
            + "-"
            + self.to_tag_name(context["urcapId"])
            + "-"
        )
        if context["hasApplicationNode"]:
            named_sublists["applicationNodeList"] = [
                self.build_item(element, base_tag)
                for element in context["applicationNodes"].split(",")
            ]

        if context["hasProgramNode"]:
            named_sublists["programNodeList"] = [
                self.build_item(element, base_tag)
                for element in context["programNodes"].split(",")
            ]

        if context["hasSmartSkill"]:
            named_sublists["smartSkillList"] = [
                self.build_item(element, base_tag)
                for element in context["smartSkills"].split(",")
            ]

        if context["hasSidebar"]:
            named_sublists["sidebarItemList"] = [
                self.build_item(element, base_tag)
                for element in context["sidebarItems"].split(",")
            ]

        if context["hasOperatorScreen"]:
            named_sublists["operatorScreenList"] = [
                self.build_item(element, base_tag)
                for element in context["operatorScreens"].split(",")
            ]

        if not named_sublists:
            raise UserMessageError(
                "Invalid combination chosen! Include at least one frontend component to generate a valid URCap."
                " Rerun the generator to restart"
            )
        return named_sublists

    def hook(self, context) -> None:
        if context.get("answersOk") is not None:
            if not context["answersOk"]:
                raise UserMessageError(
                    "Answers not confirmed. Rerun the generator to restart"
                )
            if not context["includeFrontend"] and not context["includeDocker"]:
                raise UserMessageError(
                    "Invalid combination chosen! Include either a frontend or a backend to generate a valid URCap. "
                    "Rerun the generator to restart"
                )

            context["artifactId"] = context.get("urcapId")

            if context["includeFrontend"]:
                named_sublists = self.create_named_sublists(context)

                context["named_sublists"] = named_sublists

                all_elements_flattened = [
                    item for sublist in named_sublists.values() for item in sublist
                ]

                context["allElementsFlattened"] = all_elements_flattened

            if not context["includeFrontend"] and context["includeDocker"]:
                context["dockerOnly"] = True
                context["FrontendType"] = ""

            if context.get("includeCustomRosTypes"):
                context["rosTypePkgName"] = self.to_ROS2_node_name(context.get("customRosTypeName"))
                # Converts the ros type name to CamelCase
                normalized = re.sub(r'[_.]', '-', context.get("customRosTypeName").strip())
                context["rosTypeMsgName"] = self.to_camelcase(normalized)

            context["ros2NodeName"] = self.to_ROS2_node_name(context.get("urcapId"))
            context["ros2NodeDesc"] = context.get("urcapId")

            # These 3 are be replaced by maven's filtering
            context["docker_developmentimage"] = "universalrobots/urcap_polyscopex_ros2:5.1.4-jazzy-dev"
            context["docker_runtimeimage"] = "universalrobots/urcap_polyscopex_ros2:5.1.4-jazzy-runtime"
            context["docker_sampleproxy"] = ""

            context["frontendId"] = context.get("urcapId") + "-frontend"
            context["backendId"] = context.get("urcapId") + "-backend"
            context["subdirectory"] = "frontend_and_backend"
