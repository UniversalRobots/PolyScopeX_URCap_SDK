import { ChangeDetectionStrategy, Component, OnChanges, signal, SimpleChanges } from '@angular/core';
import { URVariable, VariableValueType } from '@universal-robots/contribution-api';
import { createIntegerValidator } from '@universal-robots/ui-angular-components/validators';
import { DropdownOption, InputValidator, TabInputInsertableModel, TabInputValue } from '@universal-robots/ui-models';
import { CommonProgramPresenterComponent } from '../common-program-presenter.component';
import { getExpressionValidator, getVariableNameValidator } from '../validator-helper';
import { SampleLoopNode } from './loop.node';

export enum LoopType {
    ALWAYS = 'always',
    XTIMES = 'xtimes',
    EXPRESSION = 'expression',
}
@Component({
    templateUrl: './loop.component.html',
    styleUrls: ['./loop.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    standalone: false,
})
export class LoopComponent extends CommonProgramPresenterComponent<SampleLoopNode> implements OnChanges {
    validators?: Array<InputValidator<string>>;
    expressionValidator!: InputValidator<string>;
    xTimeValidator = createIntegerValidator();
    loopOptions: Array<DropdownOption> = [];
    expressionInsertables = signal<TabInputInsertableModel | undefined>(undefined);

    override onSetRobotSettings() {
        super.onSetRobotSettings();
        this.setLoopOptions();
    }

    private setLoopOptions() {
        this.loopOptions = [
            {
                label: this.translateService.instant('presenter.loop.label_dropdown.loop_always'),
                value: LoopType.ALWAYS,
            },
            {
                label: this.translateService.instant('presenter.loop.label_dropdown.loop_xtimes'),
                value: LoopType.XTIMES,
            },
            {
                label: this.translateService.instant('presenter.loop.label_dropdown.expression'),
                value: LoopType.EXPRESSION,
            },
        ];
    }

    async setType(loopOption: DropdownOption & { value: LoopType }) {
        if (!this.presenterAPI) {
            return;
        }
        if (loopOption.value === LoopType.XTIMES) {
            this.contributedNode.parameters.loopVariable = await this.presenterAPI.symbolService.generateVariable(
                'Loop',
                VariableValueType.INTEGER,
            );
        } else {
            delete this.contributedNode.parameters.loopVariable;
        }
        this.contributedNode.parameters.type = loopOption.value;
        this.saveNode();
        this.setValidators();
    }

    setXTimes(times: number) {
        this.contributedNode.parameters.xtimes = Number(times.toFixed(0));
        this.saveNode();
    }

    async ngOnChanges(changes: SimpleChanges) {
        await super.ngOnChanges(changes);
        if (this.translateService && this.presenterAPI && this.contributedNode) {
            this.setValidators();
            this.expressionInsertables.set(await this.presenterAPI.expressionEditorService?.getTabInputInsertableModel());
        }
    }

    setValidators() {
        this.validators = [getVariableNameValidator.bind(this)(this.contributedNode?.parameters?.loopVariable?.name)];
        this.expressionValidator = getExpressionValidator.bind(this)();
    }

    setVariable(name: string) {
        this.contributedNode.parameters.loopVariable = new URVariable(name, VariableValueType.INTEGER);
        this.saveNode();
    }

    setExpression(expression: TabInputValue) {
        this.contributedNode.parameters.expression = expression;
        this.saveNode();
    }
}
