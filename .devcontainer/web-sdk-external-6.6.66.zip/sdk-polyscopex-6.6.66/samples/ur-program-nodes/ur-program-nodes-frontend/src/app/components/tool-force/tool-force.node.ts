import { ForceUnit, ProgramNode, ExpressionEditorValue, TimeUnit } from '@universal-robots/contribution-api';

export interface SampleToolForceNode extends ProgramNode {
    type: 'ur-sample-node-tool-force';
    parameters: {
        x: ToolForceAxisParameter;
        y: ToolForceAxisParameter;
        z: ToolForceAxisParameter;
        zeroSensor: ToolForceZeroSensorParameter;
        selectedFrame: ToolForceFrameParameter;
    };
}

export interface ToolForceAxisParameter {
    enabled: boolean;
    value: ExpressionEditorValue;
    unit: ForceUnit;
}

export interface ToolForceZeroSensorParameter {
    enabled: boolean;
    value: ExpressionEditorValue;
    unit: TimeUnit;
}

export interface ToolForceFrameParameter {
    value: ExpressionEditorValue;
}
