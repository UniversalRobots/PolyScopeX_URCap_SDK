import {
    ApplicationNodeType,
    GridPatternNode,
    GridPatternParameters,
    ProgramBehaviorAPI,
    ProgramPresenterAPI,
    TabInputModel,
    ValidationResponse,
    VARIABLE_VALUE_TYPES,
    VariableDeclaration,
    VariableReference,
} from '@universal-robots/contribution-api';
import { SelectedInput } from '@universal-robots/ui-models';
import { getVariableDescription, validateVariable, VALIDATION_TYPE_MISMATCH } from '../variable-helper';

export const VALIDATION_OK: ValidationResponse = { isValid: true };
export const VALIDATION_MISSING_VALUE: ValidationResponse = { isValid: false, errorMessageKey: 'Missing value' };
export const VALIDATION_INVALID_GRID_PATTERN: ValidationResponse = { isValid: false, errorMessageKey: 'Invalid grid pattern' };
export const VALIDATION_INVALID_WAYPOINT: ValidationResponse = { isValid: false, errorMessageKey: 'Invalid waypoint' };

export async function validateGridPattern(name: string, api: ProgramBehaviorAPI | ProgramPresenterAPI): Promise<ValidationResponse> {
    const gridPatternNode = (await api.applicationService?.getApplicationNode(ApplicationNodeType.GRID_PATTERN)) as GridPatternNode;

    if (!gridPatternNode) {
        return VALIDATION_OK;
    }

    const grid = gridPatternNode.grids.find((grid: GridPatternParameters) => grid.grid.name === name);
    if (grid && !isValidGrid(grid)) {
        return VALIDATION_INVALID_GRID_PATTERN;
    }

    // if the grid not found on the grid pattern application node, we assume the grid pattern is valid.
    return VALIDATION_OK;
}

/**
 * Validates a value
 * @param variable the model with the value to validate
 * @param valueType the expected type of the value (typically the valueType of the node itself)
 * @param valueReference optional, used when the value is a reference to another variable (required for variable.selectedType == VARIABLE)
 * @param api optional, API instance for validation
 */
export async function validateValue(
    variable: TabInputModel<VariableDeclaration | VariableReference>,
    valueType: (typeof VARIABLE_VALUE_TYPES)[number],
    valueReference?: VariableReference,
    api: ProgramBehaviorAPI | ProgramPresenterAPI = new ProgramBehaviorAPI(globalThis),
): Promise<ValidationResponse> {
    const valueStr = variable.value.toString().trim();
    if (valueStr.length === 0 && variable.selectedType !== SelectedInput.VARIABLE) {
        return VALIDATION_MISSING_VALUE;
    }

    if (variable.selectedType === SelectedInput.VARIABLE) {
        if (valueType === 'grid') {
            const gridPatternValidation: ValidationResponse = await validateGridPattern(variable.value.toString(), api);
            if (!gridPatternValidation.isValid) {
                return gridPatternValidation;
            }
        }

        const validation: ValidationResponse = await validateVariable(valueReference, [valueType], api.variableService);
        if (!validation.isValid) {
            return validation;
        }
    }

    if (variable.selectedType === SelectedInput.VALUE) {
        const validationFunction = validationFunctionsMap.get(valueType);
        if (validationFunction?.(valueStr) === false) {
            return VALIDATION_TYPE_MISMATCH;
        }
    }

    if (variable.entity._IDENTIFIER !== 'VariableReference') {
        return VALIDATION_OK;
    }
    const variableDescription = await getVariableDescription(variable.entity, api.variableService);
    if (valueType !== variableDescription?.valueType) {
        return VALIDATION_TYPE_MISMATCH;
    }

    // If reaching this point, the value is a string or an Expression.
    return VALIDATION_OK;
}

const validationFunctionsMap = new Map([
    ['integer', isValidInteger],
    ['float', isValidNumber],
]);

function isValidGrid(gridPattern: GridPatternParameters): boolean {
    // A grid pattern needs to have at least some corner positions defined.
    if (!gridPattern.corners.length) {
        return false;
    }

    // Determine whether the grid pattern is 1D (single row or column) or 2D (matrix).
    // 1D grids need at least 2 corners.
    // 2D grids need at least 4 corners.
    const columns = gridPattern.numColumns;
    const rows = gridPattern.numRows;
    const requiredCorners = columns === 1 || rows === 1 ? 2 : 4;

    const hasRequiredCorners = gridPattern.corners.length >= requiredCorners;

    // Every corner must be defined to be a valid grid.
    const hasValidCorners = gridPattern.corners.every((corner) => !!corner);

    return hasRequiredCorners && hasValidCorners;
}

function isValidNumber(value: string): boolean {
    return !Number.isNaN(Number(value));
}

function isValidInteger(value: string): boolean {
    return isValidNumber(value) && Number.isInteger(Number(value));
}
