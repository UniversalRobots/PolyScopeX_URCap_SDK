import { ChangeDetectionStrategy, Component, computed, Signal, signal } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { combineLatest, filter, map, Observable, startWith, switchMap } from 'rxjs';
import {
    isVariableReference,
    isWaypoint,
    MoveScreenOptions,
    VARIABLE_VALUE_TYPES,
    VariableDeclaration,
    VariableDescriptionWithReference,
    VariableReference,
    WaypointType,
} from '@universal-robots/contribution-api';
import {
    DropdownOption,
    InputValidator,
    SelectedInput,
    SelectedType,
    TabInputInsertableModel,
    TabInputValue,
    TabInputVariable,
} from '@universal-robots/ui-models';
import { CommonProgramPresenterComponent } from '../common-program-presenter.component';
import { mapVariablesToTabInputVariables } from '../tabinput-helper';
import { getVariableNameValidator } from '../validator-helper';
import { SampleAssignmentNode } from './assignment.node';
import { validateValue } from './helpers';

@Component({
    templateUrl: './assignment.component.html',
    styleUrls: ['./assignment.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    standalone: false,
})
export class AssignmentComponent extends CommonProgramPresenterComponent<SampleAssignmentNode> {
    private readonly variables$ = this.api$.pipe(
        switchMap((api) => api.variableService.variables()),
        map((variables) => variables.filter((variable) => variable.valueType !== 'frame' && variable.valueType !== 'profile')),
    );
    private readonly variables: Signal<VariableDescriptionWithReference[]> = toSignal(this.variables$, { initialValue: [] });
    private readonly nodeVariableDescription$: Observable<VariableDescriptionWithReference> = combineLatest([
        this.node$,
        this.api$,
        this.variables$.pipe(filter((variables) => variables.length > 0)),
    ]).pipe(
        filter(([node]) => !!node?.parameters?.variable?.entity),
        map(([node, api]) => ({ entity: node.parameters.variable.entity as VariableReference, api })),
        switchMap(({ entity, api }) => api.variableService.getVariableDescription(entity)),
        filter((variable) => !!variable),
    );

    /*
     * Variable selection/creation:
     */
    public variableOptions: Signal<DropdownOption[]> = toSignal(
        combineLatest([this.variables$, this.nodeVariableDescription$.pipe(startWith(undefined))]).pipe(
            map(([variables, selectedVariable]) => {
                const options = variables.map((variable) => ({
                    label: variable.name,
                    value: variable.name,
                    invalid: variable.programNodeMetadata?.isSuppressed === true || variable.isDeleted === true,
                }));
                if (!selectedVariable?.name || options.some((option) => option.label === selectedVariable.name)) {
                    return options;
                }

                return [...options, { label: selectedVariable.name, value: selectedVariable.name, invalid: true }];
            }),
        ),

        { initialValue: [] },
    );
    public variableNameValidator: InputValidator<string> = getVariableNameValidator.bind(this)();
    public variableDropdown = signal<{ label: string; icon: string }>({
        label: this.translateService.instant('presenter.assignment.variable_dropdown.new'),
        icon: 'pencil',
    });
    public nodeVariable: Signal<VariableDescriptionWithReference | undefined> = toSignal(this.nodeVariableDescription$);

    public async createVariable(varName: string) {
        if (this.api() === undefined) {
            return;
        }

        if (this.contributedNode.parameters.variable.entity._IDENTIFIER === 'VariableDeclaration') {
            // If the variable is currently a declaration, this is a rename operation.

            const renamedVariable: VariableDeclaration | undefined = await this.api()?.variableService.renameVariable(
                this.contributedNode.parameters.variable.entity,
                varName,
            );
            if (renamedVariable) {
                this.contributedNode.parameters.variable.entity = renamedVariable;
                this.saveNode();
                return;
            }
        }

        const newVariable: VariableDeclaration | undefined = await this.api()?.variableService.createVariable(
            varName,
            this.contributedNode.parameters.valueType,
        );

        if (newVariable) {
            this.contributedNode.parameters.variable.entity = newVariable;
            this.saveNode();
        }
    }

    public variableDropdownOpen() {
        this.variableDropdown.set(
            isVariableReference(this.contributedNode.parameters.variable.entity)
                ? { label: this.translateService.instant('presenter.assignment.variable_dropdown.new'), icon: 'plus' }
                : { label: this.translateService.instant('presenter.assignment.variable_dropdown.rename'), icon: 'pencil' },
        );
    }

    public async selectVariable(variableOption: DropdownOption) {
        if (variableOption.label === this.nodeVariable()?.name) {
            return;
        }

        const selectedVariable: VariableDescriptionWithReference | undefined = this.getVariableByName(
            variableOption.label,
            this.variables(),
        );
        if (!selectedVariable) {
            return;
        }

        this.contributedNode.parameters.variable.entity = { ...selectedVariable.reference };

        if (this.contributedNode.parameters.valueType !== selectedVariable.valueType) {
            this.contributedNode.parameters.variable.value = this.resetValue(selectedVariable.valueType);
        }

        this.contributedNode.parameters.valueType = selectedVariable.valueType;

        if (selectedVariable?.valueType === 'waypoint') {
            this.contributedNode.parameters.waypointType = WaypointType.Teach;
        }
        this.saveNode();
    }

    /*
     * Value type selection:
     * Set by user if variable is a declaration, otherwise read-only, inherited from the referenced variable.
     */
    public variableTypeTranslationFactory = (variableType: string) => this.translateService.instant('variable-type.' + variableType);
    public variableValueTypes = Object.values(VARIABLE_VALUE_TYPES)
        .filter((val) => val !== 'frame' && val !== 'profile')
        .sort((a, b) => a.localeCompare(b));
    public isVariableReference = isVariableReference;

    /**
     * For variable declarations, sets
     * - the valueType
     * - resets the value and selectedType (selected tapInput tap type) accordingly
     * - updates the last known valueType of the node, for validation purposes
     * - if waypoint, sets waypointType to Teach
     * */
    public setType(valueType: (typeof VARIABLE_VALUE_TYPES)[number]) {
        const newSelectedType: SelectedType =
            new Map<string, SelectedType>([
                ['integer', SelectedInput.VALUE],
                ['float', SelectedInput.VALUE],
                ['string', SelectedInput.VALUE],
            ]).get(valueType) ?? SelectedInput.EXPRESSION;

        if (valueType === 'waypoint') {
            this.contributedNode.parameters.waypointType = WaypointType.Teach;
        }

        (this.contributedNode.parameters.variable.entity as VariableDeclaration).valueType = valueType;
        this.contributedNode.parameters.variable.selectedType = newSelectedType;
        this.contributedNode.parameters.variable.value = this.resetValue(valueType);
        this.contributedNode.parameters.valueType = valueType;

        this.saveNode();
    }

    /*
     * All variables, excluding this node's variable
     */
    private readonly filteredVariables: Signal<VariableDescriptionWithReference[]> = toSignal(
        combineLatest([this.node$.pipe(map((node) => node.parameters.variable.entity)), this.api$, this.variables$]).pipe(
            switchMap(async ([nodeVariable, api, variables]) => {
                const variableDescription = await api.variableService.getVariableDescription(nodeVariable as VariableReference);

                return variables.filter((variable) => variable.name !== variableDescription?.name);
            }),
        ),
        { initialValue: [] },
    );

    /** Variables for ur-tab-input (TabInputVariable[] with suppressed from programNodeMetadata). */
    public tabInputVariables: Signal<TabInputVariable[]> = computed(() => mapVariablesToTabInputVariables(this.filteredVariables()));

    public expressionInsertables: Signal<TabInputInsertableModel> = toSignal(
        this.api$.pipe(switchMap((api) => api.expressionEditorService.getTabInputInsertableModel())),
        { initialValue: { functions: [], variables: [], inputs: [], outputs: [], builtins: [] } },
    );
    public tabInputValueTabValidators: Signal<Array<InputValidator>> = toSignal(
        combineLatest([this.node$, this.settings$]).pipe(
            map(() => [
                (input) => {
                    if ((input as string).length === 0) {
                        return this.translateService.instant('presenter.assignment.empty_expression_error');
                    }
                    return null;
                },
                (input) => {
                    if (this.contributedNode.parameters.valueType === 'integer' && !Number.isInteger(Number(input))) {
                        return this.translateService.instant('presenter.assignment.integer_error');
                    }
                    return null;
                },
            ]),
        ),
        { initialValue: [] },
    );
    public tabInputValue: Signal<TabInputValue> = computed(() => {
        const { valueReference, variable } = this.node()?.parameters ?? {};

        let value = variable?.value ?? '';

        if (valueReference) {
            const valueVariable = this.getVariableById(valueReference?.id, this.variables());
            value = valueVariable?.name ?? this.translateService.instant('select');
        }

        return { value, selectedType: variable?.selectedType ?? SelectedInput.VALUE };
    });
    public precision = computed(() => {
        const variable = this.nodeVariable();
        if (variable?.valueType === 'integer') {
            return 0;
        }
        if (variable?.valueType === 'float') {
            return 10;
        }
        return null;
    });
    public isTapInputValid: Signal<boolean> = toSignal(
        // re-validate when either the node or variables change, as both can affect the validity of the value input.
        combineLatest([this.node$, this.variables$]).pipe(
            switchMap(() =>
                validateValue(
                    this.contributedNode.parameters.variable,
                    this.contributedNode.parameters.valueType,
                    this.contributedNode.parameters.valueReference,
                    this.api(),
                ),
            ),
            map((validation) => validation.isValid),
        ),
        { initialValue: true },
    );

    public tabInputValueChanged(input: TabInputValue) {
        const nodeVariable = this.contributedNode.parameters.variable;

        nodeVariable.selectedType = input.selectedType;

        if (input.selectedType === 'VALUE') {
            switch (this.nodeVariable()?.valueType) {
                case 'integer':
                    nodeVariable.value = Number.parseInt(input.value as string, 10);
                    break;
                case 'float':
                    nodeVariable.value = Number.parseFloat(input.value as string);
                    break;
                default:
                    nodeVariable.value = String(input.value);
            }
        }

        if (input.selectedType === 'VARIABLE') {
            const referencedVariable = this.getVariableByName(String(input.value), this.variables());
            if (!referencedVariable) {
                return;
            }

            this.contributedNode.parameters.valueReference = { ...referencedVariable.reference };
        } else {
            delete this.contributedNode.parameters.valueReference;
        }

        if (input.selectedType === 'EXPRESSION') {
            nodeVariable.value = String(input.value);
        }

        this.contributedNode.parameters.valueType = this.nodeVariable()?.valueType ?? 'string';

        this.saveNode();
    }

    /*
     * Value input, waypoint:
     */
    public selectedWaypointSource: Signal<(DropdownOption & { value: WaypointType }) | undefined> = toSignal(
        this.node$.pipe(
            map((node) => this.wayPointSources.find((source) => source.value === node.parameters.waypointType)),
            filter((dropdownOption) => !!dropdownOption),
            map((dropdownOption) => {
                return { value: this.contributedNode.parameters.waypointType, label: dropdownOption.label };
            }),
        ),
    );
    public wayPointSources: DropdownOption[] = [
        {
            label: this.translateService.instant('presenter.assignment.label.teach'),
            value: WaypointType.Teach,
        },
        {
            label: this.translateService.instant('presenter.assignment.label.set_expression'),
            value: WaypointType.Expression,
        },
    ];

    public setWaypointSource(value: WaypointType) {
        this.contributedNode.parameters.waypointType = value;
        this.saveNode();
    }

    public async openMoveScreen() {
        const variableName = this.nodeVariable()?.name;

        if (!variableName || this.api() === undefined) {
            return;
        }

        window.parent.performance.mark('setWaypointStart');
        const storedWaypoint = this.contributedNode.parameters.waypoint;
        const options: MoveScreenOptions = {
            moveScreenTarget: 'waypoint',
            moveScreenTargetLabel: variableName,
            frame: storedWaypoint?.frame,
            tcp: storedWaypoint?.tcp,
            position: isWaypoint(storedWaypoint) ? storedWaypoint : undefined,
        };
        const newWaypoint = await this.api()?.robotMoveService.openMoveScreen(options);

        if (isWaypoint(newWaypoint)) {
            this.contributedNode.parameters.waypoint = newWaypoint;
            this.saveNode();
        }
    }

    private resetValue(newValueType: (typeof VARIABLE_VALUE_TYPES)[number]): number | string {
        // If changing to a variable with a different type, reset the value accordingly.
        const newValue: string | number =
            new Map<string, number | string>([
                ['integer', 0],
                ['float', 0],
                ['string', ''],
            ]).get(newValueType) ?? ''; /* reset to empty value if 'complex' type */

        return newValue;
    }

    private getVariableById(id: string, variables: VariableDescriptionWithReference[]): VariableDescriptionWithReference | undefined {
        return variables.find((variable) => variable.reference?.id === id);
    }

    private getVariableByName(name: string, variables: VariableDescriptionWithReference[]): VariableDescriptionWithReference | undefined {
        return variables.find((variable) => variable.name === name);
    }
}
