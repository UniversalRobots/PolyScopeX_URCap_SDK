import { firstValueFrom } from 'rxjs';
import {
    ProgramBehaviorAPI,
    ValidationResponse,
    VariableDeclaration,
    VariableDescriptionWithReference,
    VariableReference,
    VariableService,
    VARIABLE_VALUE_TYPES,
} from '@universal-robots/contribution-api';

export type VariableValueTypeUnion = (typeof VARIABLE_VALUE_TYPES)[number];

export const VALIDATION_VARIABLE_SUPPRESSED: ValidationResponse = { isValid: false, errorMessageKey: 'Variable is suppressed' };
export const VALIDATION_TYPE_MISMATCH: ValidationResponse = { isValid: false, errorMessageKey: 'Assigned value type mismatch' };
export const VALIDATION_VARIABLE_NOT_FOUND: ValidationResponse = { isValid: false, errorMessageKey: 'Variable not found' };
export const VALIDATION_VARIABLE_MISSING_REFERENCE: ValidationResponse = { isValid: false, errorMessageKey: 'Variable missing reference' };
export const VALIDATION_VARIABLE_DELETED: ValidationResponse = { isValid: false, errorMessageKey: 'Variable is deleted' };

export async function lookupByName(
    variableName: string,
    api: ProgramBehaviorAPI = new ProgramBehaviorAPI(globalThis),
): Promise<VariableDescriptionWithReference | undefined> {
    const variables = await firstValueFrom(api.variableService.variables());
    return variables.find((v) => v.name === variableName);
}

export function lookupByReference(
    reference: VariableReference,
    variables: VariableDescriptionWithReference[],
): VariableDescriptionWithReference | undefined {
    return variables.find((variable) => variable.reference.id === reference.id);
}

export async function getName(
    variable: VariableReference | VariableDeclaration,
    variableService: VariableService = new ProgramBehaviorAPI(globalThis).variableService,
): Promise<string | undefined> {
    if (Object.hasOwn(variable, 'name')) {
        return (variable as VariableDeclaration).name;
    }

    const variableWithDescription = await getVariableDescription(variable as VariableReference, variableService);
    return variableWithDescription?.name;
}

export async function getVariableDescription(
    entity: VariableReference,
    variableService: VariableService = new ProgramBehaviorAPI(globalThis).variableService,
): Promise<VariableDescriptionWithReference | undefined> {
    return variableService.getVariableDescription(entity);
}

export async function validateVariable(
    reference: VariableReference | undefined,
    acceptedTypes: (typeof VARIABLE_VALUE_TYPES)[number][],
    variableService: VariableService = new ProgramBehaviorAPI(globalThis).variableService,
): Promise<ValidationResponse> {
    if (!reference) {
        return VALIDATION_VARIABLE_MISSING_REFERENCE;
    }

    const variableDescription = await variableService.getVariableDescription(reference);

    if (!variableDescription) {
        return VALIDATION_VARIABLE_NOT_FOUND;
    }

    if (variableDescription.programNodeMetadata?.isSuppressed) {
        return VALIDATION_VARIABLE_SUPPRESSED;
    }

    if (variableDescription.isDeleted) {
        return VALIDATION_VARIABLE_DELETED;
    }

    const isValidType = acceptedTypes.includes(variableDescription.valueType);
    if (!isValidType) {
        return VALIDATION_TYPE_MISMATCH;
    }

    return { isValid: true };
}

export async function getType(
    variable: VariableReference | VariableDeclaration,
    variableService: VariableService = new ProgramBehaviorAPI(globalThis).variableService,
): Promise<VariableValueTypeUnion | undefined> {
    if (Object.hasOwn(variable, 'valueType')) {
        return (variable as VariableDeclaration).valueType;
    }

    const variableWithDescription = await getVariableDescription(variable as VariableReference, variableService);
    return variableWithDescription?.valueType;
}

export async function fetchRegisteredVariables(
    variableService: VariableService = new ProgramBehaviorAPI(globalThis).variableService,
): Promise<VariableDescriptionWithReference[]> {
    return firstValueFrom(variableService.variables());
}

export async function isRegistered(
    entity: VariableReference | VariableDeclaration,
    variableService: VariableService = new ProgramBehaviorAPI(globalThis).variableService,
): Promise<boolean> {
    const variableName = await getName(entity, variableService);
    const registeredVariables = await fetchRegisteredVariables(variableService);
    return registeredVariables.some((v) => v.name === variableName);
}
/**
 *
 * @param name: string - the name of the variable to upgrade
 * @param variableService - VariableService instance set by factory
 * @returns
 */
export async function upgradeVariable(
    name: string,
    variableService: VariableService = new ProgramBehaviorAPI(globalThis).variableService,
): Promise<VariableDeclaration | VariableReference | undefined> {
    const legacyVar = { name, type: '$$Variable', reference: true };
    return variableService.upgradeURVariable(legacyVar as any);
}
