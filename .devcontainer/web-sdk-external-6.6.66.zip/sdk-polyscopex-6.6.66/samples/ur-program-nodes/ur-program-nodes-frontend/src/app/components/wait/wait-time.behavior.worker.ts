import { ScriptBuilder, TabInputModel, Time, VariableValueType } from '@universal-robots/contribution-api';
import { SelectedInput } from '@universal-robots/ui-models';
import { getName, validateVariable } from '../variable-helper';
import { WaitTypeStrategy } from './wait-type-handler.interface';
import { TIME_RANGE } from './wait.constants';
import { SampleWaitNode } from './wait.node';

const MILLIS_TO_SECONDS = 1000;

export const TimeStrategy: WaitTypeStrategy = {
    programNodeLabel: async (node) => {
        if (!TabInputModel.isTabInputModel<Time>(node.parameters.time)) {
            return [{ type: 'primary', value: '' }];
        }
        return [{ type: 'secondary', value: await formatLabel(node) }];
    },

    validator: async (node) => {
        const time = node.parameters.time;

        if (time?.value == null) {
            return { isValid: false };
        }

        if (time.selectedType === 'VARIABLE' && node.parameters.reference?.valueReference) {
            return validateVariable(node.parameters.reference.valueReference, [VariableValueType.FLOAT, VariableValueType.INTEGER]);
        }

        if (time.selectedType === 'EXPRESSION') {
            const expression = time.value?.toString().trim() ?? '';
            return { isValid: expression.length > 0 };
        }

        const waitTime = time?.entity.unit === 's' ? Number(time?.value) : time?.entity.value / MILLIS_TO_SECONDS;

        if (waitTime > TIME_RANGE.max) {
            return { isValid: false, errorMessageKey: 'Time must be 24 hours or less' };
        }
        if (waitTime < TIME_RANGE.min) {
            return { isValid: false, errorMessageKey: 'Time must be 0 ms or greater' };
        }

        return { isValid: true };
    },

    generateCodeBeforeChildren: async (node) => {
        const time = node.parameters.time;
        if (!time) {
            return new ScriptBuilder();
        }

        let valueToUse: string | number = time.value as string | number;
        if (time.selectedType === 'VARIABLE' && node.parameters.reference?.valueReference) {
            const variableName = await getName(node.parameters.reference.valueReference);
            if (variableName) {
                valueToUse = variableName;
            }
        }
        return new ScriptBuilder().sleep(valueToUse);
    },
};

async function formatLabel(node: SampleWaitNode): Promise<string> {
    const time = node.parameters.time;
    if (!time) {
        return '';
    }
    const labelFormatters: Record<string, () => string | Promise<string>> = {
        [SelectedInput.VALUE]: () => `${Number(time.entity.value).toFixed(2)} ${time.entity.unit}`,
        [SelectedInput.VARIABLE]: async () => {
            const variableName = node.parameters.reference?.valueReference ? await getName(node.parameters.reference.valueReference) : '';
            return `Variable: ${variableName}`;
        },
        [SelectedInput.EXPRESSION]: () => `Expression: ${time.value}`,
    };
    return (await labelFormatters[time.selectedType]?.()) ?? '';
}
