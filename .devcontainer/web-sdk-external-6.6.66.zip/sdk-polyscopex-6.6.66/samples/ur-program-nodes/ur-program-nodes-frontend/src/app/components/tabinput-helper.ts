import {
    AllUnits,
    convertValue,
    TabInputModel,
    Value,
    valueFixedConverter,
    VariableDescriptionWithReference,
} from '@universal-robots/contribution-api';
import { SelectedInput, TAB_INPUT_VALUE_TYPES, TabInputValue, TabInputValueType, TabInputVariable } from '@universal-robots/ui-models';
import { Unit } from '@universal-robots/utilities-units';

/**
 * Maps a variable value type (e.g. from contribution-api) to TabInputValueType.
 */
export function toTabInputValueType(valueType: string): TabInputValueType {
    return TAB_INPUT_VALUE_TYPES.includes(valueType as TabInputValueType) ? (valueType as TabInputValueType) : 'string';
}

/**
 * Maps an array of variable-like objects to TabInputVariable[] for use with ur-tab-input.
 * Uses programNodeMetadata?.isSuppressed ?? suppressed ?? false for the suppressed flag.
 */
export function mapVariablesToTabInputVariables(variables: VariableDescriptionWithReference[]): TabInputVariable[] {
    return variables.map(
        (v): TabInputVariable => ({
            name: v.name,
            valueType: toTabInputValueType(v.valueType),
            suppressed: v.programNodeMetadata?.isSuppressed ?? false,
            isDeleted: v.isDeleted ?? false,
        }),
    );
}

export function getConvertedTabInputValue(val: TabInputModel<Value>, rawConverter: (value: Value) => number) {
    if (!val) {
        return {
            selectedType: SelectedInput.VALUE,
            value: '0',
        };
    }

    const tmp = { ...val };

    if (tmp.selectedType === SelectedInput.VALUE) {
        tmp.value = rawConverter(tmp.entity);
    }

    return TabInputModel.getTabInputValue(tmp);
}

export function getConvertedTabInputValueWithUnit(val: TabInputModel<Value>, unit: Unit) {
    return getConvertedTabInputValue(val, (value: Value) => valueFixedConverter(value, unit));
}

export function setConvertedTabInputValueWithUnit(
    model: TabInputModel<Value>,
    newValue: TabInputValue,
    currentUnit: Unit,
    toUnit: AllUnits,
) {
    const inputValue = newValue.value;

    model.selectedType = newValue.selectedType;
    if (newValue.selectedType === SelectedInput.VALUE) {
        const convertedValue = convertValue({ value: Number(inputValue), unit: currentUnit.label }, toUnit);
        model.entity = convertedValue;
        model.value = convertedValue.value;
    } else {
        model.value = inputValue;
    }
}
