import { ValueRange } from '@universal-robots/contribution-api';

export const TIME_RANGE: ValueRange = { min: 0, max: 86400, unit: 's' };
