import { ChangeDetectionStrategy, Component, computed, inject, OnChanges, resource, Signal, signal, SimpleChanges } from '@angular/core';
import { toObservable, toSignal } from '@angular/core/rxjs-interop';
import { combineLatest, filter, firstValueFrom, map, mergeMap, of, switchMap } from 'rxjs';
import {
    Signal as SourceSignal,
    SignalDirectionEnum,
    SignalValue,
    SignalValueTypeEnum,
    Source,
    Value,
    ValueRange,
    VariableDescriptionWithReference,
} from '@universal-robots/contribution-api';
import { URPortalService, URTabInputContainerComponent } from '@universal-robots/ui-angular-components';
import {
    DropdownOption,
    SelectedInput,
    TabInputData,
    TabInputInsertableModel,
    TabInputValue,
    TabInputValueType,
    TabInputVariable,
} from '@universal-robots/ui-models';
import { CommonProgramPresenterComponent } from '../common-program-presenter.component';
import { mapVariablesToTabInputVariables } from '../tabinput-helper';
import { getName, lookupByName, validateVariable } from '../variable-helper';
import { SampleSetNode, SampleSetNodeVariableReference } from './set.node';

type SourceDropdownOption = DropdownOption & { groupId: string; groupIdName: string; value: string };

@Component({
    templateUrl: './set.component.html',
    styleUrls: ['./set.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    standalone: false,
})
export class SetComponent extends CommonProgramPresenterComponent<SampleSetNode> implements OnChanges {
    private dialogService = inject(URPortalService);

    variables: Signal<VariableDescriptionWithReference[]> = toSignal(
        this.api$.pipe(
            switchMap((api) => api.variableService.variables({ includeDeleted: true })),
            filter((variables): variables is VariableDescriptionWithReference[] => variables != undefined),
            map((variables) => variables.filter((variable) => variable.valueType !== 'frame' && variable.valueType !== 'profile')),
        ),
        { initialValue: [] },
    );

    tabInputVariables: Signal<TabInputVariable[]> = computed(() => mapVariablesToTabInputVariables(this.variables()));

    selectedSignalOutput = computed(() => this.node()?.parameters.signalOutput);
    isValid = resource({
        params: () => ({ value: this.selectedSignalOutput()?.value }),
        loader: ({ params }) => {
            return this.validateSignal(params.value);
        },
    });
    expressionInsertables = signal<TabInputInsertableModel | undefined>(undefined);

    selectedSourceSignal = computed(() =>
        this.signals()?.find((sourceSignal) => sourceSignal.signalID === this.selectedSignalOutput()?.signalID),
    );
    selectedSourceOption = computed(() => this.sourcesOptions()?.find((option) => option.value === this.selectedSignalOutput()?.sourceID));

    sourcesOptions = computed(() =>
        Object.entries(this.sources()).flatMap(([groupId, sources]) =>
            sources.map((source) => ({
                label: groupId === 'robot' ? this.translateService.instant(source.sourceID) : source.name || source.sourceID,
                value: source.sourceID,
                groupId,
                groupIdName:
                    groupId === 'robot'
                        ? this.translateService.instant(`communication.nodes.robot.title`)
                        : this.sourceNodeLabels()[groupId] || groupId,
            })),
        ),
    );

    selectedSignalValueType = computed(() => this.typeMap[this.selectedSignalType() || 'DEFAULT']);

    selectedSignalType = computed(
        () => this.signals()?.find((signal) => signal.signalID === this.selectedSignalOutput()?.signalID)?.valueType,
    );

    selectedSignalOption = computed(() => {
        const signalOutput = this.selectedSignalOutput();
        const value = signalOutput?.value;
        if (value !== undefined && value !== null) {
            const option = this.digitalValueOptions().find((opt) => opt.value === value);
            if (option) {
                return option;
            }
        }
        const displayName = this.node()?.parameters.reference ? this.resolvedVariableName() : value;
        if (displayName != null && displayName !== '') {
            const invalid = typeof displayName === 'number' ? false : !this.isVariableAvailable(String(displayName));
            return {
                label: `${displayName}`,
                value: displayName,
                invalid,
            };
        }
        return undefined;
    });

    selectedSignalTabOption = computed(() => {
        const signalOutput = this.selectedSignalOutput();
        const selectedType = signalOutput?.selectedType;
        const value =
            selectedType === 'VARIABLE' && this.node()?.parameters.reference
                ? (this.resolvedVariableName() ?? 'undefined')
                : ((signalOutput?.value as Value)?.value ?? signalOutput?.value ?? 'undefined');
        return { selectedType, value };
    });

    digitalValueOptions = computed(() => {
        this.onLangChange();
        const options: Array<DropdownOption> = [
            { label: this.translateService.instant('high'), value: true },
            { label: this.translateService.instant('low'), value: false },
        ];
        if (this.selectedSignalOutput()?.signalValueType !== SignalValueTypeEnum.CUSTOM) {
            return options;
        }
        const selectedType = this.node()?.parameters.signalOutput?.selectedType;
        const displayName = this.resolvedVariableName() ?? this.selectedSignalOutput()?.value;
        if (displayName != null && displayName !== '') {
            const invalid = selectedType === 'EXPRESSION' ? false : !this.isVariableAvailable(String(displayName));
            options.push({
                label: `${displayName}`,
                value: displayName,
                invalid: invalid,
            });
        }
        return options;
    });

    sourceNodeLabels: Signal<{ [groupId: string]: string }> = toSignal(
        this.api$.pipe(switchMap((presenterAPI) => presenterAPI?.sourceService.sourceNodeLabels() ?? of({}))),
        { initialValue: {} },
    );

    sources: Signal<{ [groupId: string]: Array<Source> }> = toSignal(
        this.api$.pipe(
            switchMap((presenterAPI) =>
                presenterAPI.sourceService.sources({
                    direction: SignalDirectionEnum.OUT,
                }),
            ),
        ),
        { initialValue: {} },
    );
    signals = toSignal(
        combineLatest([toObservable(this.selectedSignalOutput), this.api$]).pipe(
            mergeMap(([selectedSignalOutput, presenterAPI]) => {
                if (!selectedSignalOutput) {
                    return [];
                }
                const { groupId, sourceID } = selectedSignalOutput;
                if (presenterAPI && groupId && sourceID) {
                    return firstValueFrom(
                        presenterAPI.sourceService.sourceSignals(groupId, sourceID, {
                            direction: SignalDirectionEnum.OUT,
                        }),
                    );
                }
                return [];
            }),
            map((signals) =>
                signals.filter((signal) =>
                    [SignalValueTypeEnum.BOOLEAN, SignalValueTypeEnum.FLOAT, SignalValueTypeEnum.REGISTER].some(
                        (valueType) => valueType === signal.valueType,
                    ),
                ),
            ),
            mergeMap((signals) => this.filterSafetyOutputs(signals)),
        ),
    );
    domains: Signal<Record<string, ValueRange> | undefined> = toSignal(
        combineLatest([toObservable(this.selectedSignalOutput), this.api$]).pipe(
            mergeMap(([selectedSignalInput, presenterAPI]) => {
                const sourceId = selectedSignalInput?.sourceID;
                if (presenterAPI && sourceId) {
                    return presenterAPI.sourceService.getSignalsDomainData(selectedSignalInput.groupId || '', sourceId);
                }
                return of({});
            }),
        ),
    );

    onLangChange = toSignal(this.translateService.onLangChange);

    readonly SignalValueType = SignalValueTypeEnum;
    readonly valueValidators = [this.validateValue.bind(this)];
    readonly onUseVariable = () => {
        this.setDigitalTabInputValue();
    };

    private readonly typeMap: { [key: string]: TabInputValueType[] } = {
        BOOLEAN: ['boolean'],
        FLOAT: ['integer', 'float'],
        REGISTER: ['integer', 'float'],
        DEFAULT: ['integer', 'float', 'string', 'boolean'],
    };

    async ngOnChanges(changes: SimpleChanges) {
        await super.ngOnChanges(changes);

        if (changes.presenterAPI) {
            this.expressionInsertables.set(await changes.presenterAPI.currentValue.expressionEditorService?.getTabInputInsertableModel());
        }
    }

    signalLabelFactory = (signal: SourceSignal) => signal?.name || signal.signalID;

    digitalValueFactory = (option: any) =>
        option.value === 'custom' && this.selectedSignalOutput()?.signalValueType === SignalValueTypeEnum.CUSTOM
            ? this.selectedSignalOutput()?.value
            : option.label;

    async setSourceID($event: SourceDropdownOption) {
        if (!this.contributedNode.parameters.signalOutput) {
            return;
        }
        this.contributedNode.parameters.signalOutput.sourceID = $event.value;
        this.contributedNode.parameters.signalOutput.groupId = $event.groupId;
        this.contributedNode.parameters.signalOutput.signalID = undefined;
        this.contributedNode.parameters.signalOutput.value = undefined;
        this.contributedNode.parameters.signalOutput.selectedType = undefined;
        this.contributedNode.parameters.signalOutput.signalValueType = undefined;
        this.contributedNode.parameters.reference = undefined;
        this.saveNode();
    }

    setSignalID($event: SourceSignal) {
        if (!this.contributedNode.parameters.signalOutput) {
            return;
        }

        const previousSignalValueType = this.contributedNode.parameters.signalOutput.signalValueType ?? $event.valueType;
        this.contributedNode.parameters.signalOutput.signalID = $event.signalID;

        this.resetSignalOutputValue($event.valueType, $event.signalID, previousSignalValueType);
        this.saveNode();
    }

    async setValue($event: TabInputValue) {
        if (this.selectedSignalType() === SignalValueTypeEnum.REGISTER) {
            await this.setRegisterValue($event);
            return;
        }
        await this.setAnalogTabInput($event);
    }

    async setDigitalValue($event: DropdownOption) {
        if (!this.contributedNode.parameters.signalOutput) {
            return;
        }

        if (typeof $event.value === 'boolean') {
            this.contributedNode.parameters.signalOutput = {
                ...this.contributedNode.parameters.signalOutput,
                value: $event.value,
                signalValueType: SignalValueTypeEnum.BOOLEAN,
                selectedType: undefined,
            };
            this.saveNode();
        }
    }

    validateValue(val: number) {
        const signalDomainData = getSignalValueRange(this.domains(), this.contributedNode.parameters.signalOutput?.signalID);
        if (signalDomainData !== undefined) {
            return this.getDomainDataErrorString(val, signalDomainData);
        }
        return null;
    }

    async validateSignal(value: SignalValue | undefined): Promise<boolean> {
        const signalOutput = this.selectedSignalOutput();
        if (!signalOutput?.groupId || !signalOutput?.sourceID || !signalOutput.signalID) {
            return false;
        }
        const api = this.api();
        const node = this.node();
        if (!api || !node) {
            return false;
        }

        value = value ?? '';

        if (
            signalOutput.selectedType === 'VARIABLE' &&
            (signalOutput.signalValueType === SignalValueTypeEnum.FLOAT || signalOutput.signalValueType === SignalValueTypeEnum.REGISTER) &&
            node.parameters.reference
        ) {
            const validation = await validateVariable(node.parameters.reference.valueReference, ['float', 'integer'], api.variableService);
            if (!validation.isValid) {
                return validation.isValid;
            }
            value = (await getName(node.parameters.reference.valueReference, api.variableService)) ?? value;
        }

        const validationResponse = await api.sourceService.validateSetSignal(
            signalOutput.groupId,
            signalOutput.sourceID,
            signalOutput.signalID,
            value,
        );
        return !!validationResponse?.isValid;
    }

    getAnalogUnit() {
        const domain = getSignalValueRange(this.domains(), this.contributedNode.parameters.signalOutput?.signalID);
        if (domain !== undefined && this.selectedSignalOutput()?.selectedType === 'VALUE') {
            return domain.unit;
        }
        return null;
    }

    async setRegisterValue($event: TabInputValue) {
        if (this.contributedNode.parameters.signalOutput) {
            this.contributedNode.parameters.signalOutput.selectedType = $event.selectedType;
            const { value, reference } = this.getVariableReferenceValues($event, this.variables());
            this.contributedNode.parameters.signalOutput.value = value;
            this.contributedNode.parameters.reference = reference;
            this.saveNode();
        }
    }

    async setDigitalTabInputValue() {
        const inputData = this.createTabInputData();
        const { reason, returnData } = await firstValueFrom(
            this.dialogService.open<TabInputValue>(URTabInputContainerComponent, inputData).afterClose,
        );

        if (reason !== 'CONFIRMED' || !this.contributedNode.parameters.signalOutput) {
            return;
        }

        this.contributedNode.parameters.signalOutput.signalValueType = SignalValueTypeEnum.CUSTOM;
        this.contributedNode.parameters.signalOutput.selectedType = returnData?.selectedType;
        if (['VALUE', 'EXPRESSION'].includes(returnData?.selectedType ?? '')) {
            this.contributedNode.parameters.signalOutput.value = returnData?.value;
            delete this.contributedNode.parameters.reference;
        }

        if (returnData?.selectedType === 'VARIABLE' && returnData?.value != null) {
            const matchingVariable = await lookupByName(String(returnData.value), this.presenterAPI ?? this.api());
            if (matchingVariable) {
                delete this.contributedNode.parameters.signalOutput.value;
                this.contributedNode.parameters.reference = {
                    valueType: matchingVariable.valueType,
                    valueReference: matchingVariable.reference,
                } as SampleSetNodeVariableReference;
            } else {
                delete this.contributedNode.parameters.signalOutput.value;
                delete this.contributedNode.parameters.reference;
            }
        }

        this.saveNode();
    }

    private getVariableReferenceValues(
        tabInputValue: TabInputValue,
        variables: VariableDescriptionWithReference[],
    ): { value: SignalValue | undefined; reference: SampleSetNodeVariableReference | undefined } {
        if (tabInputValue.selectedType === 'VARIABLE') {
            const variableName = String(tabInputValue.value);
            const matchingVariable = variables.find((v) => v.name === variableName);
            return {
                value: undefined,
                reference: matchingVariable
                    ? { valueType: matchingVariable.valueType, valueReference: matchingVariable.reference }
                    : undefined,
            };
        }
        return {
            value: tabInputValue.value as SignalValue,
            reference: undefined,
        };
    }

    /** Resolves the current variable name from parameters.reference using the variables list (e.g. after rename). */
    resolvedVariableName = computed(() => {
        const node = this.node();
        const variables = this.variables();
        const ref = node?.parameters.reference?.valueReference;
        if (!ref?.id) {
            return undefined;
        }
        return variables.find((v) => v.reference?.id === ref.id)?.name;
    });

    private resetSignalOutputValue(valueType: SignalValueTypeEnum, signalID: string, previousSignalValueType: SignalValueTypeEnum) {
        if (!this.contributedNode.parameters.signalOutput) {
            return;
        }

        const previousValue = this.contributedNode.parameters.signalOutput.value;
        const previousSelectedType = this.contributedNode.parameters.signalOutput.selectedType;
        const hasCustomSelection = previousSelectedType === 'VARIABLE' || previousSelectedType === 'EXPRESSION';
        const isSameBaseType =
            (valueType === SignalValueTypeEnum.BOOLEAN && previousSignalValueType === SignalValueTypeEnum.CUSTOM) ||
            valueType === previousSignalValueType;

        if (hasCustomSelection && isSameBaseType) {
            if (previousSignalValueType === SignalValueTypeEnum.CUSTOM) {
                this.contributedNode.parameters.signalOutput.signalValueType = SignalValueTypeEnum.CUSTOM;
            } else {
                this.contributedNode.parameters.signalOutput.signalValueType = valueType;
            }
            return;
        }

        this.contributedNode.parameters.signalOutput.signalValueType = valueType;
        const domain = getSignalValueRange(this.domains(), signalID);
        this.contributedNode.parameters.signalOutput.selectedType = undefined;
        this.contributedNode.parameters.signalOutput.value = 0;

        if (valueType === SignalValueTypeEnum.FLOAT) {
            this.contributedNode.parameters.signalOutput.selectedType = 'VALUE';
            if (domain !== undefined) {
                this.contributedNode.parameters.signalOutput.value = {
                    value: domain.min,
                    unit: domain.unit,
                };
            }
        }

        if (valueType === SignalValueTypeEnum.BOOLEAN) {
            this.contributedNode.parameters.signalOutput.value = typeof previousValue === 'boolean' ? previousValue : true;
        }
        delete this.contributedNode.parameters.reference;
    }

    private async setAnalogTabInput($event: TabInputValue) {
        if (this.contributedNode.parameters.signalOutput === undefined) {
            return;
        }

        this.contributedNode.parameters.signalOutput.selectedType = $event.selectedType;

        if ($event.selectedType === 'VARIABLE') {
            const { value, reference } = this.getVariableReferenceValues($event, this.variables());
            this.contributedNode.parameters.signalOutput.value = value;
            this.contributedNode.parameters.reference = reference;
        } else {
            const domain = getSignalValueRange(this.domains(), this.contributedNode.parameters.signalOutput?.signalID);
            if (domain !== undefined && $event.selectedType === 'VALUE') {
                this.contributedNode.parameters.signalOutput.value = { value: Number($event.value), unit: domain.unit };
            } else {
                this.contributedNode.parameters.signalOutput.value = $event.value;
            }
            this.contributedNode.parameters.reference = undefined;
        }

        this.saveNode();
    }

    private createTabInputData(): TabInputData {
        const selectedType = this.selectedSignalOutput()?.selectedType ?? SelectedInput.VARIABLE;
        let value = this.translateService.instant('select');
        if (selectedType === 'VARIABLE') {
            value = this.resolvedVariableName() ?? value;
        } else {
            value = (this.selectedSignalOutput()?.value as string) ?? value;
        }
        return {
            inputLabel: '',
            placeholder: '',
            translations: {},
            type: 'text',
            label: this.translateService.instant('presenter.set.expression'),
            valueType: ['boolean'],
            insertables: this.expressionInsertables(),
            tabInputValue: {
                selectedType,
                value: value,
            },
            tabs: [SelectedInput.VARIABLE, SelectedInput.EXPRESSION],
        };
    }

    private isVariableAvailable(varName: string) {
        return this.variables().some((item) => item.name === varName && !item.programNodeMetadata?.isSuppressed && !item.isDeleted);
    }

    private getDomainDataErrorString(val: number, constraints: ValueRange): string | null {
        return this.getRangeErrorString(val, {
            lowerLimit: constraints.min,
            upperLimit: constraints.max,
            unit: constraints.unit,
        });
    }

    private async filterSafetyOutputs(signals: SourceSignal[]): Promise<SourceSignal[]> {
        const safetyOutputs = await this.getSafetyOutputs();
        return signals.filter((signal) => !this.isSignalUsedBySafetyIOs(signal.signalID, safetyOutputs));
    }

    private async getSafetyOutputs(): Promise<{ name: string; valueA: number; valueB: number }[]> {
        if (!this.presenterAPI) {
            return [];
        }
        const safetyIOs = await this.presenterAPI.safetyService.getIOs();
        if (safetyIOs === undefined) {
            return [];
        }
        return Object.values(safetyIOs).filter((io) => io.name.includes('Output'));
    }

    private isSignalUsedBySafetyIOs(
        signalID: string,
        safetyOutputs: {
            name: string;
            valueA: number;
            valueB: number;
        }[],
    ): boolean {
        return safetyOutputs.some((output) => 'CO ' + output.valueA === signalID || 'CO ' + output.valueB === signalID);
    }
}

const getSignalValueRange = (domains: Record<string, ValueRange> | undefined, signalID: string | undefined) => {
    if (signalID && domains && Object.hasOwnProperty.call(domains, signalID)) {
        return Reflect.get(domains, signalID) as ValueRange;
    }
    return undefined;
};
