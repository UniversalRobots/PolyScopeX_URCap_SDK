import { ChangeDetectionStrategy, Component, computed, inject, OnChanges, signal, Signal, SimpleChanges } from '@angular/core';
import { toObservable, toSignal } from '@angular/core/rxjs-interop';
import { combineLatest, firstValueFrom, map, mergeMap, of, switchMap } from 'rxjs';
import {
    floatOperators,
    registerOperator,
    registerOperators,
    SignalDirectionEnum,
    SignalValueTypeEnum,
    Source,
    Signal as SourceSignal,
    TabInputModel,
    Time,
    TimeUnit,
    Value,
    ValueRange,
} from '@universal-robots/contribution-api';
import { URPortalService, URTabInputContainerComponent } from '@universal-robots/ui-angular-components';
import { createNumberRangeValidator } from '@universal-robots/ui-angular-components/validators';
import {
    DropdownOption,
    SelectedInput,
    TabInputData,
    TabInputInsertableModel,
    TabInputValue,
    TabInputVariable,
} from '@universal-robots/ui-models';
import { s } from '@universal-robots/utilities-units';
import { CommonProgramPresenterComponent } from '../common-program-presenter.component';
import { getAcceptableTabInputTypes } from '../signal-helper';
import { lookupByName } from '../variable-helper';
import { TIME_RANGE } from './wait.constants';
import { SampleWaitNode, SampleWaitNodeVariableReference } from './wait.node';

type SourceDropdownOption = DropdownOption & { groupId: string; groupIdName: string };

@Component({
    templateUrl: './wait.component.html',
    styleUrls: ['./wait.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    standalone: false,
})
export class WaitComponent extends CommonProgramPresenterComponent<SampleWaitNode> implements OnChanges {
    dialogService = inject(URPortalService);

    selectedSignalInput = signal<SampleWaitNode['parameters']['signalInput'] | undefined>(undefined);
    selectedSourceSignal = computed(() =>
        this.signals()?.find((sourceSignal) => sourceSignal.signalID === this.selectedSignalInput()?.signalID),
    );
    selectedSourceOption = computed(() => this.sourcesOptions()?.find((option) => option.value === this.selectedSignalInput()?.sourceID));
    expressionInsertables = signal<TabInputInsertableModel | undefined>(undefined);

    // RegisterOpereator dropdown selection
    registerOperator = computed(() => {
        const valueType = this.selectedSignalType();
        const signalValueType = this.selectedSignalInput()?.signalValueType;
        if (valueType !== signalValueType) {
            return undefined;
        }
        return this.selectedSignalInput()?.registerOperator;
    });

    // Signal value input
    selectedValueOption = computed(() => {
        const selectedType = this.selectedSignalInput()?.selectedType;
        if (selectedType === 'EXPRESSION') {
            return {
                label: this.selectedSignalInput()?.value as string,
                value: this.selectedSignalInput()?.value,
                invalid: false,
            } as DropdownOption;
        }
        if (selectedType === 'VARIABLE') {
            const name = this.resolvedVariableName() ?? (this.selectedSignalInput()?.value as string);
            return {
                label: name,
                value: name,
                invalid: this.isVarSuppressed(name) || !this.varExists(name) || this.isDeletedVar(name),
            } as DropdownOption;
        }

        const { value } = this.selectedSignalInput() ?? {};
        const option = this.digitalValueOptions().find((option) => {
            if (option.value === value) {
                return option;
            }
        });
        if (option) {
            return option;
        }
        if (value) {
            return {
                label: `${value}`,
                value: value,
                invalid: this.isVarSuppressed(value as string),
            };
        }
    });

    selectedSignalTabOption = computed(() => {
        // REGISTER & FLOAT = Value ({value, unit})
        const value = (this.selectedSignalInput()?.value as Value)?.value ?? this.selectedSignalInput()?.value ?? '';

        return {
            selectedType: this.selectedSignalInput()?.selectedType,
            value,
        };
    });

    sourceNodeLabels: Signal<{ [groupId: string]: string }> = toSignal(
        toObservable(this.api).pipe(switchMap((api) => api?.sourceService.sourceNodeLabels() ?? of({}))),
        { initialValue: {} },
    );
    sourcesOptions = computed(() => {
        const options: Array<SourceDropdownOption> = [];
        Object.entries(this.sources()).forEach(([groupId, sources]) => {
            options.push(
                ...sources.map((source) => ({
                    label: groupId === 'robot' ? this.translateService.instant(source.sourceID) : source.name || source.sourceID,
                    value: source.sourceID,
                    groupId,
                    groupIdName:
                        groupId === 'robot'
                            ? this.translateService.instant(`communication.nodes.robot.title`)
                            : this.sourceNodeLabels()[groupId] || groupId,
                })),
            );
        });
        return options;
    });
    sources: Signal<{ [groupId: string]: Array<Source> }> = toSignal(
        this.api$.pipe(
            switchMap((presenterAPI) => {
                return presenterAPI.sourceService.sources({ direction: SignalDirectionEnum.IN });
            }),
        ),
        { initialValue: {} },
    );
    signals = toSignal(
        combineLatest([toObservable(this.selectedSignalInput), this.api$]).pipe(
            mergeMap(([selectedSignalInput, api]) => {
                if (!selectedSignalInput) {
                    return [];
                }
                const { groupId, sourceID } = selectedSignalInput;
                if (groupId && sourceID) {
                    return firstValueFrom(api.sourceService.sourceSignals(groupId, sourceID, { direction: SignalDirectionEnum.IN }));
                }
                return [];
            }),
            map((signals) => {
                return signals.filter((signal) =>
                    [SignalValueTypeEnum.BOOLEAN, SignalValueTypeEnum.FLOAT, SignalValueTypeEnum.REGISTER].some(
                        (valueType) => valueType === signal.valueType,
                    ),
                );
            }),
        ),
    );
    domains: Signal<Record<string, ValueRange> | undefined> = toSignal(
        combineLatest([toObservable(this.selectedSignalInput), this.api$]).pipe(
            mergeMap(([selectedSignalInput, api]) => {
                const sourceId = selectedSignalInput?.sourceID;
                if (sourceId) {
                    return api.sourceService.getSignalsDomainData(selectedSignalInput.groupId || '', sourceId);
                }
                return of({});
            }),
        ),
    );
    selectedSignalType = computed(
        () => this.signals()?.find((signal) => signal.signalID === this.selectedSignalInput()?.signalID)?.valueType,
    );

    variables = toSignal(this.api$.pipe(switchMap((api) => api.variableService.variables({ includeDeleted: true }))), { initialValue: [] });

    tabInputVariables = computed(() =>
        this.variables().map(
            (variable) =>
                ({
                    name: variable.name,
                    suppressed: variable.programNodeMetadata?.isSuppressed ?? false,
                    valueType: variable.valueType,
                    isDeleted: variable.isDeleted ?? false,
                }) as TabInputVariable,
        ),
    );

    timeVariables = computed(() => this.tabInputVariables().filter((v) => v.valueType === 'float' || v.valueType === 'integer'));

    getAnalogUnit = computed(() => {
        this.selectedSignalTabOption();
        const domain = getSignalValueRange(this.domains(), this.contributedNode.parameters.signalInput?.signalID);
        if (domain !== undefined && this.selectedSignalInput()?.selectedType === 'VALUE') {
            return domain.unit;
        }
        return undefined;
    });

    resolvedVariableName = computed(() => {
        const node = this.node();
        const variables = this.variables();
        const ref = node?.parameters.reference?.valueReference;
        if (!ref?.id) {
            return undefined;
        }
        return variables.find((v) => v.reference?.id === ref.id)?.name;
    });

    readonly s = s;
    readonly TIME_RANGE = TIME_RANGE;

    public SignalValueType = SignalValueTypeEnum;
    public typeSelection: DropdownOption[] = [];
    public valueValidators = [(val: number) => this.validateAnalogValue(val)];
    readonly floatOperators = floatOperators;
    readonly registerOperators = registerOperators;

    override onSetRobotSettings() {
        super.onSetRobotSettings();
        this.setOptions();
    }

    onUseVariable = () => {
        this.setDigitalTabInputValue();
    };

    private setOptions() {
        this.typeSelection = [
            {
                label: this.translateService.instant('presenter.wait.label.time'),
                value: 'time',
            },
            {
                label: this.translateService.instant('presenter.wait.label.signal_input'),
                value: 'signalInput',
            },
            {
                label: this.translateService.instant('presenter.wait.label.expression'),
                value: 'expression',
            },
        ];
        this.cd.detectChanges();
    }
    onLangChange = toSignal(this.translateService.onLangChange);

    digitalValueOptions = computed(() => {
        this.onLangChange();

        let options: Array<DropdownOption> = [
            {
                label: this.translateService.instant('high'),
                value: true,
            },
            {
                label: this.translateService.instant('low'),
                value: false,
            },
        ];
        const value = this.selectedSignalInput()?.value;
        if (this.selectedSignalInput()?.signalValueType === SignalValueTypeEnum.CUSTOM && value) {
            options = options.concat({
                label: `${value}`,
                value: value,
                invalid:
                    this.contributedNode.parameters.signalInput?.selectedType === 'EXPRESSION'
                        ? false
                        : this.isVarSuppressed(value as string) || !this.varExists(value as string),
            });
        }
        return options;
    });

    selectedSignalValueType = computed(() => getAcceptableTabInputTypes(this.selectedSignalType()));

    async ngOnChanges(changes: SimpleChanges) {
        await super.ngOnChanges(changes);
        if (changes.contributedNode?.isFirstChange()) {
            await this.initParamType();
            this.cd.detectChanges();
        }

        if (changes.presenterAPI) {
            this.expressionInsertables.set(await changes.presenterAPI.currentValue.expressionEditorService?.getTabInputInsertableModel());
        }

        if (changes.contributedNode) {
            this.selectedSignalInput.set(changes.contributedNode.currentValue.parameters?.signalInput);
        }
    }

    private async initParamType() {
        if (this.contributedNode.parameters.type === 'signalInput') {
            // clean up other types
            delete this.contributedNode.parameters.time;
            delete this.contributedNode.parameters.expression;

            if (!this.contributedNode.parameters.signalInput) {
                this.contributedNode.parameters.signalInput = {};
                return;
            }
        } else if (this.contributedNode.parameters.type === 'time') {
            // clean up other types
            delete this.contributedNode.parameters.signalInput;
            delete this.contributedNode.parameters.expression;

            if (!this.contributedNode.parameters.time) {
                this.contributedNode.parameters.time = new TabInputModel<Time>(
                    {
                        value: 1,
                        unit: s.label as TimeUnit,
                    },
                    SelectedInput.VALUE,
                    1,
                );
            }
        } else if (this.contributedNode.parameters.type === 'expression') {
            // clean up other types
            delete this.contributedNode.parameters.time;
            delete this.contributedNode.parameters.signalInput;

            // initialize expression parameter if missing
            if (!this.contributedNode.parameters.expression) {
                this.contributedNode.parameters.expression = new TabInputModel<string>('', SelectedInput.EXPRESSION, '');
            }
        }
    }

    async setType({ value }: DropdownOption) {
        if (value !== this.contributedNode.parameters.type) {
            this.contributedNode.parameters.type = value as 'time' | 'signalInput';
            await this.initParamType();
            this.saveNode();
        }
    }

    public getTime() {
        const time = this.contributedNode.parameters.time;
        if (!time) {
            return {
                selectedType: SelectedInput.VALUE,
                value: '1',
            };
        }
        const selectedType = time.selectedType;
        const value =
            selectedType === 'VARIABLE' && this.node()?.parameters.reference
                ? (this.resolvedVariableName() ?? 'undefined')
                : (time?.value ?? 'undefined');
        return {
            selectedType,
            value,
        };
    }

    public async setTime($event: TabInputValue): Promise<void> {
        if (this.contributedNode.parameters.time) {
            const time = this.contributedNode.parameters.time;
            TabInputModel.setTabInputValue(time, $event);
            time.entity.value = Number($event.value);
            if (isNaN(time.entity.value)) {
                time.entity.value = 0;
            }
            if ($event.selectedType === 'VARIABLE') {
                const value = String($event.value);
                const matchingVariable = await lookupByName(value, this.presenterAPI);
                if (matchingVariable) {
                    this.contributedNode.parameters.reference = {
                        valueType: matchingVariable.valueType,
                        valueReference: matchingVariable.reference,
                    } as SampleWaitNodeVariableReference;
                }
            }
            this.contributedNode.parameters.time = time;
            this.saveNode();
        }
    }

    public async setSourceID($event: SourceDropdownOption) {
        if (!this.contributedNode.parameters.signalInput) {
            return;
        }
        this.contributedNode.parameters.signalInput.sourceID = $event.value as string;
        this.contributedNode.parameters.signalInput.groupId = $event.groupId;
        this.contributedNode.parameters.signalInput.signalID = undefined;
        this.contributedNode.parameters.signalInput.selectedType = undefined;
        this.contributedNode.parameters.signalInput.signalValueType = undefined;
        this.contributedNode.parameters.signalInput.value = undefined;
        delete this.contributedNode.parameters.reference;
        delete this.contributedNode.parameters.expression;
        this.saveNode();
    }

    setSignalID($event: SourceSignal) {
        if (!this.contributedNode.parameters.signalInput) {
            return;
        }

        const signalInput = this.contributedNode.parameters.signalInput;
        const previousValue = signalInput.value;
        const previousSelectedType = signalInput.selectedType;
        const previousSignalValueType = signalInput.signalValueType;

        signalInput.signalID = $event.signalID;

        const hasCustomSelection = previousSelectedType === 'VARIABLE' || previousSelectedType === 'EXPRESSION';
        const isSameBaseType =
            ($event.valueType === SignalValueTypeEnum.BOOLEAN && previousSignalValueType === SignalValueTypeEnum.CUSTOM) ||
            $event.valueType === previousSignalValueType;

        if (hasCustomSelection && isSameBaseType) {
            if (previousSignalValueType !== SignalValueTypeEnum.CUSTOM) {
                signalInput.signalValueType = $event.valueType;
            }
            this.saveNode();
            return;
        }

        switch ($event.valueType) {
            case SignalValueTypeEnum.BOOLEAN:
                signalInput.registerOperator = undefined;
                signalInput.floatOperator = undefined;
                signalInput.selectedType = undefined;
                signalInput.value = typeof previousValue === 'boolean' ? previousValue : true;
                break;

            case SignalValueTypeEnum.FLOAT:
                {
                    signalInput.floatOperator = '>';
                    const signalDomainData = getSignalValueRange(this.domains(), $event.signalID);
                    signalInput.selectedType = SelectedInput.VALUE;
                    if (signalDomainData !== undefined) {
                        signalInput.value = {
                            value: signalDomainData.min,
                            unit: signalDomainData.unit,
                        };
                    } else {
                        signalInput.value = 0;
                    }
                }
                break;

            case SignalValueTypeEnum.REGISTER:
                signalInput.registerOperator = '<';
                signalInput.value = 0;
                signalInput.selectedType = undefined;
                break;
        }
        signalInput.signalValueType = $event.valueType;
        delete this.contributedNode.parameters.reference;
        delete this.contributedNode.parameters.expression;

        this.saveNode();
    }

    public signalLabelFactory = (signal: SourceSignal) => {
        return signal?.name || signal.signalID;
    };

    async setAnalogTabInput($event: TabInputValue): Promise<void> {
        if (this.contributedNode.parameters.signalInput === undefined) {
            return;
        }

        const domain = getSignalValueRange(this.domains(), this.contributedNode.parameters.signalInput?.signalID);

        if (domain !== undefined && $event.selectedType === 'VALUE') {
            this.contributedNode.parameters.signalInput.value = { value: Number($event.value), unit: domain.unit };
        } else {
            this.contributedNode.parameters.signalInput.value = $event.value;
        }

        this.contributedNode.parameters.signalInput.selectedType = $event.selectedType;

        if ($event.selectedType === 'VARIABLE' && $event.value != null) {
            const matchingVariable = await lookupByName(String($event.value), this.presenterAPI);
            if (matchingVariable) {
                this.contributedNode.parameters.reference = {
                    valueType: matchingVariable.valueType,
                    valueReference: matchingVariable.reference,
                } as SampleWaitNodeVariableReference;
            }
        }

        this.saveNode();
    }

    setRegisterValue($event: TabInputValue) {
        if (this.contributedNode.parameters.signalInput) {
            this.contributedNode.parameters.signalInput.value = $event.value;
            this.contributedNode.parameters.signalInput.signalValueType = SignalValueTypeEnum.REGISTER;
            this.contributedNode.parameters.signalInput.selectedType = $event.selectedType;
            this.saveNode();
        }
    }

    isVarSuppressed(searchName: string): boolean {
        return this.tabInputVariables().some((item) => item.name === searchName && item.suppressed);
    }

    varExists(searchName: string): boolean {
        return this.tabInputVariables().some((item) => item.name === searchName);
    }

    isDeletedVar(searchName: string): boolean {
        return this.tabInputVariables().some((item) => item.name === searchName && item.isDeleted);
    }

    setDigitalValue($event: DropdownOption) {
        const dropDownOption = $event as DropdownOption;

        if (typeof dropDownOption.value === 'boolean') {
            this.contributedNode.parameters.signalInput = {
                ...this.contributedNode.parameters.signalInput,
                value: dropDownOption.value,
                signalValueType: SignalValueTypeEnum.BOOLEAN,
                selectedType: undefined,
            };

            this.saveNode();
        }
    }

    createTabInputData(): TabInputData {
        const selectedType = this.selectedSignalInput()?.selectedType ?? SelectedInput.VARIABLE;
        let value = this.translateService.instant('select');
        if (selectedType === 'VARIABLE') {
            value = this.resolvedVariableName() ?? value;
        } else {
            value = (this.selectedSignalInput()?.value as string) ?? value;
        }
        return {
            inputLabel: '',
            placeholder: '',
            translations: {},
            type: 'text',
            label: '',
            valueType: ['boolean'],
            insertables: this.expressionInsertables(),
            tabInputValue: {
                selectedType,
                value: value,
            },
            tabs: [SelectedInput.VARIABLE, SelectedInput.EXPRESSION],
        };
    }

    async setDigitalTabInputValue() {
        const inputData = this.createTabInputData();
        const { reason, returnData } = await firstValueFrom(
            this.dialogService.open<TabInputValue>(URTabInputContainerComponent, inputData).afterClose,
        );

        if (reason !== 'CONFIRMED' || !this.contributedNode.parameters.signalInput) {
            return;
        }

        this.contributedNode.parameters.signalInput.signalValueType = SignalValueTypeEnum.CUSTOM;
        this.contributedNode.parameters.signalInput.selectedType = returnData?.selectedType;
        if (['VALUE', 'EXPRESSION'].includes(returnData?.selectedType ?? '')) {
            this.contributedNode.parameters.signalInput.value = returnData?.value;
            delete this.contributedNode.parameters.reference;
        }

        if (returnData?.selectedType === 'VARIABLE' && returnData?.value != null) {
            const matchingVariable = await lookupByName(String(returnData.value), this.presenterAPI);
            if (matchingVariable) {
                delete this.contributedNode.parameters.signalInput.value;
                this.contributedNode.parameters.reference = {
                    valueType: matchingVariable.valueType,
                    valueReference: matchingVariable.reference,
                } as SampleWaitNodeVariableReference;
            }
        }

        this.saveNode();
    }

    public setAnalogOperator($event: string) {
        if (!this.contributedNode.parameters.signalInput) {
            return;
        }
        if ($event === '>' || $event === '<') {
            this.contributedNode.parameters.signalInput.floatOperator = $event;
            this.saveNode();
        }
    }
    public setRegisterOperator($event: registerOperator) {
        if (!this.contributedNode.parameters.signalInput) {
            return;
        }
        this.contributedNode.parameters.signalInput.registerOperator = $event;
        this.contributedNode.parameters.signalInput.signalValueType = SignalValueTypeEnum.REGISTER;
        this.saveNode();
    }

    private getDomainDataErrorString(val: number, constraints: ValueRange): string | null {
        return this.getRangeErrorString(val, { lowerLimit: constraints.min, upperLimit: constraints.max, unit: constraints.unit });
    }

    public validateAnalogValue(val: number) {
        const signalDomainData = getSignalValueRange(this.domains(), this.contributedNode.parameters.signalInput?.signalID);
        if (signalDomainData !== undefined) {
            return this.getDomainDataErrorString(val, signalDomainData);
        }
        return undefined;
    }

    public setExpression($event: TabInputValue): void {
        this.contributedNode.parameters.expression = $event;
        this.saveNode();
    }

    protected readonly createNumberRangeValidator = createNumberRangeValidator;
}

const getSignalValueRange = (domains: Record<string, ValueRange> | undefined, signalID: string | undefined) => {
    if (signalID && domains && Object.hasOwnProperty.call(domains, signalID)) {
        return Reflect.get(domains, signalID) as ValueRange;
    }
    return undefined;
};
