#!/usr/bin/env bash
set -e

CURRENT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

(return 0 2>/dev/null) && sourced=1


install_executable() {
  npm install --force --silent --prefix artifacts/runtime

  cat <<EOT >"${CURRENT_DIR}"/run-simulator
#!/usr/bin/env bash

node "${CURRENT_DIR}"/artifacts/runtime "\$@"
EOT

  chmod +x "${CURRENT_DIR}"/run-simulator
}

install_executable

set +e